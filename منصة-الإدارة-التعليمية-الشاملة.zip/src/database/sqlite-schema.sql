-- ============================================================================
-- منظومة إتقان لإدارة المدارس ومراكز الدعم والتقوية التربوية
-- SQLite Database Schema Definition (Ready for Tauri / Desktop Offline Deployment)
-- ============================================================================

PRAGMA foreign_keys = ON;

-- 1. جدول إعدادات المؤسسة
CREATE TABLE IF NOT EXISTS center_settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    center_name TEXT NOT NULL,
    slogan TEXT,
    address TEXT,
    phone TEXT NOT NULL,
    phone_secondary TEXT,
    email TEXT,
    logo_url TEXT,
    currency TEXT DEFAULT 'MAD',
    academic_year TEXT DEFAULT '2025/2026',
    receipt_prefix TEXT DEFAULT 'REC',
    receipt_next_number INTEGER DEFAULT 1,
    receipt_terms_notice TEXT,
    director_name TEXT,
    tax_id_or_license TEXT,
    print_format_default TEXT DEFAULT 'A4',
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 2. جدول المستخدمين والصلاحيات
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('director', 'admin', 'accountant', 'viewer')),
    permissions TEXT NOT NULL, -- JSON array of permissions
    password_hash TEXT NOT NULL,
    active INTEGER DEFAULT 1,
    last_login TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 3. جدول المستويات الدراسية
CREATE TABLE IF NOT EXISTS levels (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    code TEXT UNIQUE NOT NULL,
    order_index INTEGER DEFAULT 0,
    description TEXT
);

-- 4. جدول المواد التعليمية
CREATE TABLE IF NOT EXISTS subjects (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    level_id TEXT REFERENCES levels(id) ON DELETE CASCADE,
    color TEXT
);

-- 5. جدول المجموعات الدراسية
CREATE TABLE IF NOT EXISTS study_groups (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    level_id TEXT NOT NULL REFERENCES levels(id),
    subject_id TEXT NOT NULL REFERENCES subjects(id),
    teacher_name TEXT NOT NULL,
    max_capacity INTEGER DEFAULT 20,
    schedule_json TEXT NOT NULL, -- JSON list of days, times and classrooms
    monthly_fee REAL NOT NULL DEFAULT 0.0,
    registration_fee REAL DEFAULT 0.0,
    per_session_fee REAL DEFAULT 0.0,
    status TEXT DEFAULT 'active' CHECK(status IN ('active', 'paused')),
    academic_year TEXT NOT NULL,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 6. جدول التلاميذ
CREATE TABLE IF NOT EXISTS students (
    id TEXT PRIMARY KEY,
    code TEXT UNIQUE NOT NULL, -- معرف فريد مثل رقم مسار
    full_name TEXT NOT NULL,
    birth_date TEXT,
    gender TEXT CHECK(gender IN ('male', 'female')),
    guardian_name TEXT NOT NULL,
    guardian_phone TEXT NOT NULL,
    guardian_relation TEXT DEFAULT 'أب',
    address TEXT,
    level_id TEXT NOT NULL REFERENCES levels(id),
    status TEXT DEFAULT 'active' CHECK(status IN ('active', 'inactive', 'suspended')),
    registration_date TEXT NOT NULL,
    notes TEXT,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_students_name ON students(full_name);
CREATE INDEX IF NOT EXISTS idx_students_code ON students(code);
CREATE INDEX IF NOT EXISTS idx_students_guardian_phone ON students(guardian_phone);
CREATE INDEX IF NOT EXISTS idx_students_level ON students(level_id);

-- 7. جدول تسجيل التلاميذ في المجموعات
CREATE TABLE IF NOT EXISTS student_enrollments (
    id TEXT PRIMARY KEY,
    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    group_id TEXT NOT NULL REFERENCES study_groups(id) ON DELETE CASCADE,
    enrollment_date TEXT NOT NULL,
    status TEXT DEFAULT 'active' CHECK(status IN ('active', 'transferred', 'dropped')),
    transfer_reason TEXT,
    UNIQUE(student_id, group_id)
);

-- 8. جدول الرسوم والاستحقاقات المالية (Charges)
CREATE TABLE IF NOT EXISTS fee_charges (
    id TEXT PRIMARY KEY,
    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    group_id TEXT REFERENCES study_groups(id) ON DELETE SET NULL,
    type TEXT NOT NULL CHECK(type IN ('registration', 'monthly', 'session', 'custom')),
    title TEXT NOT NULL,
    amount REAL NOT NULL,
    due_date TEXT NOT NULL,
    academic_year TEXT NOT NULL,
    period_month TEXT,
    status TEXT DEFAULT 'unpaid' CHECK(status IN ('unpaid', 'partial', 'paid')),
    paid_amount REAL DEFAULT 0.0,
    remaining_amount REAL NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_charges_student ON fee_charges(student_id);
CREATE INDEX IF NOT EXISTS idx_charges_status ON fee_charges(status);

-- 9. جدول عمليات الأداء المالي (Payments)
CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    receipt_number TEXT UNIQUE NOT NULL,
    student_id TEXT NOT NULL REFERENCES students(id),
    charge_id TEXT REFERENCES fee_charges(id) ON DELETE SET NULL,
    amount_paid REAL NOT NULL,
    previous_balance REAL DEFAULT 0.0,
    remaining_balance_after REAL DEFAULT 0.0,
    payment_date TEXT NOT NULL,
    payment_method TEXT NOT NULL CHECK(payment_method IN ('cash', 'transfer', 'cheque', 'card', 'other')),
    reference_number TEXT,
    notes TEXT,
    recorded_by TEXT NOT NULL,
    status TEXT DEFAULT 'completed' CHECK(status IN ('completed', 'cancelled')),
    cancellation_reason TEXT,
    cancelled_at TEXT,
    cancelled_by TEXT,
    items_covered TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_payments_student ON payments(student_id);
CREATE INDEX IF NOT EXISTS idx_payments_receipt ON payments(receipt_number);
CREATE INDEX IF NOT EXISTS idx_payments_date ON payments(payment_date);

-- 10. جدول المصاريف (Expenses)
CREATE TABLE IF NOT EXISTS expenses (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL CHECK(category IN ('rent', 'salaries', 'utilities', 'supplies', 'maintenance', 'marketing', 'taxes', 'other')),
    amount REAL NOT NULL,
    date TEXT NOT NULL,
    payment_method TEXT NOT NULL,
    beneficiary TEXT,
    reference_doc TEXT,
    notes TEXT,
    recorded_by TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(date);

-- 11. جدول الحضور والغياب (Attendance)
CREATE TABLE IF NOT EXISTS attendance_records (
    id TEXT PRIMARY KEY,
    group_id TEXT NOT NULL REFERENCES study_groups(id) ON DELETE CASCADE,
    student_id TEXT NOT NULL REFERENCES students(id) ON DELETE CASCADE,
    session_date TEXT NOT NULL,
    session_time TEXT,
    status TEXT NOT NULL CHECK(status IN ('present', 'absent', 'late', 'excused')),
    notes TEXT,
    recorded_by TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(group_id, student_id, session_date)
);
CREATE INDEX IF NOT EXISTS idx_attendance_date ON attendance_records(session_date);
CREATE INDEX IF NOT EXISTS idx_attendance_student ON attendance_records(student_id);

-- 12. جدول سجل العمليات والتدقيق (Audit Logs)
CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY,
    timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
    user_id TEXT NOT NULL,
    user_name TEXT NOT NULL,
    action TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    details TEXT
);

-- 13. جدول بيانات الترخيص
CREATE TABLE IF NOT EXISTS license_info (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    center_name TEXT NOT NULL,
    license_key TEXT NOT NULL,
    license_type TEXT DEFAULT 'lifetime_commercial',
    issue_date TEXT NOT NULL,
    expires_at TEXT,
    machine_fingerprint TEXT NOT NULL,
    is_valid INTEGER DEFAULT 1
);
