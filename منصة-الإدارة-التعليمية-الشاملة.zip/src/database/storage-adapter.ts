import { AppDatabase } from '../types';
import { initialDatabase } from './initial-data';

const STORAGE_KEY = 'itqan_school_os_clean_v2';
const BACKUP_PREFIX = 'itqan_backup_';

export interface StorageAdapter {
  isTauriDesktop(): boolean;
  getDatabase(): Promise<AppDatabase>;
  saveDatabase(data: AppDatabase): Promise<void>;
  exportBackup(): Promise<{ jsonString: string; filename: string; checksum: string }>;
  importBackup(rawJson: string): Promise<{ success: boolean; message: string; count?: number }>;
  resetToInitial(): Promise<void>;
  clearTransactionalData(): Promise<void>;
}

// Simple checksum generator for backup integrity
function calculateChecksum(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16).toUpperCase().padStart(8, '0');
}

class LocalPersistentAdapter implements StorageAdapter {
  isTauriDesktop(): boolean {
    return typeof window !== 'undefined' && Boolean((window as unknown as { __TAURI__?: unknown }).__TAURI__);
  }

  async getDatabase(): Promise<AppDatabase> {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (!stored) {
        // Initialize with default seed data
        await this.saveDatabase(initialDatabase);
        return initialDatabase;
      }
      const parsed = JSON.parse(stored) as AppDatabase;

      // Ensure all arrays and objects exist in case of future schema expansions
      return {
        levels: Array.isArray(parsed.levels) ? parsed.levels : initialDatabase.levels,
        subjects: Array.isArray(parsed.subjects) ? parsed.subjects : initialDatabase.subjects,
        groups: Array.isArray(parsed.groups) ? parsed.groups : initialDatabase.groups,
        students: Array.isArray(parsed.students) ? parsed.students : [],
        enrollments: Array.isArray(parsed.enrollments) ? parsed.enrollments : [],
        charges: Array.isArray(parsed.charges) ? parsed.charges : [],
        payments: Array.isArray(parsed.payments) ? parsed.payments : [],
        expenses: Array.isArray(parsed.expenses) ? parsed.expenses : [],
        attendance: Array.isArray(parsed.attendance) ? parsed.attendance : [],
        devices: Array.isArray(parsed.devices) ? parsed.devices : (initialDatabase.devices || []),
        teachers: Array.isArray(parsed.teachers) ? parsed.teachers : (initialDatabase.teachers || []),
        teacherPayments: Array.isArray(parsed.teacherPayments) ? parsed.teacherPayments : [],
        grades: Array.isArray(parsed.grades) ? parsed.grades : [],
        cashClosures: Array.isArray(parsed.cashClosures) ? parsed.cashClosures : [],
        settings: { ...initialDatabase.settings, ...(parsed.settings || {}) },
        users: Array.isArray(parsed.users) ? parsed.users : initialDatabase.users,
        auditLogs: Array.isArray(parsed.auditLogs) ? parsed.auditLogs : [],
        license: { ...initialDatabase.license, ...(parsed.license || {}) },
      };
    } catch (e) {
      console.error('Error reading database from persistent storage:', e);
      return initialDatabase;
    }
  }

  async saveDatabase(data: AppDatabase): Promise<void> {
    try {
      const serialized = JSON.stringify(data);
      localStorage.setItem(STORAGE_KEY, serialized);
    } catch (e) {
      console.error('Failed to save to local storage:', e);
      throw new Error('فشل حفظ التعديلات في وحدة التخزين المحلية. تأكد من توفر مساحة كافية.');
    }
  }

  async exportBackup(): Promise<{ jsonString: string; filename: string; checksum: string }> {
    const db = await this.getDatabase();
    const jsonString = JSON.stringify(db, null, 2);
    const checksum = calculateChecksum(jsonString);
    const dateStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const sanitizedCenterName = (db.settings.centerName || 'center')
      .replace(/[\s/\\?%*:|"<>]/g, '_')
      .slice(0, 20);
    const filename = `${BACKUP_PREFIX}${sanitizedCenterName}_${dateStr}.json`;

    return {
      jsonString,
      filename,
      checksum,
    };
  }

  async importBackup(rawJson: string): Promise<{ success: boolean; message: string; count?: number }> {
    try {
      const parsed = JSON.parse(rawJson);
      
      // Basic schema validation
      if (!parsed || typeof parsed !== 'object') {
        return { success: false, message: 'ملف النسخة الاحتياطية غير صالح أو فارغ.' };
      }

      if (!Array.isArray(parsed.students) || !parsed.settings) {
        return { success: false, message: 'هيكل بيانات النسخة الاحتياطية لا يتطابق مع قاعدة بيانات منظومة إتقان.' };
      }

      // Auto-save a safety rollback snapshot of the current state before replacing
      const current = await this.getDatabase();
      localStorage.setItem(`${STORAGE_KEY}_safety_snapshot`, JSON.stringify(current));

      // Overwrite current database
      await this.saveDatabase(parsed as AppDatabase);

      const studentCount = parsed.students.length;
      return {
        success: true,
        message: `تم استعادة النسخة الاحتياطية بنجاح. تم تحميل ${studentCount} تلميذاً وسجلاتهم كاملة.`,
        count: studentCount,
      };
    } catch (e) {
      return {
        success: false,
        message: `حدث خطأ أثناء معالجة ملف النسخة الاحتياطية: ${(e as Error).message}`,
      };
    }
  }

  async resetToInitial(): Promise<void> {
    await this.saveDatabase(initialDatabase);
  }

  async clearTransactionalData(): Promise<void> {
    const db = await this.getDatabase();
    db.students = [];
    db.enrollments = [];
    db.charges = [];
    db.payments = [];
    db.expenses = [];
    db.attendance = [];
    db.auditLogs = [];
    db.settings.receiptNextNumber = 1;
    await this.saveDatabase(db);
  }
}

export const storageAdapter: StorageAdapter = new LocalPersistentAdapter();
