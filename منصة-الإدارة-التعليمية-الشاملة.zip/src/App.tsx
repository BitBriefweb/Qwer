/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import {
  Student,
  StudentWithDetails,
  StudyGroup,
  Level,
  Subject,
  Payment,
  Expense,
  CenterSettings,
  LicenseInfo,
  User,
  AuditLog,
  ConnectedDevice,
  Teacher,
} from './types';
import {
  dataService,
  FinancialStats,
  DashboardAnalytics,
} from './services/data-service';
import { storageAdapter } from './database/storage-adapter';

// Layout & Common Components
import { Sidebar, NavSection } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { ConfirmDialog } from './components/common/ConfirmDialog';

// Views
import { DashboardView } from './components/views/DashboardView';
import { BranchesView } from './components/views/BranchesView';
import { StudentsView } from './components/views/StudentsView';
import { GroupsView } from './components/views/GroupsView';
import { DevicesView } from './components/views/DevicesView';
import { MobileAttendanceTerminal } from './components/mobile/MobileAttendanceTerminal';
import { FinanceView } from './components/views/FinanceView';
import { ExpensesView } from './components/views/ExpensesView';
import { AttendanceSheet } from './components/attendance/AttendanceSheet';
import { ReportsView } from './components/views/ReportsView';
import { SettingsManager } from './components/settings/SettingsManager';
import { TeachersView } from './components/views/TeachersView';

// Modals
import { DailyCashClosureModal } from './components/finance/DailyCashClosureModal';
import { GradesManagerModal } from './components/grades/GradesManagerModal';
import { InstitutionProfileModal } from './components/institution/InstitutionProfileModal';

// Modals
import { StudentFormModal } from './components/students/StudentFormModal';
import { StudentProfileModal } from './components/students/StudentProfileModal';
import { StudentTransferModal } from './components/students/StudentTransferModal';
import { StudentCardModal } from './components/students/StudentCardModal';
import { PaymentFormModal } from './components/finance/PaymentFormModal';
import { CancelPaymentModal } from './components/finance/CancelPaymentModal';
import { GroupFormModal } from './components/groups/GroupFormModal';
import { ExpenseFormModal } from './components/expenses/ExpenseFormModal';
import { PrintableReceipt } from './components/receipts/PrintableReceipt';
import { TauriDesktopGuideModal } from './components/tauri/TauriDesktopGuideModal';
import { GlobalQuickSearchModal } from './components/common/GlobalQuickSearchModal';
import { Modal } from './components/common/Modal';

export default function App() {
  const [activeSection, setActiveSection] = useState<NavSection>('dashboard');
  const [isLoading, setIsLoading] = useState(true);

  // Core Data State
  const [students, setStudents] = useState<StudentWithDetails[]>([]);
  const [levels, setLevels] = useState<Level[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [groups, setGroups] = useState<
    Array<StudyGroup & { enrolledCount: number; levelName: string; subjectName: string }>
  >([]);
  const [payments, setPayments] = useState<
    Array<Payment & { studentName: string; studentCode: string; levelName: string }>
  >([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [stats, setStats] = useState<FinancialStats>({
    collectedToday: 0,
    collectedThisMonth: 0,
    totalCollected: 0,
    totalRemainingDue: 0,
    totalExpenses: 0,
    netCashflow: 0,
    paymentCountThisMonth: 0,
  });
  const [settings, setSettings] = useState<CenterSettings>({
    centerName: 'منظومة إتقان',
    slogan: '',
    address: '',
    phone: '',
    currency: 'MAD',
    academicYear: '2025/2026',
    receiptPrefix: 'REC',
    receiptNextNumber: 1,
    receiptTermsNotice: '',
    directorName: '',
    printFormatDefault: 'A4',
  });
  const [license, setLicense] = useState<LicenseInfo>({
    centerName: '',
    licenseKey: '',
    licenseType: 'lifetime_commercial',
    issueDate: '',
    machineFingerprint: '',
    isValid: true,
  });
  const [users, setUsers] = useState<User[]>([]);
  const [currentUser, setCurrentUser] = useState<User>(dataService.getCurrentUser());
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  // Modals visibility state
  const [isStudentModalOpen, setIsStudentModalOpen] = useState(false);
  const [studentToEdit, setStudentToEdit] = useState<Student | null>(null);
  const [selectedStudentForProfile, setSelectedStudentForProfile] = useState<StudentWithDetails | null>(
    null
  );
  const [studentForTransfer, setStudentForTransfer] = useState<StudentWithDetails | null>(null);
  const [studentForCard, setStudentForCard] = useState<StudentWithDetails | null>(null);
  const [studentToDelete, setStudentToDelete] = useState<StudentWithDetails | null>(null);

  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [preselectedStudentForPayment, setPreselectedStudentForPayment] = useState<StudentWithDetails | null>(
    null
  );
  const [paymentToPrint, setPaymentToPrint] = useState<Payment | null>(null);
  const [paymentToCancel, setPaymentToCancel] = useState<Payment | null>(null);

  const [isGroupModalOpen, setIsGroupModalOpen] = useState(false);
  const [groupToEdit, setGroupToEdit] = useState<StudyGroup | null>(null);
  const [initialSubjectIdForGroup, setInitialSubjectIdForGroup] = useState<string | undefined>(undefined);

  const [isExpenseModalOpen, setIsExpenseModalOpen] = useState(false);
  const [expenseToDelete, setExpenseToDelete] = useState<Expense | null>(null);

  const [isTauriGuideOpen, setIsTauriGuideOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Mobile Device Companion State
  const [devices, setDevices] = useState<ConnectedDevice[]>([]);
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [isCashClosureOpen, setIsCashClosureOpen] = useState(false);
  const [isGradesModalOpen, setIsGradesModalOpen] = useState(false);
  const [isInstitutionProfileOpen, setIsInstitutionProfileOpen] = useState(false);
  const [analytics, setAnalytics] = useState<DashboardAnalytics | undefined>(undefined);
  const [activeMobileTerminalDevice, setActiveMobileTerminalDevice] = useState<ConnectedDevice | null>(null);
  const [isStandaloneMobile, setIsStandaloneMobile] = useState(false);

  // Check URL parameters for standalone mobile tablet terminal (?mode=mobile_terminal)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const mode = params.get('mode');
    const devId = params.get('device');
    const token = params.get('token');

    if (mode === 'mobile_terminal' || mode === 'mobile_attendance') {
      setIsStandaloneMobile(true);
      if (devId) {
        dataService.getDevices().then((devList) => {
          const matched = devList.find((d) => d.id === devId || d.pairingToken === token);
          if (matched) {
            setActiveMobileTerminalDevice(matched);
          } else {
            // Create fallback device session for phone
            setActiveMobileTerminalDevice({
              id: devId || 'dev-mobile',
              name: 'جهاز التابليت المتنقل',
              deviceType: 'tablet',
              pairingToken: token || 'DEV-DIRECT',
              pinCode: '1234',
              status: 'active',
              createdAt: new Date().toISOString().substring(0, 10),
            });
          }
        });
      }
    }
  }, []);

  // Global Ctrl+K keyboard shortcut to open instant search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Load all data
  const loadAllData = useCallback(async () => {
    try {
      const [
        studentsList,
        levelsList,
        subjectsList,
        groupsList,
        paymentsList,
        expensesList,
        finStats,
        sett,
        lic,
        usersList,
        logsList,
        devicesList,
        analyticsData,
        teachersData,
      ] = await Promise.all([
        dataService.getStudents(),
        dataService.getLevels(),
        dataService.getSubjects(),
        dataService.getGroups(),
        dataService.getPayments(),
        dataService.getExpenses(),
        dataService.getFinancialStats(),
        dataService.getSettings(),
        dataService.getLicense(),
        dataService.getUsers(),
        dataService.getAuditLogs(),
        dataService.getDevices(),
        dataService.getDashboardAnalytics(),
        dataService.getTeachers(),
      ]);

      setStudents(studentsList);
      setLevels(levelsList);
      setSubjects(subjectsList);
      setGroups(groupsList);
      setPayments(paymentsList);
      setExpenses(expensesList);
      setStats(finStats);
      setSettings(sett);
      setLicense(lic);
      setUsers(usersList);
      setCurrentUser(dataService.getCurrentUser());
      setAuditLogs(logsList);
      setDevices(devicesList);
      setAnalytics(analyticsData);
      setTeachers(teachersData);
    } catch (e) {
      console.error('Error loading application data:', e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Listen for BroadcastChannel events across tabs/windows (e.g. tablet sync to PC)
  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel('itqan_device_sync');
      channel.onmessage = (event) => {
        if (event.data?.type === 'ATTENDANCE_SYNCED') {
          loadAllData();
        }
      };
    } catch (e) {
      // not supported in older browsers
    }
    return () => {
      channel?.close();
    };
  }, [loadAllData]);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // Section title mapping
  const sectionTitles: Record<NavSection, string> = {
    dashboard: 'لوحة التحكم والمؤشرات الإحصائية العامة',
    branches: 'المواد والأفواج (المادة ⬅️ الفوج ⬅️ التلاميذ)',
    students: 'إدارة شؤون وسجلات التلاميذ',
    groups: 'المواد والأفواج (المادة ⬅️ الفوج ⬅️ التلاميذ)',
    attendance: 'ورقة تسجيل الحضور والغياب',
    devices: 'ربط أجهزة التابليت والهواتف (تسجيل الغياب بالقاعات)',
    teachers: 'إدارة هيئة التدريس ومستحقات الأساتذة',
    finance: 'الأداءات المالية وسجل الوصولات',
    expenses: 'المصاريف التشغيلية والتكاليف',
    reports: 'التقارير المالية والديون وصافي السيولة',
    settings: 'إعدادات المؤسسة والنسخ الاحتياطي والترخيص',
  };

  // Device Management Handlers
  const handleAddDevice = async (
    deviceData: Omit<ConnectedDevice, 'id' | 'createdAt' | 'pairingToken'>
  ): Promise<ConnectedDevice> => {
    const newDev = await dataService.addDevice(deviceData);
    await loadAllData();
    return newDev;
  };

  const handleUpdateDevice = async (id: string, updates: Partial<ConnectedDevice>) => {
    const updated = await dataService.updateDevice(id, updates);
    await loadAllData();
    return updated;
  };

  const handleDeleteDevice = async (id: string) => {
    await dataService.deleteDevice(id);
    await loadAllData();
  };

  const handleSyncMobileAttendance = async (
    deviceToken: string,
    groupId: string,
    date: string,
    records: Array<{ studentId: string; status: any; notes?: string }>
  ) => {
    const res = await dataService.syncMobileAttendance(deviceToken, groupId, date, records);
    await loadAllData();
    return res;
  };

  // Branch & Subject Handlers
  const handleAddSubject = async (subjectData: Omit<Subject, 'id'>) => {
    await dataService.addSubject(subjectData);
    await loadAllData();
  };

  const handleUpdateSubject = async (id: string, updates: Partial<Subject>) => {
    await dataService.updateSubject(id, updates);
    await loadAllData();
  };

  const handleDeleteSubject = async (id: string) => {
    await dataService.deleteSubject(id);
    await loadAllData();
  };

  const handleEnrollExistingStudent = async (studentId: string, groupId: string) => {
    await dataService.enrollStudent(studentId, groupId);
    await loadAllData();
  };

  const handleAddNewStudentAndEnroll = async (
    studentData: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }
  ) => {
    await dataService.addStudent(studentData);
    await loadAllData();
  };

  // Student Actions Handlers
  const handleSaveStudent = async (data: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }) => {
    if (studentToEdit) {
      await dataService.updateStudent(studentToEdit.id, data);
    } else {
      await dataService.addStudent(data);
    }
    await loadAllData();
    setIsStudentModalOpen(false);
    setStudentToEdit(null);
  };

  const handleConfirmDeleteStudent = async () => {
    if (!studentToDelete) return;
    try {
      await dataService.deleteStudent(studentToDelete.id);
      await loadAllData();
      setStudentToDelete(null);
    } catch (e) {
      alert((e as Error).message);
    }
  };

  const handleToggleStudentStatus = async (student: StudentWithDetails) => {
    const nextStatus = student.status === 'active' ? 'suspended' : 'active';
    await dataService.toggleStudentStatus(student.id, nextStatus);
    await loadAllData();
  };

  const handleTransferStudent = async (
    studentId: string,
    fromGroupId: string,
    toGroupId: string,
    reason: string
  ) => {
    await dataService.transferStudent(studentId, fromGroupId, toGroupId, reason);
    await loadAllData();
    setStudentForTransfer(null);
  };

  const handleUnenrollStudent = async (studentId: string, groupId: string) => {
    try {
      await dataService.unenrollStudent(studentId, groupId);
      await loadAllData();
    } catch (e) {
      alert((e as Error).message);
    }
  };

  // Financial Payment Handlers
  const handlePaymentSuccess = async (newPayment: Payment) => {
    await loadAllData();
    // Open printable receipt immediately
    setPaymentToPrint(newPayment);
  };

  const handleConfirmCancelPayment = async (paymentId: string, reason: string) => {
    await dataService.cancelPayment(paymentId, reason);
    await loadAllData();
    setPaymentToCancel(null);
  };

  // Group Handlers
  const handleSaveGroup = async (groupData: Omit<StudyGroup, 'id'>) => {
    if (groupToEdit) {
      await dataService.updateGroup(groupToEdit.id, groupData);
    } else {
      await dataService.addGroup(groupData);
    }
    await loadAllData();
    setIsGroupModalOpen(false);
    setGroupToEdit(null);
  };

  // Expense Handlers
  const handleSaveExpense = async (expenseData: Omit<Expense, 'id' | 'recordedBy'>) => {
    await dataService.addExpense(expenseData);
    await loadAllData();
    setIsExpenseModalOpen(false);
  };

  const handleConfirmDeleteExpense = async () => {
    if (!expenseToDelete) return;
    await dataService.deleteExpense(expenseToDelete.id);
    await loadAllData();
    setExpenseToDelete(null);
  };

  // Settings Handlers
  const handleUpdateSettings = async (newSettings: Partial<CenterSettings>) => {
    await dataService.updateSettings(newSettings);
    await loadAllData();
  };

  // Quick backup download
  const handleQuickBackup = async () => {
    const backup = await storageAdapter.exportBackup();
    const blob = new Blob([backup.jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = backup.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleSwitchUser = (user: User) => {
    dataService.setCurrentUser(user);
    setCurrentUser(user);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-900 text-white flex flex-col items-center justify-center p-4">
        <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mb-4" />
        <h2 className="text-lg font-bold">جاري تحميل منظومة إتقان المدرسية...</h2>
        <p className="text-xs text-slate-400 mt-1 font-mono">تهيئة قاعدة البيانات والتخزين المحلي المستقل</p>
      </div>
    );
  }

  // Standalone Mobile/Tablet Terminal Mode (e.g. accessed via QR code on smartphone/tablet)
  if (isStandaloneMobile && activeMobileTerminalDevice) {
    return (
      <MobileAttendanceTerminal
        device={activeMobileTerminalDevice}
        groups={groups}
        students={students}
        settings={settings}
        onSyncAttendance={handleSyncMobileAttendance}
        onCloseTerminal={() => {
          setIsStandaloneMobile(false);
          setActiveMobileTerminalDevice(null);
        }}
        isStandaloneMobile={true}
      />
    );
  }

  return (
    <div className="flex h-screen bg-slate-50 text-slate-900 overflow-hidden" dir="rtl">
      {/* Sidebar Navigation */}
      <Sidebar
        activeSection={activeSection}
        onSelectSection={setActiveSection}
        settings={settings}
        license={license}
        currentUser={currentUser}
        onOpenTauriGuide={() => setIsTauriGuideOpen(true)}
        studentsCount={students.filter((s) => s.status === 'active').length}
        debtorsCount={students.filter((s) => s.remainingBalance > 0).length}
        subjectsCount={subjects.length}
        devicesCount={devices.length}
        onOpenInstitutionProfile={() => setIsInstitutionProfileOpen(true)}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top Header */}
        <Header
          sectionTitle={sectionTitles[activeSection]}
          settings={settings}
          currentUser={currentUser}
          onOpenNewStudentModal={() => {
            setStudentToEdit(null);
            setIsStudentModalOpen(true);
          }}
          onOpenPaymentModal={() => {
            setPreselectedStudentForPayment(null);
            setIsPaymentModalOpen(true);
          }}
          onQuickBackup={handleQuickBackup}
          onOpenSearch={() => setIsSearchOpen(true)}
          onOpenCashClosure={() => setIsCashClosureOpen(true)}
          onOpenInstitutionProfile={() => setIsInstitutionProfileOpen(true)}
        />

        {/* Viewport Scrollable Content */}
        <main className="flex-1 overflow-y-auto p-6">
          <div className="max-w-7xl mx-auto">
            {activeSection === 'dashboard' && (
              <DashboardView
                students={students}
                groups={groups}
                payments={payments}
                expenses={expenses}
                stats={stats}
                settings={settings}
                auditLogs={auditLogs}
                currentUser={currentUser}
                analytics={analytics}
                devices={devices}
                onOpenPaymentModal={(stu) => {
                  setPreselectedStudentForPayment(stu || null);
                  setIsPaymentModalOpen(true);
                }}
                onOpenNewStudentModal={() => {
                  setStudentToEdit(null);
                  setIsStudentModalOpen(true);
                }}
                onSelectStudent={(stu) => setSelectedStudentForProfile(stu)}
                onPrintPayment={(pay) => setPaymentToPrint(pay)}
                onNavigateSection={(sec) => setActiveSection(sec)}
                onOpenMobileTerminal={(dev) => setActiveMobileTerminalDevice(dev)}
              />
            )}

            {(activeSection === 'branches' || activeSection === 'groups') && (
              <BranchesView
                subjects={subjects}
                groups={groups}
                students={students}
                levels={levels}
                settings={settings}
                onAddSubject={handleAddSubject}
                onUpdateSubject={handleUpdateSubject}
                onDeleteSubject={handleDeleteSubject}
                onOpenNewGroupForSubject={(subId) => {
                  setInitialSubjectIdForGroup(subId);
                  setGroupToEdit(null);
                  setIsGroupModalOpen(true);
                }}
                onOpenEditGroupModal={(grp) => {
                  setGroupToEdit(grp);
                  setInitialSubjectIdForGroup(grp.subjectId);
                  setIsGroupModalOpen(true);
                }}
                onEnrollExistingStudent={handleEnrollExistingStudent}
                onAddNewStudentAndEnroll={handleAddNewStudentAndEnroll}
                onSelectStudentProfile={(stu) => setSelectedStudentForProfile(stu)}
                onOpenPaymentModal={(stu) => {
                  setPreselectedStudentForPayment(stu);
                  setIsPaymentModalOpen(true);
                }}
                onPrintStudentCard={(stu) => setStudentForCard(stu)}
                onTakeAttendance={(grpId) => {
                  setActiveSection('attendance');
                }}
                onUnenrollStudent={handleUnenrollStudent}
              />
            )}

            {activeSection === 'students' && (
              <StudentsView
                students={students}
                levels={levels}
                groups={groups}
                settings={settings}
                onOpenNewModal={() => {
                  setStudentToEdit(null);
                  setIsStudentModalOpen(true);
                }}
                onOpenEditModal={(stu) => {
                  setStudentToEdit(stu);
                  setIsStudentModalOpen(true);
                }}
                onSelectStudent={(stu) => setSelectedStudentForProfile(stu)}
                onOpenPaymentModal={(stu) => {
                  setPreselectedStudentForPayment(stu);
                  setIsPaymentModalOpen(true);
                }}
                onOpenTransferModal={(stu) => setStudentForTransfer(stu)}
                onToggleStatus={handleToggleStudentStatus}
                onDeleteStudent={(stu) => setStudentToDelete(stu)}
                onPrintStudentCard={(stu) => setStudentForCard(stu)}
              />
            )}

            {activeSection === 'finance' && (
              <FinanceView
                payments={payments}
                students={students}
                settings={settings}
                onOpenNewPaymentModal={() => {
                  setPreselectedStudentForPayment(null);
                  setIsPaymentModalOpen(true);
                }}
                onPrintPayment={(pay) => setPaymentToPrint(pay)}
                onCancelPayment={(pay) => setPaymentToCancel(pay)}
              />
            )}

            {activeSection === 'expenses' && (
              <ExpensesView
                expenses={expenses}
                settings={settings}
                onOpenNewExpenseModal={() => setIsExpenseModalOpen(true)}
                onDeleteExpense={(exp) => setExpenseToDelete(exp)}
              />
            )}

            {activeSection === 'attendance' && (
              <AttendanceSheet groups={groups} students={students} settings={settings} />
            )}

            {activeSection === 'devices' && (
              <DevicesView
                devices={devices}
                groups={groups}
                settings={settings}
                onAddDevice={handleAddDevice}
                onUpdateDevice={handleUpdateDevice}
                onDeleteDevice={handleDeleteDevice}
                onOpenMobileTerminal={(dev) => setActiveMobileTerminalDevice(dev)}
              />
            )}

            {activeSection === 'teachers' && (
              <TeachersView
                teachers={teachers}
                groups={groups}
                settings={settings}
                onRefreshData={loadAllData}
              />
            )}

            {activeSection === 'reports' && (
              <ReportsView
                students={students}
                payments={payments}
                expenses={expenses}
                settings={settings}
                onOpenPaymentModal={(stu) => {
                  setPreselectedStudentForPayment(stu);
                  setIsPaymentModalOpen(true);
                }}
              />
            )}

            {activeSection === 'settings' && (
              <SettingsManager
                settings={settings}
                license={license}
                users={users}
                currentUser={currentUser}
                onUpdateSettings={handleUpdateSettings}
                onRefreshData={loadAllData}
                onUserSwitched={handleSwitchUser}
                onOpenInstitutionProfile={() => setIsInstitutionProfileOpen(true)}
              />
            )}
          </div>
        </main>
      </div>

      {/* ============================================================
          APPLICATION MODALS & OVERLAYS
          ============================================================ */}

      {/* 1. Student Form Modal (Add/Edit) */}
      <StudentFormModal
        isOpen={isStudentModalOpen}
        onClose={() => {
          setIsStudentModalOpen(false);
          setStudentToEdit(null);
        }}
        onSubmit={handleSaveStudent}
        studentToEdit={studentToEdit}
        levels={levels}
        groups={groups}
      />

      {/* 2. Comprehensive Student Profile Modal */}
      <StudentProfileModal
        isOpen={Boolean(selectedStudentForProfile)}
        onClose={() => setSelectedStudentForProfile(null)}
        student={selectedStudentForProfile}
        settings={settings}
        onOpenPaymentModal={(stu) => {
          setSelectedStudentForProfile(null);
          setPreselectedStudentForPayment(stu);
          setIsPaymentModalOpen(true);
        }}
        onOpenEditModal={(stu) => {
          setSelectedStudentForProfile(null);
          setStudentToEdit(stu);
          setIsStudentModalOpen(true);
        }}
        onOpenTransferModal={(stu) => {
          setSelectedStudentForProfile(null);
          setStudentForTransfer(stu);
        }}
        onPrintPayment={(pay) => setPaymentToPrint(pay)}
        onPrintStudentCard={(stu) => setStudentForCard(stu)}
      />

      {/* 2.5 Student ID Card Modal */}
      <StudentCardModal
        isOpen={Boolean(studentForCard)}
        onClose={() => setStudentForCard(null)}
        student={studentForCard}
        settings={settings}
      />

      {/* 3. Student Group Transfer Modal */}
      <StudentTransferModal
        isOpen={Boolean(studentForTransfer)}
        onClose={() => setStudentForTransfer(null)}
        student={studentForTransfer}
        groups={groups}
        onTransfer={handleTransferStudent}
      />

      {/* 4. Payment Recording & Receipt Issuance Modal */}
      <PaymentFormModal
        isOpen={isPaymentModalOpen}
        onClose={() => {
          setIsPaymentModalOpen(false);
          setPreselectedStudentForPayment(null);
        }}
        students={students}
        initialStudent={preselectedStudentForPayment}
        settings={settings}
        onPaymentSuccess={handlePaymentSuccess}
      />

      {/* 5. Printable Receipt Modal (Dual A4 & Thermal 80mm) */}
      {paymentToPrint && (
        <Modal
          isOpen={Boolean(paymentToPrint)}
          onClose={() => setPaymentToPrint(null)}
          title={`معاينة وصل أداء: ${paymentToPrint.receiptNumber}`}
          subtitle="طباعة الورق الرسمي أو طابعة الوصولات الحرارية POS"
          maxWidth="2xl"
        >
          <PrintableReceipt
            payment={paymentToPrint}
            student={students.find((s) => s.id === paymentToPrint.studentId)}
            settings={settings}
            onClose={() => setPaymentToPrint(null)}
          />
        </Modal>
      )}

      {/* 6. Cancel Payment Modal */}
      <CancelPaymentModal
        isOpen={Boolean(paymentToCancel)}
        onClose={() => setPaymentToCancel(null)}
        payment={paymentToCancel}
        onConfirmCancel={handleConfirmCancelPayment}
      />

      {/* 7. Group Form Modal (Add/Edit) */}
      <GroupFormModal
        isOpen={isGroupModalOpen}
        onClose={() => {
          setIsGroupModalOpen(false);
          setGroupToEdit(null);
          setInitialSubjectIdForGroup(undefined);
        }}
        onSubmit={handleSaveGroup}
        groupToEdit={groupToEdit}
        levels={levels}
        subjects={subjects}
        initialSubjectId={initialSubjectIdForGroup}
      />

      {/* 8. Expense Form Modal */}
      <ExpenseFormModal
        isOpen={isExpenseModalOpen}
        onClose={() => setIsExpenseModalOpen(false)}
        onSubmit={handleSaveExpense}
        settings={settings}
      />

      {/* 9. Confirm Delete Student Dialog */}
      <ConfirmDialog
        isOpen={Boolean(studentToDelete)}
        onClose={() => setStudentToDelete(null)}
        onConfirm={handleConfirmDeleteStudent}
        title="تأكيد حذف ملف التلميذ"
        message={`هل أنت متأكد من رغبتك في حذف ملف التلميذ "${studentToDelete?.fullName}" (${studentToDelete?.code})؟ إذا كان لدى التلميذ وصولات مالية معتمدة، فسيتم رفض الحذف التلقائي حفاظاً على الأثر المحاسبي.`}
        confirmText="تأكيد الحذف"
        variant="danger"
      />

      {/* 10. Confirm Delete Expense Dialog */}
      <ConfirmDialog
        isOpen={Boolean(expenseToDelete)}
        onClose={() => setExpenseToDelete(null)}
        onConfirm={handleConfirmDeleteExpense}
        title="تأكيد حذف المصروف"
        message={`هل أنت متأكد من حذف المصروف "${expenseToDelete?.title}" بمبلغ ${expenseToDelete?.amount} ${settings.currency}؟`}
        confirmText="حذف المصروف"
        variant="danger"
      />

      {/* 11. Tauri Desktop Setup & Packaging Guide Modal */}
      <TauriDesktopGuideModal
        isOpen={isTauriGuideOpen}
        onClose={() => setIsTauriGuideOpen(false)}
      />

      {/* 12. Global Instant Search Modal (Ctrl+K) */}
      <GlobalQuickSearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        students={students}
        payments={payments}
        groups={groups}
        settings={settings}
        onSelectStudent={(stu) => {
          setSelectedStudentForProfile(stu);
          setIsSearchOpen(false);
        }}
        onOpenPaymentModal={(stu) => {
          setPreselectedStudentForPayment(stu);
          setIsPaymentModalOpen(true);
          setIsSearchOpen(false);
        }}
        onPrintPayment={(pay) => {
          setPaymentToPrint(pay);
          setIsSearchOpen(false);
        }}
        onNavigateSection={(sec) => {
          setActiveSection(sec);
          setIsSearchOpen(false);
        }}
      />

      {/* 13. Mobile Tablet Terminal Simulator Overlay (When opened from PC) */}
      {activeMobileTerminalDevice && !isStandaloneMobile && (
        <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="relative w-full max-w-4xl h-[92vh] flex flex-col rounded-3xl overflow-hidden shadow-2xl border-4 border-slate-700 bg-slate-900">
            {/* Tablet Hardware Top Frame Bar */}
            <div className="bg-slate-800/95 px-4 py-2.5 flex items-center justify-between border-b border-slate-700 text-xs text-slate-300 select-none">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse inline-block" />
                <span className="font-bold text-white text-xs sm:text-sm">
                  محاكي جهاز التابليت الذكي الميداني — {activeMobileTerminalDevice.name}
                </span>
                <span className="hidden sm:inline-block bg-indigo-900/80 text-indigo-300 border border-indigo-700 px-2 py-0.5 rounded text-[11px] font-mono">
                  كود PIN: {activeMobileTerminalDevice.pinCode}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[11px] text-slate-400 hidden md:inline">
                  (هذه الواجهة هي نفسها التي تظهر للأستاذ في شاشة هاتفه أو التابليت)
                </span>
                <button
                  type="button"
                  onClick={() => setActiveMobileTerminalDevice(null)}
                  className="px-3 py-1 rounded-lg bg-rose-600/80 hover:bg-rose-600 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-1"
                >
                  <span>إغلاق المحاكي ✕</span>
                </button>
              </div>
            </div>

            {/* Terminal Viewport */}
            <div className="flex-1 overflow-y-auto">
              <MobileAttendanceTerminal
                device={activeMobileTerminalDevice}
                groups={groups}
                students={students}
                settings={settings}
                onSyncAttendance={handleSyncMobileAttendance}
                onCloseTerminal={() => setActiveMobileTerminalDevice(null)}
                isStandaloneMobile={false}
              />
            </div>
          </div>
        </div>
      )}

      {/* 14. Daily Cash Register Closure Modal */}
      <DailyCashClosureModal
        isOpen={isCashClosureOpen}
        onClose={() => setIsCashClosureOpen(false)}
        settings={settings}
        onClosureSaved={loadAllData}
      />

      {/* 15. Grades & Student Evaluations Modal */}
      <GradesManagerModal
        isOpen={isGradesModalOpen}
        onClose={() => setIsGradesModalOpen(false)}
        groups={groups}
        students={students}
        settings={settings}
      />

      {/* 16. Institution Profile & Branding Modal */}
      <InstitutionProfileModal
        isOpen={isInstitutionProfileOpen}
        onClose={() => setIsInstitutionProfileOpen(false)}
        settings={settings}
        onSettingsSaved={(updated) => {
          setSettings(updated);
          loadAllData();
        }}
      />
    </div>
  );
}
