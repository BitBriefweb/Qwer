import {
  AppDatabase,
  Student,
  StudentWithDetails,
  StudyGroup,
  Level,
  Subject,
  SubjectBranchSummary,
  FeeCharge,
  Payment,
  Expense,
  AttendanceRecord,
  CenterSettings,
  AuditLog,
  LicenseInfo,
  User,
  StudentEnrollment,
  ConnectedDevice,
  Teacher,
  TeacherPaymentRecord,
  GradeRecord,
  DailyCashClosure,
} from '../types';
import { storageAdapter } from '../database/storage-adapter';
import {
  verifyLicenseKey,
  generateMachineFingerprint,
  maskLicenseKey,
} from './license-security';

export interface FinancialStats {
  collectedToday: number;
  collectedThisMonth: number;
  totalCollected: number;
  totalRemainingDue: number; // ديون التلاميذ غير المحصلة
  totalExpenses: number;
  netCashflow: number; // صافي السيولة = المداخيل المحصلة - المصاريف
  paymentCountThisMonth: number;
}

export interface MonthlyFinanceTrend {
  monthName: string;
  monthKey: string;
  revenue: number;
  expenses: number;
  net: number;
}

export interface AttendanceDistributionItem {
  name: string;
  count: number;
  percentage: number;
  color: string;
}

export interface SubjectAnalyticsItem {
  id: string;
  name: string;
  code: string;
  color: string;
  studentsCount: number;
  groupsCount: number;
  revenue: number;
}

export interface DashboardAnalytics {
  monthlyTrends: MonthlyFinanceTrend[];
  attendanceDistribution: AttendanceDistributionItem[];
  subjectAnalytics: SubjectAnalyticsItem[];
  overallAttendanceRate: number;
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  totalExcused: number;
}

class DataService {
  private currentUser: User = {
    id: 'usr-1',
    username: 'director',
    fullName: 'ذ. عبد الرحيم بناني (المدير العام)',
    role: 'director',
    permissions: ['all'],
    passwordHash: '',
    active: true,
  };

  getCurrentUser(): User {
    return this.currentUser;
  }

  setCurrentUser(user: User): void {
    this.currentUser = user;
  }

  hasPermission(permission: string): boolean {
    if (this.currentUser.role === 'director' || this.currentUser.permissions.includes('all')) {
      return true;
    }
    return this.currentUser.permissions.includes(permission);
  }

  // --- Audit Log Helper ---
  private async addLog(
    db: AppDatabase,
    action: string,
    entityType: AuditLog['entityType'],
    entityId: string,
    details: string
  ): Promise<void> {
    const log: AuditLog = {
      id: 'log-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 16),
      userId: this.currentUser.id,
      userName: this.currentUser.fullName,
      action,
      entityType,
      entityId,
      details,
    };
    db.auditLogs.unshift(log);
    // Keep max 200 logs
    if (db.auditLogs.length > 200) {
      db.auditLogs = db.auditLogs.slice(0, 200);
    }
  }

  // ==========================================
  // STUDENTS MODULE
  // ==========================================
  async getStudents(filters?: {
    search?: string;
    levelId?: string;
    groupId?: string;
    status?: Student['status'];
  }): Promise<StudentWithDetails[]> {
    const db = await storageAdapter.getDatabase();
    let result = db.students;

    if (filters?.levelId) {
      result = result.filter((s) => s.levelId === filters.levelId);
    }

    if (filters?.status) {
      result = result.filter((s) => s.status === filters.status);
    }

    if (filters?.groupId) {
      const enrolledStudentIds = new Set(
        db.enrollments
          .filter((e) => e.groupId === filters.groupId && e.status === 'active')
          .map((e) => e.studentId)
      );
      result = result.filter((s) => enrolledStudentIds.has(s.id));
    }

    if (filters?.search) {
      const q = filters.search.trim().toLowerCase();
      result = result.filter(
        (s) =>
          s.fullName.toLowerCase().includes(q) ||
          s.code.toLowerCase().includes(q) ||
          s.guardianPhone.includes(q) ||
          s.guardianName.toLowerCase().includes(q)
      );
    }

    // Enrich with calculated data
    return result.map((student) => {
      // Find active enrollments
      const studentEnrollments = db.enrollments.filter(
        (e) => e.studentId === student.id && e.status === 'active'
      );
      const enrolledGroups = studentEnrollments
        .map((e) => {
          const grp = db.groups.find((g) => g.id === e.groupId);
          return grp
            ? {
                id: grp.id,
                name: grp.name,
                teacherName: grp.teacherName,
                monthlyFee: grp.monthlyFee,
              }
            : null;
        })
        .filter(Boolean) as Array<{ id: string; name: string; teacherName: string; monthlyFee: number }>;

      // Find charges
      const studentCharges = db.charges.filter((c) => c.studentId === student.id);
      const totalCharges = studentCharges.reduce((acc, c) => acc + c.amount, 0);

      // Find valid payments
      const studentPayments = db.payments.filter(
        (p) => p.studentId === student.id && p.status === 'completed'
      );
      const totalPaid = studentPayments.reduce((acc, p) => acc + p.amountPaid, 0);
      const remainingBalance = Math.max(0, totalCharges - totalPaid);

      // Calculate attendance rate
      const studentAttendance = db.attendance.filter((a) => a.studentId === student.id);
      let attendanceRate = 100;
      if (studentAttendance.length > 0) {
        const presentCount = studentAttendance.filter(
          (a) => a.status === 'present' || a.status === 'excused'
        ).length;
        attendanceRate = Math.round((presentCount / studentAttendance.length) * 100);
      }

      return {
        ...student,
        totalCharges,
        totalPaid,
        remainingBalance,
        enrolledGroups,
        attendanceRate,
      };
    });
  }

  async getStudentById(id: string): Promise<StudentWithDetails | null> {
    const list = await this.getStudents();
    return list.find((s) => s.id === id) || null;
  }

  async addStudent(
    studentData: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }
  ): Promise<Student> {
    if (!this.hasPermission('students_manage') && !this.hasPermission('all')) {
      throw new Error('ليست لديك الصلاحية لإضافة تلاميذ جدد');
    }

    if (!studentData.fullName || !studentData.guardianName || !studentData.guardianPhone) {
      throw new Error('يرجى ملء جميع الحقول الإلزامية (اسم التلميذ، ولي الأمر، ورقم الهاتف)');
    }

    const db = await storageAdapter.getDatabase();
    const newId = 'stu-' + Date.now();
    const count = db.students.length + 1;
    const year = new Date().getFullYear();
    const code = `STU-${year}-${count.toString().padStart(3, '0')}`;

    const newStudent: Student = {
      id: newId,
      code,
      fullName: studentData.fullName.trim(),
      birthDate: studentData.birthDate,
      gender: studentData.gender || 'male',
      guardianName: studentData.guardianName.trim(),
      guardianPhone: studentData.guardianPhone.trim(),
      guardianRelation: studentData.guardianRelation || 'أب',
      address: studentData.address?.trim(),
      levelId: studentData.levelId,
      status: studentData.status || 'active',
      registrationDate: studentData.registrationDate || new Date().toISOString().substring(0, 10),
      notes: studentData.notes?.trim(),
    };

    db.students.push(newStudent);

    // Initial group enrollments
    if (studentData.initialGroupIds && studentData.initialGroupIds.length > 0) {
      for (const grpId of studentData.initialGroupIds) {
        const enrollment: StudentEnrollment = {
          id: 'enr-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          studentId: newId,
          groupId: grpId,
          enrollmentDate: newStudent.registrationDate,
          status: 'active',
        };
        db.enrollments.push(enrollment);

        // Automatically create registration fee charge and first month charge if group exists
        const grp = db.groups.find((g) => g.id === grpId);
        if (grp) {
          if (grp.registrationFee > 0) {
            db.charges.push({
              id: 'chg-' + Date.now() + '-reg',
              studentId: newId,
              groupId: grpId,
              type: 'registration',
              title: `رسوم التسجيل وتأمين المركز - ${grp.name}`,
              amount: grp.registrationFee,
              dueDate: newStudent.registrationDate,
              academicYear: grp.academicYear,
              status: 'unpaid',
              paidAmount: 0,
              remainingAmount: grp.registrationFee,
              createdAt: new Date().toISOString().substring(0, 10),
            });
          }
          if (grp.monthlyFee > 0) {
            const currentMonthStr = new Date().toISOString().substring(0, 7);
            db.charges.push({
              id: 'chg-' + Date.now() + '-m1',
              studentId: newId,
              groupId: grpId,
              type: 'monthly',
              title: `واجب شهر ${currentMonthStr} - ${grp.name}`,
              amount: grp.monthlyFee,
              dueDate: new Date().toISOString().substring(0, 10),
              academicYear: grp.academicYear,
              periodMonth: currentMonthStr,
              status: 'unpaid',
              paidAmount: 0,
              remainingAmount: grp.monthlyFee,
              createdAt: new Date().toISOString().substring(0, 10),
            });
          }
        }
      }
    }

    await this.addLog(db, 'إضافة تلميذ جديد', 'student', newId, `تم تسجيل التلميذ ${newStudent.fullName} برقم ${code}`);
    await storageAdapter.saveDatabase(db);
    return newStudent;
  }

  async updateStudent(id: string, updates: Partial<Student>): Promise<Student> {
    if (!this.hasPermission('students_manage') && !this.hasPermission('all')) {
      throw new Error('ليست لديك الصلاحية لتعديل بيانات التلميذ');
    }

    const db = await storageAdapter.getDatabase();
    const index = db.students.findIndex((s) => s.id === id);
    if (index === -1) {
      throw new Error('التلميذ غير موجود');
    }

    const existing = db.students[index];
    const updated: Student = {
      ...existing,
      ...updates,
      id: existing.id,
      code: existing.code, // never overwrite immutable code
    };

    db.students[index] = updated;
    await this.addLog(db, 'تعديل بيانات تلميذ', 'student', id, `تعديل ملف التلميذ ${updated.fullName}`);
    await storageAdapter.saveDatabase(db);
    return updated;
  }

  async toggleStudentStatus(id: string, status: Student['status']): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === id);
    if (!student) throw new Error('التلميذ غير موجود');

    student.status = status;
    const statusLabel = status === 'active' ? 'نشط' : status === 'suspended' ? 'موقوف مؤقتاً' : 'غير نشط';
    await this.addLog(db, 'تغيير حالة التلميذ', 'student', id, `تغيير حالة التلميذ ${student.fullName} إلى: ${statusLabel}`);
    await storageAdapter.saveDatabase(db);
  }

  async deleteStudent(id: string): Promise<void> {
    if (!this.hasPermission('all') && this.currentUser.role !== 'director') {
      throw new Error('حذف التلميذ نهائياً مقتصر على مدير المؤسسة فقط');
    }

    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === id);
    if (!student) throw new Error('التلميذ غير موجود');

    // Check if student has valid completed payments
    const studentPayments = db.payments.filter((p) => p.studentId === id && p.status === 'completed');
    if (studentPayments.length > 0) {
      throw new Error(
        `لا يمكن حذف التلميذ ${student.fullName} نهائياً لوجود ${studentPayments.length} وصل مالي مسجل باسمه. لحفظ الأثر المحاسبي يمكنك تحويل حالته إلى "موقوف مؤقتاً" أو "غير نشط".`
      );
    }

    // Safe deletion: remove orphan enrollments, charges, attendance
    db.students = db.students.filter((s) => s.id !== id);
    db.enrollments = db.enrollments.filter((e) => e.studentId !== id);
    db.charges = db.charges.filter((c) => c.studentId !== id);
    db.attendance = db.attendance.filter((a) => a.studentId !== id);

    await this.addLog(db, 'حذف تلميذ', 'student', id, `تم حذف ملف التلميذ ${student.fullName}`);
    await storageAdapter.saveDatabase(db);
  }

  // ==========================================
  // GROUPS & ENROLLMENTS MODULE
  // ==========================================
  async getLevels(): Promise<Level[]> {
    const db = await storageAdapter.getDatabase();
    return db.levels.sort((a, b) => a.orderIndex - b.orderIndex);
  }

  async addLevel(level: Omit<Level, 'id'>): Promise<Level> {
    const db = await storageAdapter.getDatabase();
    const newLevel: Level = {
      ...level,
      id: 'lvl-' + Date.now(),
    };
    db.levels.push(newLevel);
    await storageAdapter.saveDatabase(db);
    return newLevel;
  }

  async getSubjects(): Promise<Subject[]> {
    const db = await storageAdapter.getDatabase();
    return db.subjects;
  }

  async addSubject(subject: Omit<Subject, 'id'>): Promise<Subject> {
    const db = await storageAdapter.getDatabase();
    const newSubject: Subject = {
      ...subject,
      id: 'sub-' + Date.now(),
      isActive: subject.isActive ?? true,
    };
    db.subjects.push(newSubject);
    await this.addLog(db, 'إضافة فرع / لغة جديدة', 'settings', newSubject.id, `إضافة فرع دراسي جديد: ${newSubject.name}`);
    await storageAdapter.saveDatabase(db);
    return newSubject;
  }

  async updateSubject(id: string, updates: Partial<Subject>): Promise<Subject> {
    const db = await storageAdapter.getDatabase();
    const idx = db.subjects.findIndex((s) => s.id === id);
    if (idx === -1) throw new Error('الفرع / المادة غير موجودة');

    const updated = { ...db.subjects[idx], ...updates, id };
    db.subjects[idx] = updated;
    await this.addLog(db, 'تعديل فرع / مادة', 'settings', id, `تعديل بيانات فرع: ${updated.name}`);
    await storageAdapter.saveDatabase(db);
    return updated;
  }

  async deleteSubject(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const subject = db.subjects.find((s) => s.id === id);
    if (!subject) throw new Error('الفرع / المادة غير موجودة');

    // Check if groups are associated
    const associatedGroups = db.groups.filter((g) => g.subjectId === id);
    if (associatedGroups.length > 0) {
      // Check if any group has students
      const groupIds = new Set(associatedGroups.map((g) => g.id));
      const hasEnrolled = db.enrollments.some((e) => groupIds.has(e.groupId) && e.status === 'active');
      if (hasEnrolled) {
        throw new Error(`تعذر حذف فرع "${subject.name}" لوجود تلاميذ مسجلين حالياً في أفواجه. يرجى نقل أو إلغاء تسجيل التلاميذ أولاً.`);
      }
      // If no students, remove the empty groups as well
      db.groups = db.groups.filter((g) => g.subjectId !== id);
    }

    db.subjects = db.subjects.filter((s) => s.id !== id);
    await this.addLog(db, 'حذف فرع / مادة', 'settings', id, `حذف فرع: ${subject.name}`);
    await storageAdapter.saveDatabase(db);
  }

  async deleteGroup(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const group = db.groups.find((g) => g.id === id);
    if (!group) throw new Error('المجموعة الدراسية غير موجودة');

    // Check if any students are enrolled
    const activeEnrollments = db.enrollments.filter((e) => e.groupId === id && e.status === 'active');
    if (activeEnrollments.length > 0) {
      throw new Error(`لا يمكن حذف الفوج "${group.name}" لوجود ${activeEnrollments.length} تلميذ مسجل به. يرجى نقل التلاميذ إلى فوج آخر أولاً.`);
    }

    db.groups = db.groups.filter((g) => g.id !== id);
    db.enrollments = db.enrollments.filter((e) => e.groupId !== id);
    await this.addLog(db, 'حذف فوج دراسي', 'group', id, `حذف الفوج الدراسي: ${group.name}`);
    await storageAdapter.saveDatabase(db);
  }

  async getSubjectBranches(): Promise<SubjectBranchSummary[]> {
    const db = await storageAdapter.getDatabase();
    const subjects = db.subjects;

    return subjects.map((sub) => {
      const groups = db.groups.filter((g) => g.subjectId === sub.id);
      const groupIds = new Set(groups.map((g) => g.id));

      const enrolledStudentIds = new Set(
        db.enrollments
          .filter((e) => groupIds.has(e.groupId) && e.status === 'active')
          .map((e) => e.studentId)
      );

      const weeklySessionsCount = groups.reduce((acc, g) => acc + (g.schedule ? g.schedule.length : 0), 0);
      const monthlyRevenueProjected = groups.reduce((acc, g) => {
        const studentCountInGroup = db.enrollments.filter((e) => e.groupId === g.id && e.status === 'active').length;
        return acc + (studentCountInGroup * (g.monthlyFee || 0));
      }, 0);

      const teachers = Array.from(new Set(groups.map((g) => g.teacherName).filter(Boolean)));
      if (sub.teacherDefault && !teachers.includes(sub.teacherDefault)) {
        teachers.unshift(sub.teacherDefault);
      }

      return {
        subject: sub,
        groupsCount: groups.length,
        studentsCount: enrolledStudentIds.size,
        weeklySessionsCount,
        monthlyRevenueProjected,
        teachers,
      };
    });
  }

  async clearAllDummyData(): Promise<void> {
    await storageAdapter.clearTransactionalData();
  }

  async getGroups(levelId?: string): Promise<Array<StudyGroup & { enrolledCount: number; levelName: string; subjectName: string }>> {
    const db = await storageAdapter.getDatabase();
    let result = db.groups;
    if (levelId) {
      result = result.filter((g) => g.levelId === levelId);
    }

    return result.map((group) => {
      const enrolledCount = db.enrollments.filter(
        (e) => e.groupId === group.id && e.status === 'active'
      ).length;
      const level = db.levels.find((l) => l.id === group.levelId);
      const subject = db.subjects.find((s) => s.id === group.subjectId);

      return {
        ...group,
        enrolledCount,
        levelName: level ? level.name : 'غير محدد',
        subjectName: subject ? subject.name : 'عام',
      };
    });
  }

  async addGroup(groupData: Omit<StudyGroup, 'id'>): Promise<StudyGroup> {
    const db = await storageAdapter.getDatabase();
    const newGroup: StudyGroup = {
      ...groupData,
      id: 'grp-' + Date.now(),
    };
    db.groups.push(newGroup);
    await this.addLog(db, 'إنشاء مجموعة دراسية', 'group', newGroup.id, `إنشاء المجموعة ${newGroup.name} مع الأستاذ ${newGroup.teacherName}`);
    await storageAdapter.saveDatabase(db);
    return newGroup;
  }

  async updateGroup(id: string, updates: Partial<StudyGroup>): Promise<StudyGroup> {
    const db = await storageAdapter.getDatabase();
    const idx = db.groups.findIndex((g) => g.id === id);
    if (idx === -1) throw new Error('المجموعة غير موجودة');

    const updated = { ...db.groups[idx], ...updates, id };
    db.groups[idx] = updated;
    await this.addLog(db, 'تعديل مجموعة دراسية', 'group', id, `تعديل إعدادات المجموعة ${updated.name}`);
    await storageAdapter.saveDatabase(db);
    return updated;
  }

  async enrollStudent(studentId: string, groupId: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === studentId);
    const group = db.groups.find((g) => g.id === groupId);
    if (!student || !group) throw new Error('بيانات التلميذ أو المجموعة غير صحيحة');

    // Check duplicate
    const existing = db.enrollments.find(
      (e) => e.studentId === studentId && e.groupId === groupId && e.status === 'active'
    );
    if (existing) {
      throw new Error(`التلميذ ${student.fullName} مسجل بالفعل في مجموعة "${group.name}".`);
    }

    // Check capacity
    const currentCount = db.enrollments.filter(
      (e) => e.groupId === groupId && e.status === 'active'
    ).length;
    if (currentCount >= group.maxCapacity) {
      throw new Error(`تعذر التسجيل: اكتملت الطاقة الاستيعابية القصوى للمجموعة (${group.maxCapacity} تلميذ).`);
    }

    db.enrollments.push({
      id: 'enr-' + Date.now(),
      studentId,
      groupId,
      enrollmentDate: new Date().toISOString().substring(0, 10),
      status: 'active',
    });

    await this.addLog(
      db,
      'إسناد تلميذ إلى مجموعة',
      'student',
      studentId,
      `إسناد التلميذ ${student.fullName} إلى المجموعة ${group.name}`
    );
    await storageAdapter.saveDatabase(db);
  }

  async transferStudent(
    studentId: string,
    fromGroupId: string,
    toGroupId: string,
    reason: string
  ): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === studentId);
    const fromGrp = db.groups.find((g) => g.id === fromGroupId);
    const toGrp = db.groups.find((g) => g.id === toGroupId);

    if (!student || !fromGrp || !toGrp) throw new Error('بيانات التحويل غير صالحة');

    // Mark previous enrollment as transferred
    const oldEnr = db.enrollments.find(
      (e) => e.studentId === studentId && e.groupId === fromGroupId && e.status === 'active'
    );
    if (oldEnr) {
      oldEnr.status = 'transferred';
      oldEnr.transferReason = reason;
    }

    // Add new enrollment
    db.enrollments.push({
      id: 'enr-' + Date.now(),
      studentId,
      groupId: toGroupId,
      enrollmentDate: new Date().toISOString().substring(0, 10),
      status: 'active',
    });

    await this.addLog(
      db,
      'تحويل تلميذ بين مجموعتين',
      'student',
      studentId,
      `تحويل التلميذ ${student.fullName} من فوج "${fromGrp.name}" إلى فوج "${toGrp.name}". السبب: ${reason || 'طلب التلميذ/ولي الأمر'}`
    );
    await storageAdapter.saveDatabase(db);
  }

  async unenrollStudent(studentId: string, groupId: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === studentId);
    const grp = db.groups.find((g) => g.id === groupId);

    db.enrollments = db.enrollments.filter(
      (e) => !(e.studentId === studentId && e.groupId === groupId)
    );

    if (student && grp) {
      await this.addLog(
        db,
        'إلغاء تسجيل تلميذ من فوج',
        'student',
        studentId,
        `إلغاء تسجيل التلميذ ${student.fullName} من فوج "${grp.name}"`
      );
    }
    await storageAdapter.saveDatabase(db);
  }

  // ==========================================
  // FINANCIAL MODULE (CHARGES & PAYMENTS)
  // ==========================================
  async getCharges(studentId?: string): Promise<FeeCharge[]> {
    const db = await storageAdapter.getDatabase();
    let res = db.charges;
    if (studentId) {
      res = res.filter((c) => c.studentId === studentId);
    }
    return res.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  }

  async addCharge(chargeData: Omit<FeeCharge, 'id' | 'paidAmount' | 'remainingAmount' | 'status' | 'createdAt'>): Promise<FeeCharge> {
    if (chargeData.amount <= 0) {
      throw new Error('يجب أن يكون مبلغ الاستحقاق أكبر من 0');
    }

    const db = await storageAdapter.getDatabase();
    const newCharge: FeeCharge = {
      ...chargeData,
      id: 'chg-' + Date.now(),
      paidAmount: 0,
      remainingAmount: chargeData.amount,
      status: 'unpaid',
      createdAt: new Date().toISOString().substring(0, 10),
    };

    db.charges.push(newCharge);
    await storageAdapter.saveDatabase(db);
    return newCharge;
  }

  async getPayments(filters?: {
    studentId?: string;
    startDate?: string;
    endDate?: string;
    receiptNumber?: string;
  }): Promise<Array<Payment & { studentName: string; studentCode: string; levelName: string }>> {
    const db = await storageAdapter.getDatabase();
    let res = db.payments;

    if (filters?.studentId) {
      res = res.filter((p) => p.studentId === filters.studentId);
    }
    if (filters?.startDate) {
      res = res.filter((p) => p.paymentDate >= filters.startDate!);
    }
    if (filters?.endDate) {
      res = res.filter((p) => p.paymentDate <= filters.endDate!);
    }
    if (filters?.receiptNumber) {
      const q = filters.receiptNumber.trim().toLowerCase();
      res = res.filter((p) => p.receiptNumber.toLowerCase().includes(q));
    }

    return res
      .map((p) => {
        const student = db.students.find((s) => s.id === p.studentId);
        const level = student ? db.levels.find((l) => l.id === student.levelId) : null;
        return {
          ...p,
          studentName: student ? student.fullName : 'تلميذ محذوف',
          studentCode: student ? student.code : '---',
          levelName: level ? level.name : '---',
        };
      })
      .sort((a, b) => b.paymentDate.localeCompare(a.paymentDate));
  }

  async recordPayment(paymentData: {
    studentId: string;
    chargeId?: string;
    amountPaid: number;
    paymentMethod: Payment['paymentMethod'];
    referenceNumber?: string;
    notes?: string;
    itemsCovered: string;
  }): Promise<Payment> {
    if (!this.hasPermission('finance_record') && !this.hasPermission('all')) {
      throw new Error('ليست لديك الصلاحية لتسجيل الأداءات المالية');
    }

    if (!paymentData.studentId) {
      throw new Error('يرجى تحديد التلميذ المعني بالعملية المالية');
    }

    if (!paymentData.amountPaid || paymentData.amountPaid <= 0) {
      throw new Error('مبلغ الأداء يجب أن يكون أكبر من 0 درهم');
    }

    const db = await storageAdapter.getDatabase();
    const student = db.students.find((s) => s.id === paymentData.studentId);
    if (!student) throw new Error('التلميذ غير موجود');

    // Calculate current student balance before payment
    const studentCharges = db.charges.filter((c) => c.studentId === student.id);
    const totalCharges = studentCharges.reduce((acc, c) => acc + c.amount, 0);
    const validPayments = db.payments.filter(
      (p) => p.studentId === student.id && p.status === 'completed'
    );
    const totalPaidBefore = validPayments.reduce((acc, p) => acc + p.amountPaid, 0);
    const previousBalance = Math.max(0, totalCharges - totalPaidBefore);

    // Calculate remaining balance after payment
    const remainingBalanceAfter = Math.max(0, previousBalance - paymentData.amountPaid);

    // Generate unique serial receipt number
    const prefix = db.settings.receiptPrefix || 'REC';
    const currentYear = new Date().getFullYear();
    const nextSeq = db.settings.receiptNextNumber || 1;
    const receiptNumber = `${prefix}-${currentYear}-${nextSeq.toString().padStart(4, '0')}`;

    // Increment receipt number sequence in settings
    db.settings.receiptNextNumber = nextSeq + 1;

    const payment: Payment = {
      id: 'pay-' + Date.now(),
      receiptNumber,
      studentId: paymentData.studentId,
      chargeId: paymentData.chargeId,
      amountPaid: paymentData.amountPaid,
      previousBalance,
      remainingBalanceAfter,
      paymentDate: new Date().toISOString().substring(0, 10),
      paymentMethod: paymentData.paymentMethod,
      referenceNumber: paymentData.referenceNumber?.trim(),
      notes: paymentData.notes?.trim(),
      recordedBy: this.currentUser.fullName,
      status: 'completed',
      itemsCovered: paymentData.itemsCovered.trim(),
    };

    // If payment is linked to a specific charge, update the charge
    if (paymentData.chargeId) {
      const charge = db.charges.find((c) => c.id === paymentData.chargeId);
      if (charge) {
        charge.paidAmount += paymentData.amountPaid;
        charge.remainingAmount = Math.max(0, charge.amount - charge.paidAmount);
        charge.status = charge.remainingAmount === 0 ? 'paid' : charge.paidAmount > 0 ? 'partial' : 'unpaid';
      }
    } else {
      // Allocate payment towards unpaid charges FIFO
      let remainingToAllocate = paymentData.amountPaid;
      for (const chg of studentCharges.filter((c) => c.status !== 'paid')) {
        if (remainingToAllocate <= 0) break;
        const unpaidOnCharge = chg.remainingAmount;
        if (remainingToAllocate >= unpaidOnCharge) {
          chg.paidAmount += unpaidOnCharge;
          chg.remainingAmount = 0;
          chg.status = 'paid';
          remainingToAllocate -= unpaidOnCharge;
        } else {
          chg.paidAmount += remainingToAllocate;
          chg.remainingAmount -= remainingToAllocate;
          chg.status = 'partial';
          remainingToAllocate = 0;
        }
      }
    }

    db.payments.unshift(payment);

    await this.addLog(
      db,
      'تسجيل أداء مالي',
      'payment',
      payment.id,
      `إصدار وصل ${receiptNumber} بمبلغ ${payment.amountPaid} درهم للتلميذ ${student.fullName} (${payment.paymentMethod})`
    );

    await storageAdapter.saveDatabase(db);
    return payment;
  }

  async cancelPayment(paymentId: string, reason: string): Promise<Payment> {
    if (!this.hasPermission('finance_cancel') && !this.hasPermission('all')) {
      throw new Error('ليست لديك الصلاحية لإلغاء أو تصحيح العمليات المالية');
    }

    if (!reason || reason.trim().length < 5) {
      throw new Error('يرجى كتابة سبب مفصل لإلغاء العملية المالية لتوثيق الأثر المحاسبي');
    }

    const db = await storageAdapter.getDatabase();
    const payment = db.payments.find((p) => p.id === paymentId);
    if (!payment) throw new Error('الوصل المالي غير موجود');
    if (payment.status === 'cancelled') throw new Error('هذا الوصل ملغى مسبقاً');

    const student = db.students.find((s) => s.id === payment.studentId);

    // Rollback linked charge allocation
    if (payment.chargeId) {
      const charge = db.charges.find((c) => c.id === payment.chargeId);
      if (charge) {
        charge.paidAmount = Math.max(0, charge.paidAmount - payment.amountPaid);
        charge.remainingAmount = Math.max(0, charge.amount - charge.paidAmount);
        charge.status = charge.paidAmount === 0 ? 'unpaid' : charge.remainingAmount === 0 ? 'paid' : 'partial';
      }
    }

    payment.status = 'cancelled';
    payment.cancellationReason = reason.trim();
    payment.cancelledAt = new Date().toISOString().substring(0, 16);
    payment.cancelledBy = this.currentUser.fullName;

    await this.addLog(
      db,
      'إلغاء وصل مالي',
      'payment',
      paymentId,
      `إلغاء الوصل ${payment.receiptNumber} بقيمة ${payment.amountPaid} درهم. السبب: ${reason}`
    );

    await storageAdapter.saveDatabase(db);
    return payment;
  }

  // ==========================================
  // EXPENSES MODULE
  // ==========================================
  async getExpenses(category?: Expense['category']): Promise<Expense[]> {
    const db = await storageAdapter.getDatabase();
    let res = db.expenses;
    if (category) {
      res = res.filter((e) => e.category === category);
    }
    return res.sort((a, b) => b.date.localeCompare(a.date));
  }

  async addExpense(expenseData: Omit<Expense, 'id' | 'recordedBy'>): Promise<Expense> {
    if (expenseData.amount <= 0) {
      throw new Error('مبلغ المصروف يجب أن يكون أكبر من 0');
    }

    const db = await storageAdapter.getDatabase();
    const newExpense: Expense = {
      ...expenseData,
      id: 'exp-' + Date.now(),
      recordedBy: this.currentUser.fullName,
    };

    db.expenses.unshift(newExpense);
    await this.addLog(
      db,
      'تسجيل مصروف جديد',
      'expense',
      newExpense.id,
      `تسجيل مصروف "${newExpense.title}" بمبلغ ${newExpense.amount} درهم (${newExpense.category})`
    );
    await storageAdapter.saveDatabase(db);
    return newExpense;
  }

  async deleteExpense(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const exp = db.expenses.find((e) => e.id === id);
    if (!exp) throw new Error('المصروف غير موجود');

    db.expenses = db.expenses.filter((e) => e.id !== id);
    await this.addLog(db, 'حذف مصروف', 'expense', id, `حذف المصروف "${exp.title}" بمبلغ ${exp.amount} درهم`);
    await storageAdapter.saveDatabase(db);
  }

  // ==========================================
  // ATTENDANCE MODULE
  // ==========================================
  async getAttendanceByGroupAndDate(groupId: string, date: string): Promise<AttendanceRecord[]> {
    const db = await storageAdapter.getDatabase();
    return db.attendance.filter((a) => a.groupId === groupId && a.sessionDate === date);
  }

  async getStudentAbsences(studentId: string): Promise<Array<AttendanceRecord & { groupName?: string }>> {
    const db = await storageAdapter.getDatabase();
    const records = db.attendance.filter(
      (a) => a.studentId === studentId && (a.status === 'absent' || a.status === 'late')
    );
    return records.map((r) => {
      const grp = db.groups.find((g) => g.id === r.groupId);
      return { ...r, groupName: grp?.name };
    });
  }

  async saveAttendanceBatch(
    groupId: string,
    date: string,
    sessionTime: string,
    records: Array<{ studentId: string; status: AttendanceRecord['status']; notes?: string }>
  ): Promise<void> {
    const db = await storageAdapter.getDatabase();
    const now = new Date().toISOString().substring(0, 16);

    for (const item of records) {
      const existingIdx = db.attendance.findIndex(
        (a) => a.groupId === groupId && a.studentId === item.studentId && a.sessionDate === date
      );

      if (existingIdx !== -1) {
        db.attendance[existingIdx].status = item.status;
        db.attendance[existingIdx].notes = item.notes;
        db.attendance[existingIdx].updatedAt = now;
        db.attendance[existingIdx].recordedBy = this.currentUser.fullName;
      } else {
        db.attendance.push({
          id: 'att-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          groupId,
          studentId: item.studentId,
          sessionDate: date,
          sessionTime,
          status: item.status,
          notes: item.notes,
          recordedBy: this.currentUser.fullName,
          updatedAt: now,
        });
      }
    }

    const grp = db.groups.find((g) => g.id === groupId);
    await this.addLog(
      db,
      'تسجيل حضور حصة',
      'attendance',
      groupId,
      `تسجيل حضور ${records.length} تلميذاً في فوج "${grp ? grp.name : groupId}" بتاريخ ${date}`
    );
    await storageAdapter.saveDatabase(db);
  }

  // ==========================================
  // FINANCIAL STATS & SUMMARY
  // ==========================================
  async getFinancialStats(): Promise<FinancialStats> {
    const db = await storageAdapter.getDatabase();
    const today = new Date().toISOString().substring(0, 10);
    const thisMonth = today.substring(0, 7);

    const validPayments = db.payments.filter((p) => p.status === 'completed');

    let collectedToday = 0;
    let collectedThisMonth = 0;
    let totalCollected = 0;
    let paymentCountThisMonth = 0;

    for (const p of validPayments) {
      totalCollected += p.amountPaid;
      if (p.paymentDate === today) {
        collectedToday += p.amountPaid;
      }
      if (p.paymentDate.startsWith(thisMonth)) {
        collectedThisMonth += p.amountPaid;
        paymentCountThisMonth++;
      }
    }

    const totalCharges = db.charges.reduce((acc, c) => acc + c.amount, 0);
    const totalRemainingDue = Math.max(0, totalCharges - totalCollected);

    const totalExpenses = db.expenses.reduce((acc, e) => acc + e.amount, 0);
    const netCashflow = totalCollected - totalExpenses;

    return {
      collectedToday,
      collectedThisMonth,
      totalCollected,
      totalRemainingDue,
      totalExpenses,
      netCashflow,
      paymentCountThisMonth,
    };
  }

  async getDashboardAnalytics(): Promise<DashboardAnalytics> {
    const db = await storageAdapter.getDatabase();

    // 1. Monthly Financial Trends for past 6 months
    const monthNamesArabic = ['يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو', 'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نوفمبر', 'دجنبر'];
    const now = new Date();
    const monthlyTrends: MonthlyFinanceTrend[] = [];

    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const yyyy = d.getFullYear();
      const mm = String(d.getMonth() + 1).padStart(2, '0');
      const monthKey = `${yyyy}-${mm}`;
      const monthName = `${monthNamesArabic[d.getMonth()]}`;

      const rev = db.payments
        .filter((p) => p.status === 'completed' && p.paymentDate.startsWith(monthKey))
        .reduce((sum, p) => sum + p.amountPaid, 0);

      const exp = db.expenses
        .filter((e) => e.date.startsWith(monthKey))
        .reduce((sum, e) => sum + e.amount, 0);

      monthlyTrends.push({
        monthName,
        monthKey,
        revenue: rev,
        expenses: exp,
        net: rev - exp,
      });
    }

    // 2. Attendance Distribution
    const attList = db.attendance;
    const totalAtt = attList.length;
    const present = attList.filter((a) => a.status === 'present').length;
    const absent = attList.filter((a) => a.status === 'absent').length;
    const late = attList.filter((a) => a.status === 'late').length;
    const excused = attList.filter((a) => a.status === 'excused').length;

    const attendanceDistribution: AttendanceDistributionItem[] = [
      {
        name: 'حاضر',
        count: present,
        percentage: totalAtt > 0 ? Math.round((present / totalAtt) * 100) : 0,
        color: '#10b981', // Emerald
      },
      {
        name: 'غائب',
        count: absent,
        percentage: totalAtt > 0 ? Math.round((absent / totalAtt) * 100) : 0,
        color: '#ef4444', // Red
      },
      {
        name: 'متأخر',
        count: late,
        percentage: totalAtt > 0 ? Math.round((late / totalAtt) * 100) : 0,
        color: '#f59e0b', // Amber
      },
      {
        name: 'غياب مبرر',
        count: excused,
        percentage: totalAtt > 0 ? Math.round((excused / totalAtt) * 100) : 0,
        color: '#3b82f6', // Blue
      },
    ];

    const overallAttendanceRate = totalAtt > 0 ? Math.round(((present + excused) / totalAtt) * 100) : 100;

    // 3. Subject / Branch Analytics
    const subjectAnalytics: SubjectAnalyticsItem[] = db.subjects.map((sub) => {
      const subGroups = db.groups.filter((g) => g.subjectId === sub.id);
      const subGroupIds = new Set(subGroups.map((g) => g.id));
      const enrolledStudentIds = new Set(
        db.enrollments
          .filter((e) => subGroupIds.has(e.groupId) && e.status === 'active')
          .map((e) => e.studentId)
      );

      const revenue = db.payments
        .filter((p) => p.status === 'completed' && enrolledStudentIds.has(p.studentId))
        .reduce((sum, p) => sum + p.amountPaid, 0);

      return {
        id: sub.id,
        name: sub.name,
        code: sub.code || 'SUB',
        color: sub.color || '#4f46e5',
        studentsCount: enrolledStudentIds.size,
        groupsCount: subGroups.length,
        revenue,
      };
    });

    return {
      monthlyTrends,
      attendanceDistribution,
      subjectAnalytics,
      overallAttendanceRate,
      totalPresent: present,
      totalAbsent: absent,
      totalLate: late,
      totalExcused: excused,
    };
  }

  // ==========================================
  // CONNECTED DEVICES & COMPANION TABLETS
  // ==========================================
  async getDevices(): Promise<ConnectedDevice[]> {
    const db = await storageAdapter.getDatabase();
    return db.devices || [];
  }

  async addDevice(
    deviceData: Omit<ConnectedDevice, 'id' | 'createdAt' | 'pairingToken'>
  ): Promise<ConnectedDevice> {
    const db = await storageAdapter.getDatabase();
    if (!db.devices) db.devices = [];

    const token = 'DEV-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString(36).toUpperCase();
    const newDevice: ConnectedDevice = {
      ...deviceData,
      id: 'dev-' + Date.now(),
      pairingToken: token,
      createdAt: new Date().toISOString().substring(0, 10),
      status: 'active',
      lastSyncAt: undefined,
    };

    db.devices.push(newDevice);
    await this.addLog(
      db,
      'إضافة جهاز مرافق',
      'settings',
      newDevice.id,
      `ربط جهاز جديد "${newDevice.name}" (${newDevice.deviceType}) بكود PIN: ${newDevice.pinCode}`
    );
    await storageAdapter.saveDatabase(db);
    return newDevice;
  }

  async updateDevice(id: string, updates: Partial<ConnectedDevice>): Promise<ConnectedDevice> {
    const db = await storageAdapter.getDatabase();
    if (!db.devices) db.devices = [];
    const idx = db.devices.findIndex((d) => d.id === id);
    if (idx === -1) throw new Error('الجهاز غير مسجل بالمنظومة');

    const updated = { ...db.devices[idx], ...updates, id };
    db.devices[idx] = updated;
    await storageAdapter.saveDatabase(db);
    return updated;
  }

  async deleteDevice(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    if (!db.devices) db.devices = [];
    const dev = db.devices.find((d) => d.id === id);
    if (!dev) throw new Error('الجهاز غير موجود');

    db.devices = db.devices.filter((d) => d.id !== id);
    await this.addLog(db, 'إلغاء ربط جهاز', 'settings', id, `إلغاء الترخيص للجهاز: ${dev.name}`);
    await storageAdapter.saveDatabase(db);
  }

  async syncMobileAttendance(
    deviceToken: string,
    groupId: string,
    date: string,
    records: Array<{ studentId: string; status: AttendanceRecord['status']; notes?: string }>
  ): Promise<{ success: boolean; count: number; message: string }> {
    const db = await storageAdapter.getDatabase();
    if (!db.devices) db.devices = [];

    // Verify device
    const device = db.devices.find((d) => d.pairingToken === deviceToken && d.status === 'active');
    if (!device) {
      throw new Error('رمز مصادقة الجهاز غير صالح أو تم إلغاء ترخيصه من الحاسوب الرئيسي.');
    }

    const now = new Date().toISOString().substring(0, 16);
    device.lastSyncAt = now;

    // Apply attendance records
    for (const item of records) {
      const existingIdx = db.attendance.findIndex(
        (a) => a.groupId === groupId && a.studentId === item.studentId && a.sessionDate === date
      );

      if (existingIdx !== -1) {
        db.attendance[existingIdx].status = item.status;
        db.attendance[existingIdx].notes = item.notes;
        db.attendance[existingIdx].updatedAt = now;
        db.attendance[existingIdx].recordedBy = `${device.name} (عبر التابليت)`;
      } else {
        db.attendance.push({
          id: 'att-mob-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
          groupId,
          studentId: item.studentId,
          sessionDate: date,
          sessionTime: new Date().toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' }),
          status: item.status,
          notes: item.notes,
          recordedBy: `${device.name} (عبر التابليت)`,
          updatedAt: now,
        });
      }
    }

    const grp = db.groups.find((g) => g.id === groupId);
    await this.addLog(
      db,
      'مزامنة حضور من جهاز محمول',
      'attendance',
      groupId,
      `تمت مزامنة غياب ${records.length} تلميذ من جهاز "${device.name}" لفوج "${grp?.name || groupId}" بتاريخ ${date}`
    );

    await storageAdapter.saveDatabase(db);
    return {
      success: true,
      count: records.length,
      message: `تم تسجيل وحفظ الغياب في الحاسوب الرئيسي بنجاح (${records.length} تلميذ).`,
    };
  }

  // ==========================================
  // SETTINGS & LICENSE & USERS
  // ==========================================
  async getSettings(): Promise<CenterSettings> {
    const db = await storageAdapter.getDatabase();
    return db.settings;
  }

  async updateSettings(settings: Partial<CenterSettings>): Promise<CenterSettings> {
    const db = await storageAdapter.getDatabase();
    db.settings = { ...db.settings, ...settings };

    // تزامن تلقائي: عند تعديل اسم المدير العام، يتم تحديث اسم المستخدم الإداري تلقائياً في كامل النظام
    if (settings.directorName) {
      const trimmedName = settings.directorName.trim();
      const adminUser = db.users.find((u) => u.role === 'admin' || u.username === 'admin');
      if (adminUser) {
        adminUser.fullName = `${trimmedName} (المدير العام)`;
        if (this.currentUser.role === 'admin' || this.currentUser.username === 'admin') {
          this.currentUser = { ...this.currentUser, fullName: adminUser.fullName };
        }
      }
    }

    await this.addLog(db, 'تحديث إعدادات المركز', 'settings', '1', 'تعديل بيانات وشعار ومعلومات المركز');
    await storageAdapter.saveDatabase(db);
    return db.settings;
  }

  async getLicense(): Promise<LicenseInfo> {
    const db = await storageAdapter.getDatabase();
    if (!db.license) {
      db.license = {
        centerName: db.settings.centerName,
        licenseType: 'lifetime_commercial',
        issueDate: new Date().toISOString().substring(0, 10),
        machineFingerprint: generateMachineFingerprint(),
        isValid: true,
        maskedKey: 'ITQAN-92BA-••••-••••-71D4',
        activationSignature: 'ITQAN_PRO_VERIFIED_SIGNATURE_' + generateMachineFingerprint(),
      };
      await storageAdapter.saveDatabase(db);
    }

    // تأكد من وجود بصمة عتاد الجهاز
    if (!db.license.machineFingerprint) {
      db.license.machineFingerprint = generateMachineFingerprint();
      await storageAdapter.saveDatabase(db);
    }

    // حماية أمنية صارمة: لا يتم أبداً إعادة مفتاح صريح بل المفتاح المحجوب فقط
    const safeLicense: LicenseInfo = {
      centerName: db.license.centerName || db.settings.centerName,
      licenseType: db.license.licenseType || 'lifetime_commercial',
      issueDate: db.license.issueDate || new Date().toISOString().substring(0, 10),
      machineFingerprint: db.license.machineFingerprint,
      isValid: Boolean(db.license.isValid),
      activationSignature: db.license.activationSignature,
      maskedKey: db.license.maskedKey || (db.license.licenseKey ? maskLicenseKey(db.license.licenseKey) : 'ITQAN-PRO-••••-••••-VERIFIED'),
      activatedAt: db.license.activatedAt,
    };

    // إزالة أي مفتاح صريح قديم من قاعدة البيانات إن وُجد
    if (db.license.licenseKey) {
      delete db.license.licenseKey;
      await storageAdapter.saveDatabase(db);
    }

    return safeLicense;
  }

  async activateLicense(licenseKey: string, centerName: string): Promise<LicenseInfo> {
    const db = await storageAdapter.getDatabase();
    const machineId = db.license?.machineFingerprint || generateMachineFingerprint();
    
    // التحقق المشفر الأمني الصارم
    const verification = await verifyLicenseKey(licenseKey, centerName, machineId);
    if (!verification.isValid) {
      throw new Error(verification.message);
    }

    // حفظ البصمة والتوقيع فقط - لا يتم حفظ كود التفعيل الصريح أبداً لمنع سرقته
    db.license = {
      centerName: centerName.trim(),
      licenseType: 'lifetime_commercial',
      issueDate: new Date().toISOString().substring(0, 10),
      machineFingerprint: machineId,
      isValid: true,
      activationSignature: verification.signatureHash,
      maskedKey: verification.maskedKey,
      activatedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
    };

    await this.addLog(
      db,
      'تفعيل ترخيص البرنامج المشفر',
      'settings',
      'license',
      `تم التحقق من الترخيص المشفر وتفعيله بنجاح للمؤسسة: "${centerName}" على الجهاز: ${machineId}`
    );
    await storageAdapter.saveDatabase(db);
    return db.license;
  }

  async getUsers(): Promise<User[]> {
    const db = await storageAdapter.getDatabase();
    return db.users;
  }

  async getAuditLogs(): Promise<AuditLog[]> {
    const db = await storageAdapter.getDatabase();
    return db.auditLogs;
  }

  // ==========================================
  // WHATSAPP AUTOMATION URL GENERATORS
  // ==========================================
  getWhatsAppAttendanceUrl(student: Student, groupName: string, date: string, status: string, centerName: string): string {
    const rawPhone = student.guardianPhone || '';
    const cleanPhone = rawPhone.replace(/\D/g, '');
    let internationalPhone = cleanPhone;
    if (cleanPhone.startsWith('0') && cleanPhone.length === 10) {
      internationalPhone = '212' + cleanPhone.substring(1);
    }
    const statusText = status === 'absent' ? 'غائباً' : status === 'late' ? 'متأخراً' : 'حاضراً';
    const message = `السلام عليكم ورحمة الله،\nنحيطكم علماً من إدارة *${centerName}* بأن التلميذ(ة): *${student.fullName}*\nسُجل بتاريخ اليوم (${date}) *${statusText}* عن حصة فوج: *${groupName}*.\nيرجى التواصل مع الإدارة عند الحاجة لأي توضيح أو تبرير. شكراً لحسن تعاونكم.`;
    return `https://wa.me/${internationalPhone}?text=${encodeURIComponent(message)}`;
  }

  getWhatsAppDebtReminderUrl(student: Student, balance: number, centerName: string, currency: string): string {
    const rawPhone = student.guardianPhone || '';
    const cleanPhone = rawPhone.replace(/\D/g, '');
    let internationalPhone = cleanPhone;
    if (cleanPhone.startsWith('0') && cleanPhone.length === 10) {
      internationalPhone = '212' + cleanPhone.substring(1);
    }
    const message = `السلام عليكم ورحمة الله،\nتحية تقدير من إدارة *${centerName}*.\nنود تذكيركم بلطف بأن واجبات التمدرس الشهرية الخاصة بالتلميذ(ة): *${student.fullName}* تتضمن مبلغاً مستحقاً قدره: *${balance} ${currency}*.\nنرجو منكم التفضل بتسوية الحساب عند زيارتكم المقبلة للإدارة. شاكرين حسن ثقتكم بمؤسستنا.`;
    return `https://wa.me/${internationalPhone}?text=${encodeURIComponent(message)}`;
  }

  getWhatsAppReceiptUrl(student: Student, payment: Payment, centerName: string, currency: string): string {
    const rawPhone = student.guardianPhone || '';
    const cleanPhone = rawPhone.replace(/\D/g, '');
    let internationalPhone = cleanPhone;
    if (cleanPhone.startsWith('0') && cleanPhone.length === 10) {
      internationalPhone = '212' + cleanPhone.substring(1);
    }
    const message = `السلام عليكم ورحمة الله،\nوصل أداء إلكتروني رسمي من *${centerName}*:\nتم بنجاح استلام أداء مالي للتلميذ(ة): *${student.fullName}*\n- رقم الوصل: *${payment.receiptNumber}*\n- المبلغ المؤدى: *${payment.amountPaid} ${currency}*\n- تفاصيل الأداء: ${payment.itemsCovered}\n- التاريخ: ${payment.paymentDate}\n- الرصيد المتبقي: ${payment.remainingBalanceAfter} ${currency}\nشكراً لثقتكم بمؤسستنا.`;
    return `https://wa.me/${internationalPhone}?text=${encodeURIComponent(message)}`;
  }

  // ==========================================
  // TEACHERS & PAYROLL MODULE
  // ==========================================
  async getTeachers(): Promise<Teacher[]> {
    const db = await storageAdapter.getDatabase();
    return db.teachers || [];
  }

  async addTeacher(teacherData: Omit<Teacher, 'id' | 'joinedAt'>): Promise<Teacher> {
    const db = await storageAdapter.getDatabase();
    if (!db.teachers) db.teachers = [];
    const newTeacher: Teacher = {
      ...teacherData,
      id: 'tch-' + Date.now(),
      joinedAt: new Date().toISOString().substring(0, 10),
    };
    db.teachers.push(newTeacher);
    await this.addLog(db, 'إضافة أستاذ جديد', 'teacher', newTeacher.id, `إضافة الأستاذ(ة): ${newTeacher.name} (${newTeacher.specialty})`);
    await storageAdapter.saveDatabase(db);
    return newTeacher;
  }

  async updateTeacher(id: string, updates: Partial<Teacher>): Promise<Teacher> {
    const db = await storageAdapter.getDatabase();
    if (!db.teachers) db.teachers = [];
    const idx = db.teachers.findIndex((t) => t.id === id);
    if (idx === -1) throw new Error('الأستاذ غير موجود');
    const updated = { ...db.teachers[idx], ...updates, id };
    db.teachers[idx] = updated;
    await storageAdapter.saveDatabase(db);
    return updated;
  }

  async deleteTeacher(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    if (!db.teachers) db.teachers = [];
    const teacher = db.teachers.find((t) => t.id === id);
    if (!teacher) throw new Error('الأستاذ غير موجود');
    db.teachers = db.teachers.filter((t) => t.id !== id);
    await this.addLog(db, 'حذف أستاذ', 'teacher', id, `حذف الأستاذ: ${teacher.name}`);
    await storageAdapter.saveDatabase(db);
  }

  async calculateTeacherEarnings(teacherId: string, monthKey: string): Promise<{
    teacher: Teacher;
    estimatedEarnings: number;
    groupsTaught: Array<{ id: string; name: string; revenue: number; studentCount: number }>;
    totalGroupRevenue: number;
    sessionsCount: number;
    paymentsAlreadyMade: number;
    remainingDue: number;
  }> {
    const db = await storageAdapter.getDatabase();
    const teacher = (db.teachers || []).find((t) => t.id === teacherId);
    if (!teacher) throw new Error('الأستاذ غير موجود');

    // Find groups assigned to this teacher
    const groupsTaught = db.groups.filter((g) => g.teacherName?.trim() === teacher.name?.trim());
    let totalGroupRevenue = 0;
    const groupsBreakdown = groupsTaught.map((grp) => {
      const enrolledStudentIds = new Set(
        db.enrollments.filter((e) => e.groupId === grp.id && e.status === 'active').map((e) => e.studentId)
      );
      const grpPayments = db.payments
        .filter((p) => p.status === 'completed' && p.paymentDate.startsWith(monthKey) && enrolledStudentIds.has(p.studentId))
        .reduce((sum, p) => sum + p.amountPaid, 0);
      totalGroupRevenue += grpPayments;
      return {
        id: grp.id,
        name: grp.name,
        revenue: grpPayments,
        studentCount: enrolledStudentIds.size,
      };
    });

    const sessionsInMonth = groupsTaught.reduce((acc, g) => acc + (g.schedule?.length || 0) * 4, 0);

    let estimatedEarnings = 0;
    if (teacher.compensationType === 'percentage') {
      estimatedEarnings = Math.round((totalGroupRevenue * (teacher.rate || 0)) / 100);
    } else if (teacher.compensationType === 'hourly') {
      estimatedEarnings = Math.round((teacher.rate || 0) * Math.max(1, sessionsInMonth * 1.5));
    } else {
      estimatedEarnings = teacher.rate || 0;
    }

    const paymentsAlreadyMade = (db.teacherPayments || [])
      .filter((tp) => tp.teacherId === teacherId && tp.month === monthKey)
      .reduce((sum, tp) => sum + tp.amount, 0);

    const remainingDue = Math.max(0, estimatedEarnings - paymentsAlreadyMade);

    return {
      teacher,
      estimatedEarnings,
      groupsTaught: groupsBreakdown,
      totalGroupRevenue,
      sessionsCount: sessionsInMonth,
      paymentsAlreadyMade,
      remainingDue,
    };
  }

  async recordTeacherPayment(data: {
    teacherId: string;
    teacherName: string;
    month: string;
    amount: number;
    details: string;
  }): Promise<TeacherPaymentRecord> {
    const db = await storageAdapter.getDatabase();
    if (!db.teacherPayments) db.teacherPayments = [];
    if (!db.expenses) db.expenses = [];

    const receiptNum = 'TCH-REC-' + Date.now().toString().slice(-6);
    const newRecord: TeacherPaymentRecord = {
      id: 'tp-' + Date.now(),
      teacherId: data.teacherId,
      teacherName: data.teacherName,
      month: data.month,
      amount: data.amount,
      paymentDate: new Date().toISOString().substring(0, 10),
      details: data.details,
      recordedBy: this.currentUser.fullName,
      receiptNumber: receiptNum,
    };
    db.teacherPayments.unshift(newRecord);

    // Automatically record an official expense in Treasury
    const expenseRecord: Expense = {
      id: 'exp-tch-' + Date.now(),
      title: `أتعاب الأستاذ ${data.teacherName} - شهر ${data.month}`,
      category: 'salaries',
      amount: data.amount,
      date: new Date().toISOString().substring(0, 10),
      paymentMethod: 'cash',
      beneficiary: data.teacherName,
      referenceDoc: receiptNum,
      notes: data.details,
      recordedBy: this.currentUser.fullName,
    };
    db.expenses.unshift(expenseRecord);

    await this.addLog(
      db,
      'صرف مستحقات أستاذ',
      'teacher',
      newRecord.id,
      `صرف مبلغ ${data.amount} ${db.settings.currency} للأستاذ ${data.teacherName} عن شهر ${data.month}`
    );
    await storageAdapter.saveDatabase(db);
    return newRecord;
  }

  async getTeacherPayments(teacherId?: string): Promise<TeacherPaymentRecord[]> {
    const db = await storageAdapter.getDatabase();
    const payments = db.teacherPayments || [];
    if (teacherId) {
      return payments.filter((p) => p.teacherId === teacherId);
    }
    return payments;
  }

  // ==========================================
  // GRADES & STUDENT EVALUATIONS MODULE
  // ==========================================
  async getGrades(filters?: { studentId?: string; groupId?: string; subjectId?: string }): Promise<GradeRecord[]> {
    const db = await storageAdapter.getDatabase();
    let res = db.grades || [];
    if (filters?.studentId) res = res.filter((g) => g.studentId === filters.studentId);
    if (filters?.groupId) res = res.filter((g) => g.groupId === filters.groupId);
    if (filters?.subjectId) res = res.filter((g) => g.subjectId === filters.subjectId);
    return res;
  }

  async saveGradesBatch(records: Array<Omit<GradeRecord, 'id'>>): Promise<void> {
    const db = await storageAdapter.getDatabase();
    if (!db.grades) db.grades = [];
    for (const rec of records) {
      const existingIdx = db.grades.findIndex(
        (g) => g.studentId === rec.studentId && g.groupId === rec.groupId && g.evaluationTitle === rec.evaluationTitle
      );
      if (existingIdx !== -1) {
        db.grades[existingIdx] = { ...rec, id: db.grades[existingIdx].id };
      } else {
        db.grades.push({ ...rec, id: 'grd-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6) });
      }
    }
    await this.addLog(db, 'تسجيل نقط وتقييمات', 'grade', 'batch', `تسجيل نقط وتقييمات لـ ${records.length} تلميذ`);
    await storageAdapter.saveDatabase(db);
  }

  async deleteGrade(id: string): Promise<void> {
    const db = await storageAdapter.getDatabase();
    if (!db.grades) db.grades = [];
    db.grades = db.grades.filter((g) => g.id !== id);
    await storageAdapter.saveDatabase(db);
  }

  // ==========================================
  // DAILY CASH CLOSURES (CLÔTURE DE CAISSE)
  // ==========================================
  async getCashClosures(): Promise<DailyCashClosure[]> {
    const db = await storageAdapter.getDatabase();
    return db.cashClosures || [];
  }

  async calculateTodayCashSummary(dateStr?: string): Promise<{
    date: string;
    totalCashIncome: number;
    totalCashExpense: number;
    netCashChange: number;
    paymentTransactionsCount: number;
    expenseTransactionsCount: number;
    lastClosure?: DailyCashClosure;
  }> {
    const db = await storageAdapter.getDatabase();
    const today = dateStr || new Date().toISOString().substring(0, 10);
    const todayCashPayments = db.payments.filter(
      (p) => p.status === 'completed' && p.paymentDate.startsWith(today) && p.paymentMethod === 'cash'
    );
    const totalCashIncome = todayCashPayments.reduce((sum, p) => sum + p.amountPaid, 0);

    const todayCashExpenses = db.expenses.filter(
      (e) => e.date.startsWith(today) && e.paymentMethod === 'cash'
    );
    const totalCashExpense = todayCashExpenses.reduce((sum, e) => sum + e.amount, 0);

    const lastClosure = (db.cashClosures || []).find((c) => c.date === today);

    return {
      date: today,
      totalCashIncome,
      totalCashExpense,
      netCashChange: totalCashIncome - totalCashExpense,
      paymentTransactionsCount: todayCashPayments.length,
      expenseTransactionsCount: todayCashExpenses.length,
      lastClosure,
    };
  }

  async recordDailyCashClosure(data: {
    date: string;
    openingCash: number;
    actualCashInDrawer: number;
    notes?: string;
  }): Promise<DailyCashClosure> {
    const db = await storageAdapter.getDatabase();
    if (!db.cashClosures) db.cashClosures = [];

    const summary = await this.calculateTodayCashSummary(data.date);
    const expectedCash = data.openingCash + summary.netCashChange;
    const discrepancy = data.actualCashInDrawer - expectedCash;

    const newClosure: DailyCashClosure = {
      id: 'cls-' + Date.now(),
      date: data.date,
      closedAt: new Date().toISOString().replace('T', ' ').substring(0, 16),
      closedByUserId: this.currentUser.id,
      closedByUserName: this.currentUser.fullName,
      openingCash: data.openingCash,
      totalCashIncome: summary.totalCashIncome,
      totalCashExpense: summary.totalCashExpense,
      expectedCashInDrawer: expectedCash,
      actualCashInDrawer: data.actualCashInDrawer,
      discrepancy,
      notes: data.notes,
    };

    const existingIdx = db.cashClosures.findIndex((c) => c.date === data.date);
    if (existingIdx !== -1) {
      db.cashClosures[existingIdx] = newClosure;
    } else {
      db.cashClosures.unshift(newClosure);
    }

    await this.addLog(
      db,
      'إغلاق الصندوق اليومي',
      'caisse',
      newClosure.id,
      `إغلاق صندوق ${data.date}: المتوقع=${expectedCash} د.م، الفعلي=${data.actualCashInDrawer} د.م (الفارق: ${discrepancy} د.م)`
    );
    await storageAdapter.saveDatabase(db);
    return newClosure;
  }

  // ==========================================
  // EXCEL / CSV EXPORT UTILITIES
  // ==========================================
  exportStudentsToCSV(students: StudentWithDetails[]): string {
    const headers = ['رمز التلميذ', 'الاسم الكامل', 'تاريخ الميلاد', 'المستوى الدراسي', 'الأفواج المسجلة', 'ولي الأمر', 'رقم الهاتف', 'تاريخ التسجيل', 'المبلغ المؤدى', 'الديون المتبقية', 'الحالة'];
    const rows = students.map((s) => [
      `"${s.code}"`,
      `"${s.fullName}"`,
      `"${s.birthDate || ''}"`,
      `"${s.levelId || ''}"`,
      `"${s.enrolledGroups.map((g) => g.name).join(' | ')}"`,
      `"${s.guardianName}"`,
      `"${s.guardianPhone}"`,
      `"${s.registrationDate}"`,
      s.totalPaid,
      s.remainingBalance,
      s.status === 'active' ? 'نشط' : 'متوقف',
    ]);
    return '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  exportDebtorsToCSV(debtors: StudentWithDetails[]): string {
    const headers = ['رمز التلميذ', 'اسم التلميذ', 'ولي الأمر', 'رقم الهاتف', 'الأفواج', 'مجموع المستحقات', 'المدفوع', 'المتبقي (دين)'];
    const rows = debtors.map((s) => [
      `"${s.code}"`,
      `"${s.fullName}"`,
      `"${s.guardianName}"`,
      `"${s.guardianPhone}"`,
      `"${s.enrolledGroups.map((g) => g.name).join(' | ')}"`,
      s.totalCharges,
      s.totalPaid,
      s.remainingBalance,
    ]);
    return '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
  }

  exportFinancialReportToCSV(payments: Payment[], expenses: Expense[], currency: string): string {
    const paymentRows = payments.map((p) => [
      `"مقبوضات"`,
      `"${p.paymentDate}"`,
      `"${p.receiptNumber}"`,
      `"${p.itemsCovered}"`,
      p.amountPaid,
      `"${p.paymentMethod}"`,
      `"${p.recordedBy}"`,
      p.status === 'completed' ? 'معتمد' : 'ملغى',
    ]);
    const expenseRows = expenses.map((e) => [
      `"مصروفات"`,
      `"${e.date}"`,
      `"${e.referenceDoc || '-'}"`,
      `"${e.title} (${e.category})"`,
      -e.amount,
      `"${e.paymentMethod}"`,
      `"${e.beneficiary || '-'}"`,
      'معتمد',
    ]);
    const headers = ['النوع', 'التاريخ', 'رقم الوصل', 'البيان والتفاصيل', `المبلغ (${currency})`, 'طريقة الأداء', 'المسؤول / المستفيد', 'الحالة'];
    return '\uFEFF' + [headers.join(','), ...paymentRows.map((r) => r.join(',')), ...expenseRows.map((r) => r.join(','))].join('\n');
  }
}

export const dataService = new DataService();
