/**
 * Tauri Desktop & SQLite Bridge Documentation and Helper
 * 
 * هذا الملف يشرح ويوفر الجسر البرمجي للتحويل إلى تطبيق سطح مكتب مستقل (Windows .exe)
 * باستخدام إطار عمل Tauri 2.0 وقاعدة بيانات SQLite 3 المحلية.
 */

export interface TauriConfigSummary {
  appName: string;
  version: string;
  identifier: string;
  windowsTarget: string;
  databasePath: string;
  isDesktopRuntime: boolean;
}

export const getTauriEnvironmentInfo = (): TauriConfigSummary => {
  const isDesktop = typeof window !== 'undefined' && Boolean((window as unknown as { __TAURI__?: unknown }).__TAURI__);
  
  return {
    appName: 'منظومة إتقان لإدارة المدارس والتقوية',
    version: '1.0.0',
    identifier: 'com.itqan.schoolmanager',
    windowsTarget: 'x86_64-pc-windows-msvc',
    databasePath: '%APPDATA%/com.itqan.schoolmanager/itqan_database.sqlite',
    isDesktopRuntime: isDesktop,
  };
};

/**
 * Tauri Command Bridge:
 * في بيئة سطح المكتب، يستدعي Rust command عبر invoke('execute_sqlite', { query, params })
 */
export async function executeTauriSqlite<T>(command: string, args: Record<string, unknown> = {}): Promise<T | null> {
  const tauri = (window as unknown as { __TAURI__?: { invoke: (cmd: string, args: Record<string, unknown>) => Promise<T> } }).__TAURI__;
  if (tauri && typeof tauri.invoke === 'function') {
    return await tauri.invoke(command, args);
  }
  // Fallback to web persistent adapter
  return null;
}
