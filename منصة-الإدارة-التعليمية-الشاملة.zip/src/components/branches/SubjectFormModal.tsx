import React, { useState, useEffect } from 'react';
import { Subject, Level } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { BookOpen, Palette, DollarSign, User, FileText, Check, Layers } from 'lucide-react';

interface SubjectFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Subject, 'id'>) => Promise<void>;
  subjectToEdit?: Subject | null;
  levels: Level[];
}

const COLOR_PRESETS = [
  { label: 'أحمر قرمزي', value: '#e11d48' },
  { label: 'أزرق كلاسيكي', value: '#2563eb' },
  { label: 'سماوي / تركواز', value: '#0891b2' },
  { label: 'أخضر زمردي', value: '#059669' },
  { label: 'برتقالي عنبري', value: '#d97706' },
  { label: 'بنفسجي ملكي', value: '#7c3aed' },
  { label: 'نيلي غامق', value: '#4f46e5' },
  { label: 'رمادي غرافيت', value: '#475569' },
];

export const SubjectFormModal: React.FC<SubjectFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  subjectToEdit,
  levels,
}) => {
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [department, setDepartment] = useState<'languages' | 'sciences' | 'humanities' | 'general'>('languages');
  const [teacherDefault, setTeacherDefault] = useState('');
  const [monthlyFeeDefault, setMonthlyFeeDefault] = useState<number | ''>(400);
  const [registrationFeeDefault, setRegistrationFeeDefault] = useState<number | ''>(200);
  const [color, setColor] = useState('#2563eb');
  const [description, setDescription] = useState('');
  const [levelId, setLevelId] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (subjectToEdit) {
      setName(subjectToEdit.name || '');
      setCode(subjectToEdit.code || '');
      setDepartment(subjectToEdit.department || 'languages');
      setTeacherDefault(subjectToEdit.teacherDefault || '');
      setMonthlyFeeDefault(subjectToEdit.monthlyFeeDefault ?? 400);
      setRegistrationFeeDefault(subjectToEdit.registrationFeeDefault ?? 200);
      setColor(subjectToEdit.color || '#2563eb');
      setDescription(subjectToEdit.description || '');
      setLevelId(subjectToEdit.levelId || '');
    } else {
      setName('');
      setCode('');
      setDepartment('languages');
      setTeacherDefault('');
      setMonthlyFeeDefault(400);
      setRegistrationFeeDefault(200);
      setColor('#e11d48');
      setDescription('');
      setLevelId('');
    }
    setError(null);
  }, [subjectToEdit, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('يرجى كتابة اسم الفرع أو اللغة (مثلاً: اللغة الألمانية)');
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);
      await onSubmit({
        name: name.trim(),
        code: code.trim().toUpperCase() || undefined,
        department,
        teacherDefault: teacherDefault.trim() || undefined,
        monthlyFeeDefault: Number(monthlyFeeDefault) || 0,
        registrationFeeDefault: Number(registrationFeeDefault) || 0,
        color,
        description: description.trim() || undefined,
        levelId: levelId || undefined,
        isActive: true,
      });
      onClose();
    } catch (err) {
      setError((err as Error).message || 'تعذر حفظ الفرع');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={subjectToEdit ? `تعديل فرع: ${subjectToEdit.name}` : 'إضافة لغة أو مادة دراسية جديدة (فرع مستقل)'}
      subtitle="إدارة فروع المؤسسة واللغات وتحديد الرسوم والأستاذ المسؤول بدون الحاجة لتعديل الكود"
      maxWidth="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
            {error}
          </div>
        )}

        {/* Basic Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2 space-y-1">
            <label className="block text-xs font-semibold text-slate-700">
              اسم الفرع أو اللغة <span className="text-red-500">*</span>
            </label>
            <div className="relative">
              <BookOpen className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="مثال: اللغة الألمانية، اللغة الإسبانية، الرياضيات..."
                className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-medium"
                required
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">رمز الفرع (اختياري)</label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value)}
              placeholder="مثال: DE, ES, MATH"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none uppercase font-mono"
            />
          </div>
        </div>

        {/* Department & Level */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">تصنيف المادة / الفرع</label>
            <select
              value={department}
              onChange={(e) => setDepartment(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="languages">لغات حية وأجنبية (ألمانية، إنجليزية، فرنسية...)</option>
              <option value="sciences">علوم دقيقة وتقنية (رياضيات، فيزياء، علوم...)</option>
              <option value="humanities">آداب وعلوم إنسانية وفلسفة</option>
              <option value="general">دعم مدرسي وتكوين عام</option>
            </select>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">المستوى الدراسي المرتبط</label>
            <select
              value={levelId}
              onChange={(e) => setLevelId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="">فرع عام مفتوح لجميع المستويات</option>
              {levels.map((lvl) => (
                <option key={lvl.id} value={lvl.id}>
                  {lvl.name} ({lvl.code})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Teacher & Financials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">الأستاذ المؤطر الافتراضي</label>
            <div className="relative">
              <User className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="text"
                value={teacherDefault}
                onChange={(e) => setTeacherDefault(e.target.value)}
                placeholder="اسم الأستاذ المسؤول"
                className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">الواجب الشهري المقترح (د.م)</label>
            <div className="relative">
              <DollarSign className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
              <input
                type="number"
                min="0"
                step="10"
                value={monthlyFeeDefault}
                onChange={(e) => setMonthlyFeeDefault(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="400"
                className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">رسوم التسجيل (د.م)</label>
            <input
              type="number"
              min="0"
              step="10"
              value={registrationFeeDefault}
              onChange={(e) => setRegistrationFeeDefault(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="200"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
            />
          </div>
        </div>

        {/* Color Palette */}
        <div className="space-y-1.5">
          <label className="block text-xs font-semibold text-slate-700">اللون المميز للفرع في اللوحات والجداول</label>
          <div className="flex flex-wrap items-center gap-2">
            {COLOR_PRESETS.map((preset) => {
              const isSelected = color === preset.value;
              return (
                <button
                  type="button"
                  key={preset.value}
                  onClick={() => setColor(preset.value)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-slate-800 ring-2 ring-slate-400/40 shadow-xs'
                      : 'border-slate-200 hover:border-slate-300 bg-white'
                  }`}
                >
                  <span
                    className="w-3.5 h-3.5 rounded-full inline-block shrink-0 shadow-xs"
                    style={{ backgroundColor: preset.value }}
                  />
                  <span className="text-[11px] text-slate-700">{preset.label}</span>
                  {isSelected && <Check className="w-3 h-3 text-slate-800" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Notes / Description */}
        <div className="space-y-1">
          <label className="block text-xs font-semibold text-slate-700">وصف الفرع وملاحظات التدريس</label>
          <textarea
            rows={2}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="مثال: تحضير امتحانات المستويات A1/B1، دعم مكثف في المحادثة والقواعد، متاح لعموم التلاميذ والمهتمين..."
            className="w-full p-2.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none resize-none"
          />
        </div>

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <Button variant="outline" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button variant="primary" size="sm" type="submit" disabled={isSubmitting}>
            {isSubmitting ? 'جارٍ الحفظ...' : subjectToEdit ? 'حفظ التعديلات' : 'إنشاء الفرع / المادة'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
