import React, { useState } from 'react';
import { Subject, StudyGroup, Level, StudentWithDetails, Student } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { UserPlus, UserCheck, Phone, User, Calendar, DollarSign, CheckCircle2 } from 'lucide-react';

interface QuickBranchEnrollModalProps {
  isOpen: boolean;
  onClose: () => void;
  subject: Subject;
  branchGroups: StudyGroup[];
  allStudents: StudentWithDetails[];
  levels: Level[];
  onEnrollExisting: (studentId: string, groupId: string) => Promise<void>;
  onAddNewAndEnroll: (studentData: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }) => Promise<void>;
}

export const QuickBranchEnrollModal: React.FC<QuickBranchEnrollModalProps> = ({
  isOpen,
  onClose,
  subject,
  branchGroups,
  allStudents,
  levels,
  onEnrollExisting,
  onAddNewAndEnroll,
}) => {
  const [tab, setTab] = useState<'new' | 'existing'>('new');
  const [selectedGroupId, setSelectedGroupId] = useState(branchGroups[0]?.id || '');

  // New Student State
  const [fullName, setFullName] = useState('');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [guardianRelation, setGuardianRelation] = useState<'أب' | 'أم' | 'ولي أمر'>('أب');
  const [levelId, setLevelId] = useState(subject.levelId || levels[0]?.id || '');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [address, setAddress] = useState('');
  const [notes, setNotes] = useState('');

  // Existing Student State
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [searchStudent, setSearchStudent] = useState('');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Sync selected group if branchGroups change
  React.useEffect(() => {
    if (branchGroups.length > 0 && !selectedGroupId) {
      setSelectedGroupId(branchGroups[0].id);
    }
  }, [branchGroups, selectedGroupId]);

  // Filter existing students who are NOT already enrolled in this group
  const existingFiltered = allStudents.filter((stu) => {
    const notInGroup = !stu.enrolledGroups.some((g) => g.id === selectedGroupId);
    if (!searchStudent.trim()) return notInGroup;
    const q = searchStudent.toLowerCase();
    return notInGroup && (stu.fullName.toLowerCase().includes(q) || stu.guardianPhone.includes(q) || stu.code.toLowerCase().includes(q));
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGroupId) {
      setError('يرجى اختيار الفوج أو الحصة المراد التسجيل بها');
      return;
    }

    try {
      setIsSubmitting(true);
      setError(null);

      if (tab === 'new') {
        if (!fullName.trim() || !guardianName.trim() || !guardianPhone.trim()) {
          setError('يرجى ملء جميع الحقول الإلزامية (اسم التلميذ، ولي الأمر، والهاتف)');
          return;
        }

        await onAddNewAndEnroll({
          fullName: fullName.trim(),
          guardianName: guardianName.trim(),
          guardianPhone: guardianPhone.trim(),
          guardianRelation,
          levelId,
          gender,
          address: address.trim() || undefined,
          status: 'active',
          registrationDate: new Date().toISOString().substring(0, 10),
          notes: notes.trim() || `تسجيل مباشر في فرع ${subject.name}`,
          initialGroupIds: [selectedGroupId],
        });
      } else {
        if (!selectedStudentId) {
          setError('يرجى اختيار التلميذ المراد إضافته لهذا الفرع');
          return;
        }
        await onEnrollExisting(selectedStudentId, selectedGroupId);
      }

      onClose();
    } catch (err) {
      setError((err as Error).message || 'تعذر تسجيل التلميذ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentGroup = branchGroups.find((g) => g.id === selectedGroupId);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`إضافة تلميذ إلى فرع: ${subject.name}`}
      subtitle="تسجيل فوري مباشر دون تعقيد إداري مع ربط الفوج والواجبات المالية تلقائياً"
      maxWidth="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 text-red-700 text-xs rounded-lg">
            {error}
          </div>
        )}

        {/* Target Group Selector */}
        <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
          <label className="block text-xs font-bold text-slate-800">
            حدد الفوج / الحصة التابعة لفرع {subject.name}:
          </label>
          {branchGroups.length === 0 ? (
            <div className="p-2.5 bg-amber-50 border border-amber-200 text-amber-800 text-xs rounded-lg">
              لا توجد أفواج حالياً في هذا الفرع. يرجى إنشاء فوج أولاً عبر زر "+ إنشاء فوج جديد للفرع".
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {branchGroups.map((grp) => {
                const isSelected = selectedGroupId === grp.id;
                return (
                  <button
                    type="button"
                    key={grp.id}
                    onClick={() => setSelectedGroupId(grp.id)}
                    className={`p-2.5 rounded-lg border text-right transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-white border-indigo-600 ring-2 ring-indigo-500/20 shadow-xs'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs text-slate-900">{grp.name}</span>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-600" />}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 flex items-center justify-between">
                      <span>الأستاذ: {grp.teacherName}</span>
                      <span className="font-mono font-semibold text-slate-700">{grp.monthlyFee} د.م/شهر</span>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Tab Toggle: New Student vs Existing Student */}
        <div className="flex border-b border-slate-200 text-xs font-semibold">
          <button
            type="button"
            onClick={() => setTab('new')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 transition-colors cursor-pointer ${
              tab === 'new'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" />
            تسجيل تلميذ جديد بالكامل
          </button>
          <button
            type="button"
            onClick={() => setTab('existing')}
            className={`flex items-center gap-1.5 px-4 py-2 border-b-2 transition-colors cursor-pointer ${
              tab === 'existing'
                ? 'border-indigo-600 text-indigo-600'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5" />
            إضافة تلميذ مسجل مسبقاً بالمؤسسة ({allStudents.length})
          </button>
        </div>

        {tab === 'new' ? (
          /* New Student Form */
          <div className="space-y-3">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">
                  اسم التلميذ(ة) الكامل <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="مثال: يوسف المنصوري"
                    className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">المستوى الدراسي</label>
                <select
                  value={levelId}
                  onChange={(e) => setLevelId(e.target.value)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  {levels.map((lvl) => (
                    <option key={lvl.id} value={lvl.id}>
                      {lvl.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">
                  اسم ولي الأمر <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={guardianName}
                  onChange={(e) => setGuardianName(e.target.value)}
                  placeholder="مثال: رشيد المنصوري"
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">
                  رقم هاتف ولي الأمر (واتساب) <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                  <input
                    type="tel"
                    dir="ltr"
                    value={guardianPhone}
                    onChange={(e) => setGuardianPhone(e.target.value)}
                    placeholder="06XX XX XX XX"
                    className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-right"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">صلة القرابة</label>
                <select
                  value={guardianRelation}
                  onChange={(e) => setGuardianRelation(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                >
                  <option value="أب">أب</option>
                  <option value="أم">أم</option>
                  <option value="ولي أمر">ولي أمر</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">الجنس</label>
                <div className="flex gap-4 pt-1">
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="quick_gender"
                      checked={gender === 'male'}
                      onChange={() => setGender('male')}
                    />
                    <span>ذكر (تلميذ)</span>
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer">
                    <input
                      type="radio"
                      name="quick_gender"
                      checked={gender === 'female'}
                      onChange={() => setGender('female')}
                    />
                    <span>أنثى (تلميذة)</span>
                  </label>
                </div>
              </div>

              <div className="space-y-1">
                <label className="block text-xs font-semibold text-slate-700">ملاحظات خاصة</label>
                <input
                  type="text"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="ملاحظات حول التلميذ أو الهدف من دراسة اللغة..."
                  className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>
          </div>
        ) : (
          /* Existing Student Picker */
          <div className="space-y-3">
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-700">البحث بالاسم أو الهاتف أو الرمز:</label>
              <input
                type="text"
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                placeholder="ابحث عن التلميذ..."
                className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="max-h-52 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
              {existingFiltered.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500">
                  {allStudents.length === 0
                    ? 'لا يوجد تلاميذ مسجلون في المؤسسة بعد. استخدم خيار "تسجيل تلميذ جديد بالكامل".'
                    : 'لا يوجد تلميذ يطابق بحثك أو جميع التلاميذ مسجلون مسبقاً في هذا الفوج.'}
                </div>
              ) : (
                existingFiltered.map((stu) => {
                  const isSelected = selectedStudentId === stu.id;
                  return (
                    <button
                      type="button"
                      key={stu.id}
                      onClick={() => setSelectedStudentId(stu.id)}
                      className={`w-full p-2.5 text-right flex items-center justify-between transition-colors cursor-pointer ${
                        isSelected ? 'bg-indigo-50/70 text-indigo-950 font-semibold' : 'hover:bg-slate-50 text-slate-800'
                      }`}
                    >
                      <div>
                        <div className="text-xs font-bold">{stu.fullName}</div>
                        <div className="text-[11px] text-slate-500">
                          {stu.code} • ولي الأمر: {stu.guardianName} ({stu.guardianPhone})
                        </div>
                      </div>
                      {isSelected && <CheckCircle2 className="w-4 h-4 text-indigo-600 shrink-0" />}
                    </button>
                  );
                })
              )}
            </div>
          </div>
        )}

        {/* Financial Notice */}
        {currentGroup && (
          <div className="p-2.5 bg-blue-50/80 border border-blue-200 text-blue-900 text-xs rounded-lg flex items-center justify-between">
            <span>الرسوم المستحقة عند التسجيل في هذا الفوج:</span>
            <span className="font-mono font-bold">
              {currentGroup.monthlyFee} د.م شهرياً {currentGroup.registrationFee > 0 ? `+ ${currentGroup.registrationFee} د.م تسجيل` : ''}
            </span>
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
          <Button variant="outline" size="sm" type="button" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button
            variant="primary"
            size="sm"
            type="submit"
            disabled={isSubmitting || branchGroups.length === 0}
            icon={<UserPlus className="w-3.5 h-3.5" />}
          >
            {isSubmitting ? 'جارٍ التسجيل...' : `تأكيد تسجيل التلميذ في ${subject.name}`}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
