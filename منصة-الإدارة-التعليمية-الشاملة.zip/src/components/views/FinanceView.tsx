import React, { useState } from 'react';
import { Payment, StudentWithDetails, CenterSettings } from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import {
  CreditCard,
  Search,
  Printer,
  Ban,
  Download,
  Filter,
  ArrowUpRight,
  Receipt,
  Banknote,
  Building,
  CheckCircle,
  FileCheck,
  AlertTriangle,
} from 'lucide-react';

interface FinanceViewProps {
  payments: Array<Payment & { studentName: string; studentCode: string; levelName: string }>;
  students: StudentWithDetails[];
  settings: CenterSettings;
  onOpenNewPaymentModal: () => void;
  onPrintPayment: (payment: Payment) => void;
  onCancelPayment: (payment: Payment) => void;
}

export const FinanceView: React.FC<FinanceViewProps> = ({
  payments,
  students,
  settings,
  onOpenNewPaymentModal,
  onPrintPayment,
  onCancelPayment,
}) => {
  const [search, setSearch] = useState('');
  const [activeMethodTab, setActiveMethodTab] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'cancelled'>('all');

  const filtered = payments.filter((p) => {
    if (activeMethodTab !== 'all' && p.paymentMethod !== activeMethodTab) return false;
    if (statusFilter !== 'all' && p.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      const matchReceipt = p.receiptNumber.toLowerCase().includes(q);
      const matchName = p.studentName.toLowerCase().includes(q);
      const matchItems = p.itemsCovered.toLowerCase().includes(q);
      const matchCode = p.studentCode.toLowerCase().includes(q);
      if (!matchReceipt && !matchName && !matchItems && !matchCode) return false;
    }
    return true;
  });

  const totalCompleted = filtered
    .filter((p) => p.status === 'completed')
    .reduce((acc, p) => acc + p.amountPaid, 0);

  const cashTotal = payments
    .filter((p) => p.status === 'completed' && p.paymentMethod === 'cash')
    .reduce((acc, p) => acc + p.amountPaid, 0);

  const transferTotal = payments
    .filter((p) => p.status === 'completed' && (p.paymentMethod === 'transfer' || p.paymentMethod === 'cheque'))
    .reduce((acc, p) => acc + p.amountPaid, 0);

  const cancelledCount = payments.filter((p) => p.status === 'cancelled').length;

  const exportCSV = () => {
    const headers = [
      'رقم الوصل',
      'تاريخ الأداء',
      'التلميذ',
      'الرمز',
      'المستوى',
      'طريقة الأداء',
      'المرجع',
      'المبلغ المؤدى',
      'المتبقي بعده',
      'المستلم',
      'الحالة',
    ];
    const rows = filtered.map((p) => [
      p.receiptNumber,
      p.paymentDate,
      p.studentName,
      p.studentCode,
      p.levelName,
      p.paymentMethod,
      p.referenceNumber || '',
      p.amountPaid,
      p.remainingBalanceAfter,
      p.recordedBy,
      p.status === 'completed' ? 'معتمد' : 'ملغى',
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.map((cell) => `"${cell}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `itqan_receipts_${new Date().toISOString().substring(0, 10)}.csv`;
    document.body.appendChild(link);
    link.click();
    URL.revokeObjectURL(url);
  };

  const methodBadge: Record<string, { label: string; color: string }> = {
    cash: { label: 'نقداً (Cash)', color: 'bg-emerald-50 text-emerald-800 border-emerald-200' },
    transfer: { label: 'تحويل بنكي (Virement)', color: 'bg-blue-50 text-blue-800 border-blue-200' },
    cheque: { label: 'شيك بنكي (Chèque)', color: 'bg-indigo-50 text-indigo-800 border-indigo-200' },
    card: { label: 'بطاقة مصرفية', color: 'bg-purple-50 text-purple-800 border-purple-200' },
    other: { label: 'أخرى', color: 'bg-slate-50 text-slate-800 border-slate-200' },
  };

  return (
    <div className="space-y-5">
      {/* 1. Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <Receipt className="w-5 h-5 text-indigo-600" />
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              الأداءات وسجل الوصولات المالية
            </h2>
            <span className="bg-emerald-100 text-emerald-800 text-xs font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 font-mono">
              {filtered.length} وصل
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            سجل المداخيل، طباعة الوصولات الرسمية بتنسيق A4 المزدوج والطابعات الحرارية، وتتبع الخزينة
          </p>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            icon={<Download className="w-4 h-4 text-slate-600" />}
            onClick={exportCSV}
          >
            تصدير كشف Excel
          </Button>

          <Button
            variant="primary"
            size="sm"
            icon={<CreditCard className="w-4 h-4 text-white" />}
            onClick={onOpenNewPaymentModal}
            className="shadow-sm shadow-indigo-600/30 font-bold"
          >
            تسجيل أداء مالي وإصدار وصل
          </Button>
        </div>
      </div>

      {/* 2. Top Financial Ledger Metric Strips */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            المجموع المحصل في هذا العرض
          </span>
          <div className="text-2xl font-black text-emerald-700 font-mono tabular-nums">
            {totalCompleted.toFixed(2)} {settings.currency}
          </div>
          <span className="text-[10px] text-slate-400 block">
            {filtered.filter((p) => p.status === 'completed').length} وصل معتمد
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            إجمالي السيولة النقدية (Cash)
          </span>
          <div className="text-2xl font-black text-slate-900 font-mono tabular-nums">
            {cashTotal.toFixed(2)} {settings.currency}
          </div>
          <span className="text-[10px] text-emerald-600 font-medium block">
            موجودة بصندوق الاستقبال
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            التحويلات والشيكات البنكية
          </span>
          <div className="text-2xl font-black text-blue-700 font-mono tabular-nums">
            {transferTotal.toFixed(2)} {settings.currency}
          </div>
          <span className="text-[10px] text-slate-400 block">
            مودعة بالحساب البنكي للمركز
          </span>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
            الوصولات الملغاة (Audit)
          </span>
          <div className="text-2xl font-black text-rose-600 font-mono tabular-nums">
            {cancelledCount} وصولات
          </div>
          <span className="text-[10px] text-slate-400 block">
            تم إرجاع مبالغها وموثقة بأسباب الإلغاء
          </span>
        </div>
      </div>

      {/* 3. Method Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        <button
          type="button"
          onClick={() => setActiveMethodTab('all')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
            activeMethodTab === 'all'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          كافة طرق الأداء
        </button>
        <button
          type="button"
          onClick={() => setActiveMethodTab('cash')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeMethodTab === 'cash'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Banknote className="w-3.5 h-3.5" />
          <span>نقداً (Cash)</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveMethodTab('transfer')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeMethodTab === 'transfer'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <Building className="w-3.5 h-3.5" />
          <span>تحويل بنكي</span>
        </button>
        <button
          type="button"
          onClick={() => setActiveMethodTab('cheque')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center gap-1.5 ${
            activeMethodTab === 'cheque'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <FileCheck className="w-3.5 h-3.5" />
          <span>شيك بنكي</span>
        </button>
      </div>

      {/* 4. Search and Status Row */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث برقم الوصل (REC-...)، اسم التلميذ، أو بيان الرسوم..."
              className="w-full pr-9 pl-4 py-2 text-xs bg-slate-50 hover:bg-white focus:bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>

          <div className="sm:col-span-4">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="all">كافة الحالات (المعتمدة والملغاة)</option>
              <option value="completed">الوصولات المعتمدة فقط</option>
              <option value="cancelled">الوصولات الملغاة فقط</option>
            </select>
          </div>
        </div>
      </div>

      {/* 5. Payments Ledger Table */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300 text-slate-500 space-y-3">
          <Receipt className="w-12 h-12 mx-auto text-slate-300" />
          <p className="text-base font-bold text-slate-800">لا توجد وصولات تطابق البحث المحدد</p>
          <p className="text-xs text-slate-400">تأكد من شروط البحث أو الفلاتر المختارة أعلاه.</p>
          <Button variant="primary" size="sm" onClick={onOpenNewPaymentModal}>
            تسجيل أداء جديد الآن
          </Button>
        </div>
      ) : (
        <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-2xs">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
              <tr>
                <th className="py-3 px-3">رقم الوصل</th>
                <th className="py-3 px-3">تاريخ الأداء</th>
                <th className="py-3 px-3">التلميذ المستفيد</th>
                <th className="py-3 px-3">المستوى</th>
                <th className="py-3 px-3">بيان الرسوم المغطاة</th>
                <th className="py-3 px-3">طريقة الأداء</th>
                <th className="py-3 px-3">المبلغ المؤدى</th>
                <th className="py-3 px-3">المتبقي بذمته</th>
                <th className="py-3 px-3">المستلم</th>
                <th className="py-3 px-3">الحالة</th>
                <th className="py-3 px-3 text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((p) => {
                const isCancelled = p.status === 'cancelled';
                const methodInfo = methodBadge[p.paymentMethod] || methodBadge.other;

                return (
                  <tr
                    key={p.id}
                    className={`transition-colors ${
                      isCancelled
                        ? 'bg-rose-50/40 text-slate-400 line-through'
                        : 'hover:bg-slate-50/80 text-slate-800'
                    }`}
                  >
                    <td className="py-3 px-3">
                      <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-200">
                        {p.receiptNumber}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono text-slate-500">{p.paymentDate}</td>
                    <td className="py-3 px-3 font-bold text-slate-900">
                      <div>{p.studentName}</div>
                      <div className="font-mono text-[10px] text-slate-400 font-normal">
                        {p.studentCode}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600">{p.levelName}</td>
                    <td className="py-3 px-3 max-w-[200px] truncate text-slate-600">
                      {p.itemsCovered}
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${methodInfo.color}`}
                      >
                        {methodInfo.label}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono font-black text-emerald-700 text-sm tabular-nums">
                      {p.amountPaid.toFixed(2)} {settings.currency}
                    </td>
                    <td className="py-3 px-3 font-mono font-bold tabular-nums">
                      <span
                        className={
                          p.remainingBalanceAfter > 0 ? 'text-amber-700' : 'text-slate-400'
                        }
                      >
                        {p.remainingBalanceAfter.toFixed(2)} {settings.currency}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-[11px] text-slate-500 font-medium">
                      {p.recordedBy}
                    </td>
                    <td className="py-3 px-3">
                      {isCancelled ? (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 border border-rose-200">
                          ملغى
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200">
                          معتمد
                        </span>
                      )}
                    </td>
                    <td className="py-3 px-3 text-left">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          type="button"
                          onClick={() => onPrintPayment(p)}
                          className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                          title="طباعة الوصل المالي"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                        {!isCancelled && (
                          <button
                            type="button"
                            onClick={() => onCancelPayment(p)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="إلغاء هذا الوصل المالي"
                          >
                            <Ban className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
