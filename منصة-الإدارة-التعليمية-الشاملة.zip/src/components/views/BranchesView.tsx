import React, { useState } from 'react';
import {
  Subject,
  StudyGroup,
  StudentWithDetails,
  Level,
  CenterSettings,
  Student,
} from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import {
  BookOpen,
  Plus,
  Users,
  Calendar,
  Clock,
  DollarSign,
  ArrowRight,
  GraduationCap,
  Sparkles,
  School,
  Edit2,
  Trash2,
  CheckCircle,
  AlertCircle,
  UserPlus,
  Printer,
  CreditCard,
  Languages,
  Layers,
  ChevronLeft,
  Search,
  Phone,
  MessageCircle,
  FileText,
  UserMinus,
  CheckCircle2,
  XCircle,
} from 'lucide-react';
import { SubjectFormModal } from '../branches/SubjectFormModal';
import { QuickBranchEnrollModal } from '../branches/QuickBranchEnrollModal';
import { ConfirmDialog } from '../common/ConfirmDialog';

interface BranchesViewProps {
  subjects: Subject[];
  groups: Array<StudyGroup & { enrolledCount: number; levelName: string; subjectName: string }>;
  students: StudentWithDetails[];
  levels: Level[];
  settings: CenterSettings;
  onAddSubject: (subject: Omit<Subject, 'id'>) => Promise<void>;
  onUpdateSubject: (id: string, updates: Partial<Subject>) => Promise<void>;
  onDeleteSubject: (id: string) => Promise<void>;
  onOpenNewGroupForSubject: (subjectId: string) => void;
  onOpenEditGroupModal: (group: StudyGroup) => void;
  onEnrollExistingStudent: (studentId: string, groupId: string) => Promise<void>;
  onAddNewStudentAndEnroll: (studentData: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }) => Promise<void>;
  onSelectStudentProfile: (student: StudentWithDetails) => void;
  onOpenPaymentModal: (student: StudentWithDetails) => void;
  onPrintStudentCard: (student: StudentWithDetails) => void;
  onTakeAttendance: (groupId: string) => void;
  onUnenrollStudent?: (studentId: string, groupId: string) => Promise<void>;
}

export const BranchesView: React.FC<BranchesViewProps> = ({
  subjects,
  groups,
  students,
  levels,
  settings,
  onAddSubject,
  onUpdateSubject,
  onDeleteSubject,
  onOpenNewGroupForSubject,
  onOpenEditGroupModal,
  onEnrollExistingStudent,
  onAddNewStudentAndEnroll,
  onSelectStudentProfile,
  onOpenPaymentModal,
  onPrintStudentCard,
  onTakeAttendance,
  onUnenrollStudent,
}) => {
  // Navigation State (الهيكل الهرمي 3 مستويات: المادة ⬅️ الفوج ⬅️ التلاميذ)
  // Level 1: null, null
  // Level 2: activeBranchId, null
  // Level 3: activeBranchId, activeGroupId
  const [activeBranchId, setActiveBranchId] = useState<string | null>(null);
  const [activeGroupId, setActiveGroupId] = useState<string | null>(null);

  // Filters & Searches
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [branchSearch, setBranchSearch] = useState<string>('');
  const [studentSearchInBranch, setStudentSearchInBranch] = useState<string>('');
  const [studentSearchInGroup, setStudentSearchInGroup] = useState<string>('');

  // Subtab for Level 2 (المادة)
  const [branchSubTab, setBranchSubTab] = useState<'groups' | 'students' | 'schedule'>('groups');

  // Modals state
  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [subjectToEdit, setSubjectToEdit] = useState<Subject | null>(null);
  const [isQuickEnrollModalOpen, setIsQuickEnrollModalOpen] = useState(false);
  const [subjectToDelete, setSubjectToDelete] = useState<Subject | null>(null);
  const [isDeletingSubject, setIsDeletingSubject] = useState(false);
  const [subjectDeleteError, setSubjectDeleteError] = useState<string | null>(null);

  // Unenroll student confirm
  const [studentToUnenroll, setStudentToUnenroll] = useState<{ student: StudentWithDetails; group: StudyGroup } | null>(null);
  const [isUnenrolling, setIsUnenrolling] = useState(false);

  // Current Active Objects
  const activeSubject = subjects.find((s) => s.id === activeBranchId) || null;
  const activeBranchGroups = groups.filter((g) => g.subjectId === activeBranchId);
  const activeBranchGroupIds = new Set(activeBranchGroups.map((g) => g.id));
  const activeGroup = groups.find((g) => g.id === activeGroupId) || null;

  // Active Subject Students
  const activeBranchStudents = students.filter((stu) =>
    stu.enrolledGroups.some((g) => activeBranchGroupIds.has(g.id))
  );

  // Active Group Students (Level 3)
  const groupStudents = activeGroup
    ? students.filter((stu) => stu.enrolledGroups.some((g) => g.id === activeGroup.id))
    : [];

  const filteredGroupStudents = groupStudents.filter((stu) => {
    if (!studentSearchInGroup.trim()) return true;
    const q = studentSearchInGroup.toLowerCase();
    return (
      stu.fullName.toLowerCase().includes(q) ||
      stu.code.toLowerCase().includes(q) ||
      stu.guardianPhone.includes(q) ||
      stu.guardianName.toLowerCase().includes(q)
    );
  });

  const filteredBranchStudents = activeBranchStudents.filter((stu) => {
    if (!studentSearchInBranch.trim()) return true;
    const q = studentSearchInBranch.toLowerCase();
    return (
      stu.fullName.toLowerCase().includes(q) ||
      stu.code.toLowerCase().includes(q) ||
      stu.guardianPhone.includes(q) ||
      stu.guardianName.toLowerCase().includes(q)
    );
  });

  // Calculations for active branch
  const branchWeeklySessions = activeBranchGroups.reduce((acc, g) => acc + (g.schedule?.length || 0), 0);

  // Filtered branches list for Level 1
  const filteredSubjects = subjects.filter((sub) => {
    if (departmentFilter !== 'all' && sub.department !== departmentFilter) return false;
    if (branchSearch.trim()) {
      const q = branchSearch.toLowerCase();
      return (
        sub.name.toLowerCase().includes(q) ||
        (sub.code && sub.code.toLowerCase().includes(q)) ||
        (sub.teacherDefault && sub.teacherDefault.toLowerCase().includes(q))
      );
    }
    return true;
  });

  const getDepartmentLabel = (dept?: string) => {
    switch (dept) {
      case 'languages':
        return 'لغات أجنبية وحية';
      case 'sciences':
        return 'علوم دقيقة وتقنية';
      case 'humanities':
        return 'آداب وإنسانيات';
      default:
        return 'دعم عام وتكوين';
    }
  };

  // Print Group Attendance Roster
  const handlePrintGroupRoster = () => {
    if (!activeGroup) return;
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const rows = groupStudents
      .map(
        (stu, i) => `
      <tr>
        <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center; font-weight: bold;">${i + 1}</td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; font-family: monospace; font-weight: bold;">${stu.code}</td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; font-weight: bold;">${stu.fullName}</td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; font-family: monospace;">${stu.guardianPhone}</td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; text-align: center;">
          ${stu.remainingBalance > 0 ? `<span style="color: #b91c1c; font-weight: bold;">متبقي: ${stu.remainingBalance} د.م</span>` : '<span style="color: #15803d; font-weight: bold;">خالص الحساب</span>'}
        </td>
        <td style="padding: 8px; border: 1px solid #cbd5e1; width: 140px; text-align: center; color: #94a3b8;">[ &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ]</td>
      </tr>
    `
      )
      .join('');

    printWindow.document.write(`
      <html dir="rtl">
        <head>
          <title>لائحة فوج ${activeGroup.name} - ${settings.centerName}</title>
          <style>
            body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 24px; color: #0f172a; }
            table { width: 100%; border-collapse: collapse; margin-top: 16px; font-size: 13px; }
            th { background: #f8fafc; padding: 10px; border: 1px solid #cbd5e1; text-align: right; font-weight: bold; }
            .header { border-bottom: 2px solid #4f46e5; padding-bottom: 12px; margin-bottom: 16px; display: flex; justify-content: space-between; align-items: center; }
            @media print { button { display: none; } }
          </style>
        </head>
        <body>
          <div class="header">
            <div>
              <h2 style="margin: 0; color: #1e1b4b; font-size: 20px;">${settings.centerName}</h2>
              <p style="margin: 4px 0; color: #64748b; font-size: 12px;">ورقة الغياب والتنقيط الرسمي للفوج الدراسي</p>
            </div>
            <div style="text-align: left; font-size: 12px; line-height: 1.6;">
              <div><strong>المادة:</strong> ${activeSubject?.name || ''}</div>
              <div><strong>الفوج:</strong> ${activeGroup.name}</div>
              <div><strong>المستوى:</strong> ${activeGroup.levelName || ''}</div>
              <div><strong>الأستاذ:</strong> ${activeGroup.teacherName}</div>
              <div><strong>تاريخ الطبع:</strong> ${new Date().toLocaleDateString('ar-MA')}</div>
            </div>
          </div>
          <table>
            <thead>
              <tr>
                <th style="width: 40px; text-align: center;">#</th>
                <th>رمز التلميذ</th>
                <th>الاسم الكامل للتلميذ</th>
                <th>هاتف الولي للتواصل</th>
                <th style="text-align: center;">الوضعية المالية</th>
                <th style="text-align: center;">توقيع الحضور / ملاحظات</th>
              </tr>
            </thead>
            <tbody>${rows || '<tr><td colspan="6" style="text-align:center; padding: 20px;">لا يوجد تلاميذ مسجلين بهذا الفوج حالياً</td></tr>'}</tbody>
          </table>
          <div style="margin-top: 24px; display: flex; justify-content: space-between; font-size: 12px; color: #475569;">
            <div>مجموع المسجلين: <strong>${groupStudents.length} تلميذ</strong></div>
            <div>توقيع الأستاذ المشرف: .......................................</div>
            <div>خاتم الإدارة: .......................................</div>
          </div>
          <script>window.onload = function() { window.print(); }<\/script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const handleConfirmUnenroll = async () => {
    if (!studentToUnenroll || !onUnenrollStudent) return;
    try {
      setIsUnenrolling(true);
      await onUnenrollStudent(studentToUnenroll.student.id, studentToUnenroll.group.id);
      setStudentToUnenroll(null);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setIsUnenrolling(false);
    }
  };

  const renderConfirmDeleteDialog = () => (
    <ConfirmDialog
      isOpen={Boolean(subjectToDelete)}
      onClose={() => {
        setSubjectToDelete(null);
        setSubjectDeleteError(null);
      }}
      onConfirm={async () => {
        if (!subjectToDelete) return;
        if (subjectDeleteError) {
          setSubjectToDelete(null);
          setSubjectDeleteError(null);
          return;
        }
        try {
          setIsDeletingSubject(true);
          setSubjectDeleteError(null);
          await onDeleteSubject(subjectToDelete.id);
          if (activeBranchId === subjectToDelete.id) {
            setActiveBranchId(null);
            setActiveGroupId(null);
          }
          setSubjectToDelete(null);
        } catch (e) {
          setSubjectDeleteError((e as Error).message);
        } finally {
          setIsDeletingSubject(false);
        }
      }}
      title={subjectDeleteError ? 'تعذر حذف المادة' : `تأكيد حذف مادة "${subjectToDelete?.name}"`}
      message={
        subjectDeleteError ||
        `هل أنت متأكد من رغبتك في حذف مادة "${subjectToDelete?.name}"؟ سيتم حذف بيانات المادة والأفواج غير المشغولة التابعة لها. (إذا كان هناك تلاميذ مسجلون، سيتطلب النظام نقلهم أولاً).`
      }
      confirmText={subjectDeleteError ? 'حسناً، فهمت' : 'تأكيد الحذف النهائي'}
      cancelText={subjectDeleteError ? 'إغلاق' : 'إلغاء'}
      variant={subjectDeleteError ? 'primary' : 'danger'}
      isLoading={isDeletingSubject}
    />
  );

  // =========================================================================
  // LEVEL 3: INSIDE A SPECIFIC GROUP (تلاميذ الفوج المحدد وإدارتهم المباشرة)
  // =========================================================================
  if (activeSubject && activeGroup) {
    const occupancyRate = Math.round((groupStudents.length / (activeGroup.maxCapacity || 1)) * 100);
    const isFull = groupStudents.length >= activeGroup.maxCapacity;

    return (
      <div className="space-y-5 animate-in fade-in duration-200">
        {/* Breadcrumb Navigation Bar */}
        <div className="bg-white p-3.5 px-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs flex-wrap">
            <button
              type="button"
              onClick={() => {
                setActiveBranchId(null);
                setActiveGroupId(null);
              }}
              className="text-slate-500 hover:text-indigo-600 font-bold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>المواد الدراسية</span>
            </button>
            <span className="text-slate-300">/</span>
            <button
              type="button"
              onClick={() => setActiveGroupId(null)}
              className="text-indigo-600 hover:text-indigo-800 font-bold transition-colors cursor-pointer"
            >
              {activeSubject.name}
            </button>
            <span className="text-slate-300">/</span>
            <span className="font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg">
              {activeGroup.name}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {/* Quick Group Switcher inside this Subject */}
            {activeBranchGroups.length > 1 && (
              <select
                value={activeGroupId || ''}
                onChange={(e) => setActiveGroupId(e.target.value)}
                className="text-xs bg-slate-50 border border-slate-300 text-slate-700 font-semibold rounded-lg px-2.5 py-1.5 focus:ring-2 focus:ring-indigo-500 outline-none cursor-pointer"
                title="التبديل السريع لأفواج أخرى لنفس المادة"
              >
                {activeBranchGroups.map((g) => (
                  <option key={g.id} value={g.id}>
                    فوج: {g.name} ({g.enrolledCount} تلميذ)
                  </option>
                ))}
              </select>
            )}

            <Button
              variant="outline"
              size="sm"
              icon={<ArrowRight className="w-3.5 h-3.5" />}
              onClick={() => setActiveGroupId(null)}
            >
              رجوع لأفواج {activeSubject.name}
            </Button>
          </div>
        </div>

        {/* Group Master Summary Card */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-6 space-y-5">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-5 border-b border-slate-100">
            <div className="space-y-2">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-xs font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-md">
                  {activeGroup.levelName || 'مستوى دراسي'}
                </span>
                <span className="text-xs font-bold text-slate-700 bg-slate-100 px-2.5 py-0.5 rounded-md">
                  مادة: {activeSubject.name}
                </span>
                <Badge variant={isFull ? 'danger' : occupancyRate > 75 ? 'warning' : 'success'}>
                  {isFull ? 'الفوج ممتلئ بالكامل' : `مفتوح للتسجيل (${activeGroup.maxCapacity - groupStudents.length} مقاعد شاغرة)`}
                </Badge>
              </div>

              <h2 className="text-xl font-bold text-slate-900 leading-snug">{activeGroup.name}</h2>
              <div className="flex items-center gap-4 text-xs text-slate-600 flex-wrap">
                <span>الأستاذ المشرف: <strong className="text-slate-900">{activeGroup.teacherName}</strong></span>
                <span>•</span>
                <span>الواجب الشهري: <strong className="text-indigo-700 font-mono">{activeGroup.monthlyFee} {settings.currency}</strong></span>
              </div>
            </div>

            {/* Quick Action Buttons for this Group */}
            <div className="flex items-center gap-2 flex-wrap">
              <Button
                variant="outline"
                size="sm"
                icon={<Edit2 className="w-3.5 h-3.5" />}
                onClick={() => onOpenEditGroupModal(activeGroup)}
              >
                تعديل الفوج
              </Button>

              <Button
                variant="outline"
                size="sm"
                icon={<Printer className="w-3.5 h-3.5" />}
                onClick={handlePrintGroupRoster}
                title="طباعة لائحة التلاميذ لتسليمها للأستاذ"
              >
                طباعة لائحة الفوج
              </Button>

              <Button
                variant="secondary"
                size="sm"
                icon={<Clock className="w-3.5 h-3.5" />}
                onClick={() => onTakeAttendance(activeGroup.id)}
              >
                تسجيل الحضور
              </Button>

              <Button
                variant="primary"
                size="sm"
                icon={<UserPlus className="w-3.5 h-3.5" />}
                onClick={() => setIsQuickEnrollModalOpen(true)}
                className="bg-indigo-600 hover:bg-indigo-700 font-bold"
              >
                + تسجيل تلميذ في هذا الفوج
              </Button>
            </div>
          </div>

          {/* Group Schedule & Capacity Stats Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-1">
            {/* Schedule Pills */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
              <span className="text-[11px] font-bold text-slate-500 block">مواعيد حصص الفوج:</span>
              <div className="flex flex-wrap gap-1.5">
                {activeGroup.schedule?.length ? (
                  activeGroup.schedule.map((s, idx) => (
                    <span
                      key={idx}
                      className="inline-flex items-center gap-1 text-[11px] bg-white border border-slate-200 px-2 py-0.5 rounded-md font-mono text-slate-700"
                    >
                      <Clock className="w-3 h-3 text-indigo-500" />
                      {s.day} {s.timeStart}-{s.timeEnd} {s.classroom ? `(${s.classroom})` : ''}
                    </span>
                  ))
                ) : (
                  <span className="text-xs text-slate-400">لم يتم تحديد المواعيد بعد</span>
                )}
              </div>
            </div>

            {/* Capacity Bar */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1.5">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-500">الطاقة الاستيعابية:</span>
                <span className="font-mono font-bold text-slate-900">
                  {groupStudents.length} / {activeGroup.maxCapacity} تلميذ
                </span>
              </div>
              <div className="w-full h-2 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${
                    isFull ? 'bg-rose-500' : occupancyRate > 75 ? 'bg-amber-500' : 'bg-indigo-600'
                  }`}
                  style={{ width: `${Math.min(100, occupancyRate)}%` }}
                />
              </div>
            </div>

            {/* Financial Projection for this group */}
            <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200/80 space-y-1">
              <span className="text-[11px] font-bold text-slate-500 block">المداخيل الشهرية المتوقعة للفوج:</span>
              <span className="font-mono font-bold text-lg text-emerald-700">
                {(groupStudents.length * (activeGroup.monthlyFee || 0)).toLocaleString('fr-FR')}{' '}
                <span className="text-xs text-slate-500">{settings.currency}</span>
              </span>
            </div>
          </div>
        </div>

        {/* Group Students Section */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-indigo-600" />
                <h3 className="font-bold text-base text-slate-900">
                  تلاميذ فوج: {activeGroup.name}
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                إدارة قائمة التلاميذ المسجلين في هذا الفوج، متابعة خلاصهم، وتسجيل أداءاتهم بنقرة واحدة
              </p>
            </div>

            <div className="flex items-center gap-3">
              {/* Search inside group */}
              <div className="relative w-64">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={studentSearchInGroup}
                  onChange={(e) => setStudentSearchInGroup(e.target.value)}
                  placeholder="بحث في تلاميذ الفوج بالاسم..."
                  className="w-full pr-8 pl-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <Button
                variant="primary"
                size="sm"
                icon={<UserPlus className="w-3.5 h-3.5" />}
                onClick={() => setIsQuickEnrollModalOpen(true)}
              >
                + تسجيل تلميذ
              </Button>
            </div>
          </div>

          {groupStudents.length === 0 ? (
            <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-xl space-y-3 bg-slate-50/50">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                <Users className="w-6 h-6" />
              </div>
              <h4 className="font-bold text-sm text-slate-800">
                لا يوجد أي تلميذ مسجل في فوج "{activeGroup.name}" حتى الآن
              </h4>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                يمكنك الآن تسجيل تلاميذ جدد مباشرة في هذا الفوج، أو إضافة تلاميذ مسجلين بالمركز مسبقاً.
              </p>
              <Button
                variant="primary"
                size="sm"
                icon={<UserPlus className="w-3.5 h-3.5" />}
                onClick={() => setIsQuickEnrollModalOpen(true)}
              >
                تسجيل أول تلميذ في هذا الفوج الآن
              </Button>
            </div>
          ) : filteredGroupStudents.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              لا يوجد تلميذ يطابق كلمة البحث.
            </div>
          ) : (
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50/90 border-b border-slate-200 text-slate-600 font-semibold">
                  <tr>
                    <th className="p-3 w-10 text-center">#</th>
                    <th className="p-3">رمز التلميذ</th>
                    <th className="p-3">اسم التلميذ الكامل</th>
                    <th className="p-3">ولي الأمر والتواصل</th>
                    <th className="p-3">الحالة المالية</th>
                    <th className="p-3 text-left">إجراءات سريعة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {filteredGroupStudents.map((stu, idx) => {
                    const hasDebt = stu.remainingBalance > 0;
                    const cleanPhone = stu.guardianPhone.replace(/\D/g, '').replace(/^0/, '');

                    return (
                      <tr key={stu.id} className="hover:bg-slate-50/80 transition-colors">
                        <td className="p-3 text-center text-slate-400 font-mono">{idx + 1}</td>
                        <td className="p-3 font-mono font-bold text-slate-700">{stu.code}</td>
                        <td className="p-3">
                          <button
                            type="button"
                            onClick={() => onSelectStudentProfile(stu)}
                            className="font-bold text-slate-900 hover:text-indigo-600 transition-colors text-right cursor-pointer"
                          >
                            {stu.fullName}
                          </button>
                        </td>
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <div>
                              <span className="block text-slate-800">{stu.guardianName}</span>
                              <span className="font-mono text-slate-500 text-[11px] dir-ltr inline-block">
                                {stu.guardianPhone}
                              </span>
                            </div>
                            {cleanPhone && (
                              <a
                                href={`https://wa.me/212${cleanPhone}`}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 text-emerald-600 hover:bg-emerald-50 rounded transition-colors inline-block"
                                title="مراسلة ولي الأمر عبر واتساب"
                              >
                                <MessageCircle className="w-3.5 h-3.5" />
                              </a>
                            )}
                          </div>
                        </td>
                        <td className="p-3">
                          {hasDebt ? (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                              <XCircle className="w-3 h-3 text-rose-600" />
                              متبقي: {stu.remainingBalance} د.م
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              خالص الحساب
                            </span>
                          )}
                        </td>
                        <td className="p-3 text-left">
                          <div className="flex items-center justify-end gap-1.5">
                            <Button
                              variant="outline"
                              size="sm"
                              icon={<CreditCard className="w-3.5 h-3.5 text-emerald-600" />}
                              onClick={() => onOpenPaymentModal(stu)}
                              className="text-xs bg-emerald-50/50 hover:bg-emerald-100/70 border-emerald-200 text-emerald-800"
                            >
                              خلاص وصل
                            </Button>

                            <button
                              type="button"
                              onClick={() => onSelectStudentProfile(stu)}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                              title="بروفيل التلميذ"
                            >
                              <FileText className="w-4 h-4" />
                            </button>

                            <button
                              type="button"
                              onClick={() => onPrintStudentCard(stu)}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                              title="طباعة بطاقة التلميذ"
                            >
                              <Printer className="w-4 h-4" />
                            </button>

                            {onUnenrollStudent && (
                              <button
                                type="button"
                                onClick={() => setStudentToUnenroll({ student: stu, group: activeGroup })}
                                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                                title="إلغاء تسجيل التلميذ من هذا الفوج"
                              >
                                <UserMinus className="w-4 h-4" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Quick Enroll Modal */}
        <QuickBranchEnrollModal
          isOpen={isQuickEnrollModalOpen}
          onClose={() => setIsQuickEnrollModalOpen(false)}
          subject={activeSubject}
          branchGroups={[activeGroup, ...activeBranchGroups.filter((g) => g.id !== activeGroup.id)]}
          allStudents={students}
          levels={levels}
          onEnrollExisting={onEnrollExistingStudent}
          onAddNewAndEnroll={onAddNewStudentAndEnroll}
        />

        {/* Unenroll Confirm Dialog */}
        <ConfirmDialog
          isOpen={Boolean(studentToUnenroll)}
          onClose={() => setStudentToUnenroll(null)}
          onConfirm={handleConfirmUnenroll}
          title="تأكيد إلغاء التسجيل من الفوج"
          message={`هل أنت متأكد من رغبتك في إلغاء تسجيل التلميذ "${studentToUnenroll?.student.fullName}" من فوج "${studentToUnenroll?.group.name}"؟`}
          confirmText="نعم، إلغاء التسجيل"
          cancelText="تراجع"
          variant="danger"
          isLoading={isUnenrolling}
        />
      </div>
    );
  }

  // =========================================================================
  // LEVEL 2: INSIDE A SPECIFIC SUBJECT (أفواج المادة المحددة وحصصها)
  // =========================================================================
  if (activeSubject) {
    return (
      <div className="space-y-5 animate-in fade-in duration-200">
        {/* Breadcrumb Navigation Bar */}
        <div className="bg-white p-3.5 px-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => {
                setActiveBranchId(null);
                setActiveGroupId(null);
              }}
              className="text-indigo-600 hover:text-indigo-800 font-bold flex items-center gap-1 transition-colors cursor-pointer"
            >
              <ArrowRight className="w-3.5 h-3.5" />
              <span>جميع المواد الدراسية</span>
            </button>
            <span className="text-slate-300">/</span>
            <span className="font-bold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-lg">
              {activeSubject.name}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              icon={<Trash2 className="w-3.5 h-3.5 text-red-500" />}
              onClick={() => {
                setSubjectDeleteError(null);
                setSubjectToDelete(activeSubject);
              }}
              className="hover:border-red-300 hover:text-red-600 hover:bg-red-50 text-slate-600"
            >
              حذف المادة
            </Button>
            <Button
              variant="outline"
              size="sm"
              icon={<Edit2 className="w-3.5 h-3.5" />}
              onClick={() => {
                setSubjectToEdit(activeSubject);
                setIsSubjectModalOpen(true);
              }}
            >
              تعديل بيانات المادة
            </Button>
            <Button
              variant="primary"
              size="sm"
              icon={<Plus className="w-3.5 h-3.5" />}
              onClick={() => onOpenNewGroupForSubject(activeSubject.id)}
              className="bg-indigo-600 hover:bg-indigo-700 font-bold"
            >
              + إنشاء فوج جديد في {activeSubject.name}
            </Button>
          </div>
        </div>

        {/* Dedicated Subject Header Banner */}
        <div
          className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-6 relative overflow-hidden"
          style={{
            borderRightWidth: '6px',
            borderRightColor: activeSubject.color || '#2563eb',
          }}
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 flex-wrap">
                {activeSubject.code && (
                  <span className="px-2.5 py-0.5 text-xs font-mono font-bold rounded-md bg-indigo-50 text-indigo-700">
                    {activeSubject.code}
                  </span>
                )}
                <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                  {getDepartmentLabel(activeSubject.department)}
                </span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900">{activeSubject.name}</h2>
              <p className="text-xs text-slate-500 leading-relaxed max-w-xl">
                {activeSubject.description ||
                  `إدارة أفواج وحصص وتلاميذ مادة ${activeSubject.name}. اضغط على أي فوج للدخول إلى تلاميذه مباشرة.`}
              </p>
            </div>

            {/* Quick Stats for this Subject */}
            <div className="flex items-center gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
              <div className="text-center px-3 py-1">
                <span className="block text-[11px] text-slate-500 font-medium">الأفواج المفتوحة</span>
                <span className="text-xl font-bold font-mono text-indigo-700 tabular-nums">
                  {activeBranchGroups.length}
                </span>
              </div>
              <div className="text-center px-3 py-1 border-r border-slate-200">
                <span className="block text-[11px] text-slate-500 font-medium">إجمالي التلاميذ</span>
                <span className="text-xl font-bold font-mono text-emerald-700 tabular-nums">
                  {activeBranchStudents.length}
                </span>
              </div>
              <div className="text-center px-3 py-1 border-r border-slate-200">
                <span className="block text-[11px] text-slate-500 font-medium">الحصص الأسبوعية</span>
                <span className="text-xl font-bold font-mono text-amber-700 tabular-nums">
                  {branchWeeklySessions}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Level 2 Subtabs */}
        <div className="bg-white rounded-2xl border border-slate-200/90 shadow-xs overflow-hidden">
          {/* Subtab Navigation */}
          <div className="flex border-b border-slate-200 px-6 pt-2 bg-slate-50/50">
            <button
              type="button"
              onClick={() => setBranchSubTab('groups')}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                branchSubTab === 'groups'
                  ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Users className="w-4 h-4" />
              <span>أفواج وحصص {activeSubject.name}</span>
              <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-indigo-50 text-indigo-700 font-mono">
                {activeBranchGroups.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setBranchSubTab('students')}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                branchSubTab === 'students'
                  ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <GraduationCap className="w-4 h-4" />
              <span>جميع تلاميذ المادة</span>
              <span className="px-1.5 py-0.5 text-[10px] rounded-full bg-slate-100 text-slate-700 font-mono">
                {activeBranchStudents.length}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setBranchSubTab('schedule')}
              className={`flex items-center gap-2 py-3 px-4 text-xs font-bold border-b-2 transition-all cursor-pointer ${
                branchSubTab === 'schedule'
                  ? 'border-indigo-600 text-indigo-600 bg-white rounded-t-lg shadow-2xs'
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              <Calendar className="w-4 h-4" />
              <span>جدول التوقيت الأسبوعي</span>
            </button>
          </div>

          {/* Subtab 1: Groups (الأفواج) */}
          {branchSubTab === 'groups' && (
            <div className="p-6 space-y-4">
              <div className="flex items-center justify-between gap-3">
                <p className="text-xs text-slate-600 font-medium">
                  اختر أي فوج للدخول إليه مباشرة وإدارة تلاميذه وحضوره:
                </p>
                <Button
                  variant="primary"
                  size="sm"
                  icon={<Plus className="w-3.5 h-3.5" />}
                  onClick={() => onOpenNewGroupForSubject(activeSubject.id)}
                >
                  + إنشاء فوج دراسي جديد
                </Button>
              </div>

              {activeBranchGroups.length === 0 ? (
                <div className="p-12 text-center border-2 border-dashed border-slate-200 rounded-xl space-y-3 bg-slate-50/50">
                  <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-full flex items-center justify-center mx-auto">
                    <Users className="w-6 h-6" />
                  </div>
                  <h4 className="font-bold text-sm text-slate-800">
                    لا توجد أفواج دراسية في مادة {activeSubject.name} بعد
                  </h4>
                  <p className="text-xs text-slate-500 max-w-md mx-auto">
                    أنشئ أول فوج دراسي لمادة {activeSubject.name} (مثلاً: فوج الباكالوريا، فوج الإعدادي) لتتمكن من إضافة التلاميذ إليه.
                  </p>
                  <Button
                    variant="primary"
                    size="sm"
                    icon={<Plus className="w-3.5 h-3.5" />}
                    onClick={() => onOpenNewGroupForSubject(activeSubject.id)}
                  >
                    إنشاء أول فوج دراسي الآن
                  </Button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {activeBranchGroups.map((grp) => {
                    const occupancyRate = Math.round((grp.enrolledCount / (grp.maxCapacity || 1)) * 100);
                    const isFull = grp.enrolledCount >= grp.maxCapacity;

                    return (
                      <div
                        key={grp.id}
                        className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 space-y-4 flex flex-col justify-between hover:border-indigo-300 hover:shadow-md transition-all group"
                      >
                        <div className="space-y-3">
                          <div className="flex items-start justify-between gap-2">
                            <div>
                              <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-0.5 rounded-md inline-block">
                                {grp.levelName}
                              </span>
                              <h3 className="font-bold text-base text-slate-900 mt-1 leading-snug group-hover:text-indigo-600 transition-colors">
                                {grp.name}
                              </h3>
                              <p className="text-xs text-slate-500 mt-0.5">الأستاذ: {grp.teacherName}</p>
                            </div>
                            <button
                              type="button"
                              onClick={() => onOpenEditGroupModal(grp)}
                              className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                              title="تعديل بيانات الفوج"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                          </div>

                          {/* Capacity */}
                          <div className="pt-2 border-t border-slate-100 space-y-1">
                            <div className="flex items-center justify-between text-xs">
                              <span className="text-slate-500">المسجلون بالفوج:</span>
                              <span className="font-mono font-bold text-slate-800">
                                {grp.enrolledCount} / {grp.maxCapacity} تلميذ
                              </span>
                            </div>
                            <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div
                                className={`h-full rounded-full transition-all ${
                                  isFull ? 'bg-rose-500' : occupancyRate > 75 ? 'bg-amber-500' : 'bg-indigo-600'
                                }`}
                                style={{ width: `${Math.min(100, occupancyRate)}%` }}
                              />
                            </div>
                          </div>

                          {/* Schedule summary */}
                          <div className="space-y-1 pt-1">
                            {grp.schedule?.map((s, idx) => (
                              <div
                                key={idx}
                                className="flex items-center justify-between text-[11px] bg-slate-50 px-2.5 py-1 rounded-md text-slate-600 font-mono"
                              >
                                <span className="font-bold text-slate-700">{s.day}</span>
                                <span>{s.timeStart} - {s.timeEnd}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Drill Down into Group */}
                        <div className="pt-3 border-t border-slate-100 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-mono font-bold text-xs text-slate-700">
                              {grp.monthlyFee} {settings.currency}/شهر
                            </span>
                            <span className="text-[11px] text-slate-400">
                              {isFull ? 'مكتمل' : `${grp.maxCapacity - grp.enrolledCount} أماكن فارغة`}
                            </span>
                          </div>

                          <Button
                            variant="primary"
                            size="sm"
                            icon={<Users className="w-3.5 h-3.5" />}
                            onClick={() => setActiveGroupId(grp.id)}
                            className="w-full justify-center bg-indigo-600 hover:bg-indigo-700 font-bold text-xs shadow-xs"
                          >
                            دخول للفوج وإدارة التلاميذ ({grp.enrolledCount}) ←
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Subtab 2: All Students in this Subject */}
          {branchSubTab === 'students' && (
            <div className="p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="relative flex-1 min-w-[240px] max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                  <input
                    type="text"
                    value={studentSearchInBranch}
                    onChange={(e) => setStudentSearchInBranch(e.target.value)}
                    placeholder="بحث في جميع تلاميذ مادة {activeSubject.name}..."
                    className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  />
                </div>

                <Button
                  variant="primary"
                  size="sm"
                  icon={<UserPlus className="w-3.5 h-3.5" />}
                  onClick={() => setIsQuickEnrollModalOpen(true)}
                >
                  + تسجيل تلميذ جديد في {activeSubject.name}
                </Button>
              </div>

              {activeBranchStudents.length === 0 ? (
                <div className="p-10 text-center border-2 border-dashed border-slate-200 rounded-xl space-y-2">
                  <p className="text-xs text-slate-500">لا يوجد تلاميذ مسجلون في هذه المادة بعد.</p>
                </div>
              ) : (
                <div className="overflow-x-auto border border-slate-200 rounded-xl">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                      <tr>
                        <th className="p-3">رمز التلميذ</th>
                        <th className="p-3">اسم التلميذ الكامل</th>
                        <th className="p-3">الفوج المسجل به</th>
                        <th className="p-3">ولي الأمر والهاتف</th>
                        <th className="p-3">الحالة المالية</th>
                        <th className="p-3 text-left">إجراءات</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium">
                      {filteredBranchStudents.map((stu) => {
                        const branchGroupsForStudent = stu.enrolledGroups.filter((g) =>
                          activeBranchGroupIds.has(g.id)
                        );
                        const hasDebt = stu.remainingBalance > 0;

                        return (
                          <tr key={stu.id} className="hover:bg-slate-50/80 transition-colors">
                            <td className="p-3 font-mono font-bold text-slate-700">{stu.code}</td>
                            <td className="p-3">
                              <button
                                type="button"
                                onClick={() => onSelectStudentProfile(stu)}
                                className="font-bold text-slate-900 hover:text-indigo-600 transition-colors text-right cursor-pointer"
                              >
                                {stu.fullName}
                              </button>
                            </td>
                            <td className="p-3">
                              {branchGroupsForStudent.map((g) => (
                                <button
                                  key={g.id}
                                  type="button"
                                  onClick={() => setActiveGroupId(g.id)}
                                  className="inline-block px-2 py-0.5 rounded text-[11px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-100 hover:bg-indigo-100 mr-1 cursor-pointer"
                                  title="اضغط للدخول إلى هذا الفوج مباشرة"
                                >
                                  {g.name} ←
                                </button>
                              ))}
                            </td>
                            <td className="p-3">
                              <div className="text-slate-800">{stu.guardianName}</div>
                              <div className="text-slate-400 font-mono text-[11px] dir-ltr inline-block">
                                {stu.guardianPhone}
                              </div>
                            </td>
                            <td className="p-3">
                              {hasDebt ? (
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                                  متبقي: {stu.remainingBalance} د.م
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                                  خالص الحساب
                                </span>
                              )}
                            </td>
                            <td className="p-3 text-left">
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => onOpenPaymentModal(stu)}
                                className="text-xs"
                              >
                                خلاص
                              </Button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {/* Subtab 3: Schedule Calendar */}
          {branchSubTab === 'schedule' && (
            <div className="p-6 space-y-4">
              <p className="text-xs text-slate-500 font-medium">
                توزيع الحصص الأسبوعية لمادة {activeSubject.name}:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-3">
                {['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'].map(
                  (dayName) => {
                    const daySessions = activeBranchGroups.flatMap((g) =>
                      (g.schedule || [])
                        .filter((s) => s.day === dayName)
                        .map((s) => ({ ...s, groupId: g.id, groupName: g.name, teacher: g.teacherName }))
                    );

                    return (
                      <div
                        key={dayName}
                        className="bg-slate-50/70 border border-slate-200 rounded-xl p-3 min-h-[160px] space-y-2"
                      >
                        <div className="text-xs font-bold text-slate-800 pb-1.5 border-b border-slate-200 text-center">
                          {dayName}
                        </div>
                        {daySessions.length === 0 ? (
                          <div className="text-[11px] text-slate-400 text-center pt-8">
                            لا توجد حصص
                          </div>
                        ) : (
                          <div className="space-y-1.5">
                            {daySessions.map((session, idx) => (
                              <button
                                key={idx}
                                type="button"
                                onClick={() => setActiveGroupId(session.groupId)}
                                className="w-full p-2 rounded-lg bg-white border border-slate-200 hover:border-indigo-400 text-right shadow-xs space-y-1 cursor-pointer transition-all block"
                              >
                                <div className="text-[11px] font-bold text-slate-900 leading-snug">
                                  {session.groupName}
                                </div>
                                <div className="text-[10px] font-mono text-indigo-700 font-semibold">
                                  {session.timeStart} - {session.timeEnd}
                                </div>
                                {session.classroom && (
                                  <div className="text-[10px] text-slate-500">{session.classroom}</div>
                                )}
                              </button>
                            ))}
                          </div>
                        )}
                      </div>
                    );
                  }
                )}
              </div>
            </div>
          )}
        </div>

        {/* Quick Enroll Modal */}
        <QuickBranchEnrollModal
          isOpen={isQuickEnrollModalOpen}
          onClose={() => setIsQuickEnrollModalOpen(false)}
          subject={activeSubject}
          branchGroups={activeBranchGroups}
          allStudents={students}
          levels={levels}
          onEnrollExisting={onEnrollExistingStudent}
          onAddNewAndEnroll={onAddNewStudentAndEnroll}
        />

        {/* Subject Edit Modal */}
        <SubjectFormModal
          isOpen={isSubjectModalOpen}
          onClose={() => {
            setIsSubjectModalOpen(false);
            setSubjectToEdit(null);
          }}
          onSubmit={async (data) => {
            if (subjectToEdit) {
              await onUpdateSubject(subjectToEdit.id, data);
            }
          }}
          subjectToEdit={subjectToEdit}
          levels={levels}
        />

        {/* Delete Subject Dialog */}
        {renderConfirmDeleteDialog()}
      </div>
    );
  }

  // =========================================================================
  // LEVEL 1: ALL SUBJECTS / BRANCHES OVERVIEW (المواد واللغات الدراسية كاملة)
  // =========================================================================
  return (
    <div className="space-y-5 animate-in fade-in duration-200">
      {/* Top Action & Control Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
          {/* Search */}
          <div className="relative flex-1 max-w-xs">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
            <input
              type="text"
              value={branchSearch}
              onChange={(e) => setBranchSearch(e.target.value)}
              placeholder="ابحث عن مادة أو لغة (رياضيات، فرنسية، إنجليزية...)..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          {/* Department Filter */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-lg text-xs font-semibold">
            {[
              { id: 'all', label: 'جميع المواد' },
              { id: 'languages', label: 'اللغات الحية' },
              { id: 'sciences', label: 'العلوم الدقيقة' },
              { id: 'humanities', label: 'الآداب' },
            ].map((d) => (
              <button
                type="button"
                key={d.id}
                onClick={() => setDepartmentFilter(d.id)}
                className={`px-3 py-1 rounded-md transition-all cursor-pointer ${
                  departmentFilter === d.id
                    ? 'bg-white text-slate-900 shadow-xs font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {d.label}
              </button>
            ))}
          </div>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon={<Plus className="w-4 h-4" />}
          onClick={() => {
            setSubjectToEdit(null);
            setIsSubjectModalOpen(true);
          }}
          className="bg-indigo-600 hover:bg-indigo-700 font-bold"
        >
          + إضافة مادة / لغة جديدة
        </Button>
      </div>

      {/* Subjects Grid */}
      {filteredSubjects.length === 0 ? (
        <div className="bg-white p-12 text-center rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <BookOpen className="w-12 h-12 text-slate-300 mx-auto" />
          <h3 className="font-bold text-base text-slate-700">لا توجد مواد مسجلة حالياً</h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            أضف المواد التي تقدمونها في المركز (رياضيات، فيزياء، لغات...) لتتمكن من إنشاء أفواجها وإضافة التلاميذ.
          </p>
          <Button
            variant="primary"
            size="sm"
            onClick={() => {
              setSubjectToEdit(null);
              setIsSubjectModalOpen(true);
            }}
          >
            + إضافة أول مادة دراسية الآن
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredSubjects.map((sub) => {
            const subGroups = groups.filter((g) => g.subjectId === sub.id);
            const subGroupIds = new Set(subGroups.map((g) => g.id));
            const subStudents = students.filter((stu) =>
              stu.enrolledGroups.some((g) => subGroupIds.has(g.id))
            );
            const totalSessions = subGroups.reduce((acc, g) => acc + (g.schedule?.length || 0), 0);

            return (
              <div
                key={sub.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:border-indigo-300 hover:shadow-md transition-all space-y-4 group"
              >
                <div className="space-y-3">
                  {/* Card Header */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-11 h-11 rounded-xl flex items-center justify-center font-bold text-white text-sm shadow-xs shrink-0"
                        style={{ backgroundColor: sub.color || '#4f46e5' }}
                      >
                        {sub.code || sub.name.substring(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <h3 className="font-bold text-base text-slate-900 group-hover:text-indigo-600 transition-colors">
                          {sub.name}
                        </h3>
                        <span className="text-[11px] text-slate-500">
                          {getDepartmentLabel(sub.department)}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                      <button
                        type="button"
                        onClick={() => {
                          setSubjectToEdit(sub);
                          setIsSubjectModalOpen(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg cursor-pointer transition-colors"
                        title="تعديل المادة"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setSubjectDeleteError(null);
                          setSubjectToDelete(sub);
                        }}
                        className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg cursor-pointer transition-colors"
                        title="حذف المادة"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Stats Grid inside Subject Card */}
                  <div className="grid grid-cols-3 gap-2 pt-2 text-center">
                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="block text-[10px] text-slate-500 font-medium">الأفواج</span>
                      <span className="text-base font-bold font-mono text-indigo-700">
                        {subGroups.length}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="block text-[10px] text-slate-500 font-medium">التلاميذ</span>
                      <span className="text-base font-bold font-mono text-emerald-700">
                        {subStudents.length}
                      </span>
                    </div>
                    <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100">
                      <span className="block text-[10px] text-slate-500 font-medium">حصص/أسبوع</span>
                      <span className="text-base font-bold font-mono text-slate-700">
                        {totalSessions}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Primary Button to enter this subject */}
                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>الواجب الشهري:</span>
                    <span className="font-mono font-bold text-slate-800">
                      {sub.monthlyFeeDefault ? `${sub.monthlyFeeDefault} ${settings.currency}` : 'حسب الفوج'}
                    </span>
                  </div>

                  <Button
                    variant="primary"
                    size="sm"
                    icon={<Layers className="w-3.5 h-3.5" />}
                    onClick={() => {
                      setActiveBranchId(sub.id);
                      setActiveGroupId(null);
                    }}
                    className="w-full justify-center bg-indigo-600 hover:bg-indigo-700 font-bold shadow-xs text-xs"
                  >
                    دخول للمادة وعرض الأفواج ({subGroups.length}) ←
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit Subject Modal */}
      <SubjectFormModal
        isOpen={isSubjectModalOpen}
        onClose={() => {
          setIsSubjectModalOpen(false);
          setSubjectToEdit(null);
        }}
        onSubmit={async (data) => {
          if (subjectToEdit) {
            await onUpdateSubject(subjectToEdit.id, data);
          } else {
            await onAddSubject(data);
          }
        }}
        subjectToEdit={subjectToEdit}
        levels={levels}
      />

      {/* Delete Subject Dialog */}
      {renderConfirmDeleteDialog()}
    </div>
  );
};
