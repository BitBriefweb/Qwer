import React, { useState } from 'react';
import { ConnectedDevice, StudyGroup, CenterSettings } from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import {
  Tablet,
  Smartphone,
  Laptop,
  Plus,
  QrCode,
  KeyRound,
  Trash2,
  RefreshCw,
  ExternalLink,
  ShieldCheck,
  CheckCircle,
  Clock,
  Sparkles,
  Wifi,
  Copy,
  Check,
  User,
  Info,
} from 'lucide-react';
import { DevicePairingModal } from '../devices/DevicePairingModal';
import { QRCodeSvg } from '../common/QRCodeSvg';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';

interface DevicesViewProps {
  devices: ConnectedDevice[];
  groups: StudyGroup[];
  settings: CenterSettings;
  onAddDevice: (data: Omit<ConnectedDevice, 'id' | 'createdAt' | 'pairingToken'>) => Promise<ConnectedDevice>;
  onUpdateDevice: (id: string, updates: Partial<ConnectedDevice>) => Promise<ConnectedDevice>;
  onDeleteDevice: (id: string) => Promise<void>;
  onOpenMobileTerminal: (device: ConnectedDevice) => void;
}

export const DevicesView: React.FC<DevicesViewProps> = ({
  devices,
  groups,
  settings,
  onAddDevice,
  onUpdateDevice,
  onDeleteDevice,
  onOpenMobileTerminal,
}) => {
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [selectedDeviceForQR, setSelectedDeviceForQR] = useState<ConnectedDevice | null>(null);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const [deviceToDelete, setDeviceToDelete] = useState<ConnectedDevice | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  const handleCopyLink = (dev: ConnectedDevice) => {
    const url = `${window.location.origin}${window.location.pathname}?mode=mobile_terminal&device=${dev.id}&token=${dev.pairingToken}`;
    navigator.clipboard.writeText(url);
    setCopiedToken(dev.id);
    setTimeout(() => setCopiedToken(null), 3000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Tablet className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">
              ربط الأجهزة المتنقلة (الهواتف والتابليت لتسجيل الغياب بالقاعات)
            </h1>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed max-w-2xl">
            يمكنك ربط وتفويض أي جهاز لوحي (تابليت) أو هاتف ذكي ليحمله الأستاذ أو المشرف داخل القاعة لتسجيل الغياب بسهولة، مع مزامنة وحفظ جميع السجلات تلقائياً في هذا الحاسوب دون نقل البيانات يدوياً.
          </p>
        </div>

        <Button
          variant="primary"
          size="md"
          icon={<Plus className="w-4 h-4" />}
          onClick={() => setIsAddModalOpen(true)}
        >
          + إضافة وربط جهاز جديد
        </Button>
      </div>

      {/* Guide Card */}
      <div className="bg-linear-to-r from-indigo-900 to-slate-900 text-white p-5 rounded-2xl shadow-sm border border-indigo-800 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center shrink-0">
            <QrCode className="w-5 h-5 text-amber-300" />
          </div>
          <div className="space-y-1 text-xs">
            <h3 className="font-bold text-sm text-white">كيف يعمل الربط بين الحاسوب والتابليت؟</h3>
            <p className="text-slate-300 leading-relaxed">
              1. أنشئ الجهاز أدناه (مثلاً: "تابليت القاعة 1") ➔ 2. افتح رمز QR بكاميرا الهاتف أو التابليت ➔ 3. يفتح تطبيق تسجيل الغياب المباشر ومزامنة كل شيء فوراً بالحاسوب.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <span className="text-xs font-mono bg-white/10 px-3 py-1.5 rounded-lg text-emerald-300 border border-white/10 flex items-center gap-1.5">
            <Wifi className="w-3.5 h-3.5 text-emerald-400" />
            <span>مزامنة فورية مشفرة</span>
          </span>
        </div>
      </div>

      {/* Devices Grid */}
      {devices.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border-2 border-dashed border-slate-200 space-y-3">
          <div className="w-12 h-12 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center mx-auto">
            <Smartphone className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-800">لا توجد أجهزة مرافقة مربوطة حالياً</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            أضف أول جهاز تابليت أو هاتف لمشرفي القاعات للبدء في تسجيل الحضور والغياب دون حمل الحاسوب.
          </p>
          <Button
            variant="primary"
            size="sm"
            icon={<Plus className="w-3.5 h-3.5" />}
            onClick={() => setIsAddModalOpen(true)}
          >
            إضافة أول جهاز لوحي الآن
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {devices.map((dev) => {
            const isTablet = dev.deviceType === 'tablet';
            const pairingUrl = `${window.location.origin}${window.location.pathname}?mode=mobile_terminal&device=${dev.id}&token=${dev.pairingToken}`;

            return (
              <div
                key={dev.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all space-y-4"
              >
                <div className="space-y-3">
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5">
                      <div className="p-2.5 bg-slate-100 rounded-xl text-slate-700">
                        {isTablet ? <Tablet className="w-5 h-5 text-indigo-600" /> : <Smartphone className="w-5 h-5 text-emerald-600" />}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
                            {dev.status === 'active' ? 'مصادق عليه' : 'معطل'}
                          </span>
                        </div>
                        <h3 className="font-bold text-base text-slate-900 mt-0.5">{dev.name}</h3>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setDeviceToDelete(dev)}
                      className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                      title="إلغاء ربط وحذف الجهاز"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Device Info Cards */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-600">
                      <span>كود PIN السريع:</span>
                      <span className="font-mono font-bold text-indigo-700 text-sm bg-white px-2 py-0.5 rounded border border-slate-200">
                        {dev.pinCode}
                      </span>
                    </div>

                    {dev.assignedTeacher && (
                      <div className="flex items-center justify-between text-slate-600">
                        <span>الأستاذ المسند:</span>
                        <span className="font-bold text-slate-800">{dev.assignedTeacher}</span>
                      </div>
                    )}

                    <div className="flex items-center justify-between text-slate-600">
                      <span>آخر مزامنة مع الحاسوب:</span>
                      <span className="font-mono text-slate-800 text-[11px]">
                        {dev.lastSyncAt ? dev.lastSyncAt : 'بانتظار أول مزامنة'}
                      </span>
                    </div>

                    {dev.notes && (
                      <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                        {dev.notes}
                      </p>
                    )}
                  </div>
                </div>

                {/* Actions */}
                <div className="space-y-2 pt-2 border-t border-slate-100">
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      icon={<QrCode className="w-3.5 h-3.5" />}
                      onClick={() => setSelectedDeviceForQR(dev)}
                    >
                      عرض QR Code
                    </Button>

                    <Button
                      variant="outline"
                      size="sm"
                      icon={copiedToken === dev.id ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      onClick={() => handleCopyLink(dev)}
                    >
                      {copiedToken === dev.id ? 'تم النسخ!' : 'نسخ الرابط'}
                    </Button>
                  </div>

                  <Button
                    variant="primary"
                    size="sm"
                    className="w-full justify-center"
                    icon={<ExternalLink className="w-3.5 h-3.5" />}
                    onClick={() => onOpenMobileTerminal(dev)}
                  >
                    فتح وتجربة واجهة التابليت 📱
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add Device Modal */}
      <DevicePairingModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddDevice={onAddDevice}
        groups={groups}
        onOpenMobileTerminal={onOpenMobileTerminal}
      />

      {/* Show QR Modal */}
      {selectedDeviceForQR && (
        <Modal
          isOpen={Boolean(selectedDeviceForQR)}
          onClose={() => setSelectedDeviceForQR(null)}
          title={`رمز QR لربط: ${selectedDeviceForQR.name}`}
          subtitle="وجه كاميرا التابليت أو الهاتف لمسح الرمز والاتصال بالحاسوب فوراً"
          maxWidth="sm"
        >
          <div className="text-center space-y-4 py-2 flex flex-col items-center">
            <QRCodeSvg
              value={`${window.location.origin}${window.location.pathname}?mode=mobile_terminal&device=${selectedDeviceForQR.id}&token=${selectedDeviceForQR.pairingToken}`}
              size={200}
            />

            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs space-y-1 text-center w-full">
              <span className="block text-slate-500 font-medium">كود PIN السريع للجهاز:</span>
              <span className="text-xl font-mono font-black text-indigo-700 tracking-widest">
                {selectedDeviceForQR.pinCode}
              </span>
            </div>

            <Button
              variant="primary"
              size="sm"
              className="w-full"
              onClick={() => setSelectedDeviceForQR(null)}
            >
              تم
            </Button>
          </div>
        </Modal>
      )}

      {/* Confirm Delete Device Dialog */}
      <ConfirmDialog
        isOpen={Boolean(deviceToDelete)}
        onClose={() => setDeviceToDelete(null)}
        onConfirm={async () => {
          if (!deviceToDelete) return;
          try {
            setIsDeleting(true);
            await onDeleteDevice(deviceToDelete.id);
            setDeviceToDelete(null);
          } finally {
            setIsDeleting(false);
          }
        }}
        title="تأكيد إلغاء ربط وحذف الجهاز"
        message={`هل أنت متأكد من رغبتك في حذف وإلغاء ترخيص الجهاز "${deviceToDelete?.name}"؟ لن يتمكن هذا الجهاز من تسجيل الغياب بعد الآن إلا بعد إعادة ربطه من جديد.`}
        confirmText="تأكيد الحذف"
        variant="danger"
        isLoading={isDeleting}
      />
    </div>
  );
};
