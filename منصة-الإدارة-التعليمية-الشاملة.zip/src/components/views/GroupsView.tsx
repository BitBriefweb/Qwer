import React, { useState } from 'react';
import { StudyGroup, Level, Subject, CenterSettings } from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Users, Plus, Edit2, Calendar, Clock, DollarSign, CheckCircle2 } from 'lucide-react';

interface GroupsViewProps {
  groups: Array<StudyGroup & { enrolledCount: number; levelName: string; subjectName: string }>;
  levels: Level[];
  subjects: Subject[];
  settings: CenterSettings;
  onOpenNewGroupModal: () => void;
  onOpenEditGroupModal: (group: StudyGroup) => void;
  onTakeAttendance: (groupId: string) => void;
}

export const GroupsView: React.FC<GroupsViewProps> = ({
  groups,
  levels,
  subjects,
  settings,
  onOpenNewGroupModal,
  onOpenEditGroupModal,
  onTakeAttendance,
}) => {
  const [levelFilter, setLevelFilter] = useState('');

  const filtered = levelFilter ? groups.filter((g) => g.levelId === levelFilter) : groups;

  return (
    <div className="space-y-4">
      {/* Control Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">تصفية حسب المستوى:</label>
          <select
            value={levelFilter}
            onChange={(e) => setLevelFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            <option value="">جميع المستويات الدراسية</option>
            {levels.map((lvl) => (
              <option key={lvl.id} value={lvl.id}>
                {lvl.name}
              </option>
            ))}
          </select>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon={<Plus className="w-3.5 h-3.5" />}
          onClick={onOpenNewGroupModal}
        >
          إنشاء فوج دراسي جديد
        </Button>
      </div>

      {/* Groups Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((grp) => {
          const occupancyRate = Math.round((grp.enrolledCount / (grp.maxCapacity || 1)) * 100);
          const isFull = grp.enrolledCount >= grp.maxCapacity;

          return (
            <div
              key={grp.id}
              className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:border-slate-300 transition-all space-y-4"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className="text-[11px] font-semibold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md inline-block mb-1">
                      {grp.levelName}
                    </span>
                    <h3 className="font-bold text-sm text-slate-900 leading-snug">{grp.name}</h3>
                    <p className="text-xs text-slate-500 mt-0.5">الأستاذ: {grp.teacherName}</p>
                  </div>

                  <button
                    type="button"
                    onClick={() => onOpenEditGroupModal(grp)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                    title="تعديل المجموعة"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Capacity Occupancy Bar */}
                <div className="mt-4 pt-3 border-t border-slate-100 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-slate-500">الطاقة الاستيعابية:</span>
                    <span className="font-mono font-bold text-slate-800 tabular-nums">
                      {grp.enrolledCount} / {grp.maxCapacity} تلميذ
                    </span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all ${
                        isFull
                          ? 'bg-rose-500'
                          : occupancyRate > 75
                          ? 'bg-amber-500'
                          : 'bg-indigo-600'
                      }`}
                      style={{ width: `${Math.min(100, occupancyRate)}%` }}
                    />
                  </div>
                </div>

                {/* Schedule preview */}
                <div className="mt-3 space-y-1">
                  <span className="text-[11px] font-semibold text-slate-400">مواعيد الحصص:</span>
                  <div className="flex flex-wrap gap-1">
                    {grp.schedule.map((sch, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center gap-1 text-[11px] bg-slate-50 text-slate-600 border border-slate-200 px-2 py-0.5 rounded-md font-mono"
                      >
                        <Clock className="w-3 h-3 text-slate-400" />
                        {sch.day} {sch.timeStart}-{sch.timeEnd}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Footer / Fee & Actions */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <div>
                  <span className="text-[11px] text-slate-400 block">الواجب الشهري</span>
                  <span className="font-mono font-bold text-slate-900 text-sm tabular-nums">
                    {grp.monthlyFee} {settings.currency}
                  </span>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onTakeAttendance(grp.id)}
                >
                  تسجيل الحضور
                </Button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
