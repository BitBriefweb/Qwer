import React, { useState } from 'react';
import { Expense, ExpenseCategory, CenterSettings } from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Plus, Trash2, TrendingDown, Filter, Calendar } from 'lucide-react';

interface ExpensesViewProps {
  expenses: Expense[];
  settings: CenterSettings;
  onOpenNewExpenseModal: () => void;
  onDeleteExpense: (expense: Expense) => void;
}

const CATEGORY_LABELS: Record<ExpenseCategory, string> = {
  rent: 'إيجار المقر',
  salaries: 'رواتب وتعويضات الأساتذة',
  utilities: 'فواتير ماء وكهرباء وإنترنت',
  supplies: 'أدوات مكتبية ومطبوعات',
  maintenance: 'صيانة وتجهيزات ونظافة',
  marketing: 'إعلانات وتسويق',
  taxes: 'رسوم وضرائب وتأمينات',
  other: 'مصاريف أخرى',
};

export const ExpensesView: React.FC<ExpensesViewProps> = ({
  expenses,
  settings,
  onOpenNewExpenseModal,
  onDeleteExpense,
}) => {
  const [categoryFilter, setCategoryFilter] = useState('');

  const filtered = categoryFilter
    ? expenses.filter((e) => e.category === categoryFilter)
    : expenses;

  const totalAmount = filtered.reduce((acc, e) => acc + e.amount, 0);

  return (
    <div className="space-y-4">
      {/* Control Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <label className="text-xs font-semibold text-slate-600">تصفية حسب التصنيف:</label>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
          >
            <option value="">جميع التصنيفات</option>
            {Object.entries(CATEGORY_LABELS).map(([k, label]) => (
              <option key={k} value={k}>
                {label}
              </option>
            ))}
          </select>
        </div>

        <Button
          variant="primary"
          size="sm"
          icon={<Plus className="w-3.5 h-3.5" />}
          onClick={onOpenNewExpenseModal}
        >
          تسجيل مصروف جديد
        </Button>
      </div>

      {/* Summary Banner */}
      <div className="bg-slate-50 border border-slate-200 p-3.5 rounded-xl flex items-center justify-between text-xs text-slate-600">
        <div>
          <span>مجموع المصاريف المسجلة: </span>
          <strong className="text-rose-600 font-mono text-base mr-1 tabular-nums">
            {totalAmount.toFixed(2)} {settings.currency}
          </strong>
        </div>
        <span className="font-mono text-slate-500">
          {filtered.length} عملية مصروف
        </span>
      </div>

      {/* Expenses Table */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-xl border border-dashed border-slate-200 text-slate-500 space-y-3">
          <TrendingDown className="w-10 h-10 mx-auto text-slate-300" />
          <p className="text-sm font-semibold text-slate-700">لم يتم تسجيل أي مصاريف في هذا التصنيف</p>
          <Button variant="primary" size="sm" onClick={onOpenNewExpenseModal}>
            تسجيل مصروف جديد الآن
          </Button>
        </div>
      ) : (
        <div className="bg-white rounded-xl border border-slate-200/90 overflow-hidden shadow-xs">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
              <tr>
                <th className="py-3 px-3">تاريخ المصروف</th>
                <th className="py-3 px-3">عنوان وبيان المصروف</th>
                <th className="py-3 px-3">التصنيف</th>
                <th className="py-3 px-3">الجهة المستفيدة</th>
                <th className="py-3 px-3">رقم الفاتورة/المرجع</th>
                <th className="py-3 px-3">طريقة الدفع</th>
                <th className="py-3 px-3">المبلغ</th>
                <th className="py-3 px-3">المستلم/المسجل</th>
                <th className="py-3 px-3 text-left">حذف</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((e) => (
                <tr key={e.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3 px-3 font-mono text-slate-600">{e.date}</td>
                  <td className="py-3 px-3 font-bold text-slate-900">
                    {e.title}
                    {e.notes && <p className="text-[11px] font-normal text-slate-500 mt-0.5">{e.notes}</p>}
                  </td>
                  <td className="py-3 px-3">
                    <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded text-[11px]">
                      {CATEGORY_LABELS[e.category] || e.category}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-slate-700">{e.beneficiary || '---'}</td>
                  <td className="py-3 px-3 font-mono text-slate-500">{e.referenceDoc || '---'}</td>
                  <td className="py-3 px-3 text-slate-600">
                    {e.paymentMethod === 'cash' ? 'نقداً' : e.paymentMethod === 'transfer' ? 'تحويل' : 'شيك'}
                  </td>
                  <td className="py-3 px-3 font-mono font-bold text-rose-600 tabular-nums">
                    {e.amount.toFixed(2)} {settings.currency}
                  </td>
                  <td className="py-3 px-3 text-slate-500 font-mono text-[11px]">{e.recordedBy}</td>
                  <td className="py-3 px-3 text-left">
                    <button
                      type="button"
                      onClick={() => onDeleteExpense(e)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors cursor-pointer"
                      title="حذف المصروف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
