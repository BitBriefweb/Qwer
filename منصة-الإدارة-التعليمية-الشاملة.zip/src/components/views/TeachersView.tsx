import React, { useState, useEffect } from 'react';
import { Teacher, TeacherPaymentRecord, StudyGroup, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Button } from '../common/Button';
import { Modal } from '../common/Modal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import {
  Users,
  Plus,
  DollarSign,
  Phone,
  Mail,
  Edit2,
  Trash2,
  CreditCard,
  Printer,
  Calendar,
  Layers,
  Sparkles,
  CheckCircle2,
  Clock,
  Briefcase,
  FileText,
} from 'lucide-react';

interface TeachersViewProps {
  teachers: Teacher[];
  groups: StudyGroup[];
  settings: CenterSettings;
  onRefreshData: () => Promise<void>;
}

export const TeachersView: React.FC<TeachersViewProps> = ({
  teachers,
  groups,
  settings,
  onRefreshData,
}) => {
  const currentMonthKey = new Date().toISOString().substring(0, 7); // YYYY-MM
  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthKey);
  const [selectedTeacherForPay, setSelectedTeacherForPay] = useState<Teacher | null>(null);
  const [teacherEarningsData, setTeacherEarningsData] = useState<any | null>(null);
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [payAmount, setPayAmount] = useState<number>(0);
  const [payDetails, setPayDetails] = useState('');
  const [isSavingPay, setIsSavingPay] = useState(false);

  // Add / Edit Teacher Modal state
  const [isTeacherModalOpen, setIsTeacherModalOpen] = useState(false);
  const [teacherToEdit, setTeacherToEdit] = useState<Teacher | null>(null);
  const [teacherToDelete, setTeacherToDelete] = useState<Teacher | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);

  // Teacher Form state
  const [formName, setFormName] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formSpecialty, setFormSpecialty] = useState('');
  const [formCompensationType, setFormCompensationType] = useState<Teacher['compensationType']>('percentage');
  const [formRate, setFormRate] = useState<number>(50);
  const [formNotes, setFormNotes] = useState('');
  const [formStatus, setFormStatus] = useState<Teacher['status']>('active');

  // Printable Teacher Voucher
  const [paymentToPrint, setPaymentToPrint] = useState<TeacherPaymentRecord | null>(null);

  const openTeacherModal = (teacher?: Teacher) => {
    if (teacher) {
      setTeacherToEdit(teacher);
      setFormName(teacher.name);
      setFormPhone(teacher.phone);
      setFormEmail(teacher.email || '');
      setFormSpecialty(teacher.specialty);
      setFormCompensationType(teacher.compensationType);
      setFormRate(teacher.rate);
      setFormNotes(teacher.notes || '');
      setFormStatus(teacher.status);
    } else {
      setTeacherToEdit(null);
      setFormName('');
      setFormPhone('');
      setFormEmail('');
      setFormSpecialty('');
      setFormCompensationType('percentage');
      setFormRate(50);
      setFormNotes('');
      setFormStatus('active');
    }
    setIsTeacherModalOpen(true);
  };

  const handleSaveTeacher = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) return;

    if (teacherToEdit) {
      await dataService.updateTeacher(teacherToEdit.id, {
        name: formName,
        phone: formPhone,
        email: formEmail,
        specialty: formSpecialty,
        compensationType: formCompensationType,
        rate: Number(formRate),
        notes: formNotes,
        status: formStatus,
      });
    } else {
      await dataService.addTeacher({
        name: formName,
        phone: formPhone,
        email: formEmail,
        specialty: formSpecialty,
        compensationType: formCompensationType,
        rate: Number(formRate),
        notes: formNotes,
        status: formStatus,
      });
    }

    await onRefreshData();
    setIsTeacherModalOpen(false);
  };

  const handleOpenPayModal = async (teacher: Teacher) => {
    setSelectedTeacherForPay(teacher);
    const earnings = await dataService.calculateTeacherEarnings(teacher.id, selectedMonth);
    setTeacherEarningsData(earnings);
    setPayAmount(earnings.remainingDue > 0 ? earnings.remainingDue : earnings.estimatedEarnings);
    setPayDetails(`أتعاب شهر ${selectedMonth} - الأستاذ(ة) ${teacher.name}`);
    setIsPayModalOpen(true);
  };

  const handleConfirmPayTeacher = async () => {
    if (!selectedTeacherForPay || payAmount <= 0) return;
    try {
      setIsSavingPay(true);
      const record = await dataService.recordTeacherPayment({
        teacherId: selectedTeacherForPay.id,
        teacherName: selectedTeacherForPay.name,
        month: selectedMonth,
        amount: Number(payAmount),
        details: payDetails,
      });
      await onRefreshData();
      setIsPayModalOpen(false);
      setPaymentToPrint(record);
    } finally {
      setIsSavingPay(false);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200" dir="rtl">
      {/* Top Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="p-2 bg-indigo-50 text-indigo-600 rounded-xl">
              <Briefcase className="w-5 h-5" />
            </span>
            <h1 className="text-xl font-black text-slate-900 tracking-tight">
              تسيير هيئة التدريس ومستحقات الأساتذة
            </h1>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed max-w-2xl">
            إدارة عقود الأساتذة، احتساب أتعاب الحصص والنسب المئوية آلياً من مداخيل الأفواج، وصرف المستحقات مع التقييد الفوري في الخزينة والوصولات الرسمية.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {/* Month selector */}
          <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold">
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span>شهر المحاسبة:</span>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-white px-2 py-1 rounded-lg border border-slate-300 font-mono text-xs outline-none focus:border-indigo-500"
            />
          </div>

          <Button
            variant="primary"
            size="md"
            icon={<Plus className="w-4 h-4" />}
            onClick={() => openTeacherModal()}
          >
            + إضافة أستاذ(ة) جديد
          </Button>
        </div>
      </div>

      {/* Teachers Cards Grid */}
      {teachers.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border-2 border-dashed border-slate-200 space-y-3">
          <div className="w-12 h-12 bg-slate-100 text-slate-500 rounded-full flex items-center justify-center mx-auto">
            <Users className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-sm text-slate-800">لا يوجد أساتذة مسجلون حالياً</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto">
            أضف الأساتذة المؤطرين لفروع اللغات والمواد الدراسية لبدء تتبع أتعابهم ومستحقاتهم المالية الشهرية.
          </p>
          <Button variant="primary" size="sm" onClick={() => openTeacherModal()}>
            إضافة أول أستاذ الآن
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {teachers.map((teacher) => {
            const assignedGroups = groups.filter((g) => g.teacherName?.trim() === teacher.name?.trim());
            const compensationLabel =
              teacher.compensationType === 'percentage'
                ? `نسبة مئوية: ${teacher.rate}% من مداخيل الفوج`
                : teacher.compensationType === 'hourly'
                ? `أجر بالساعة: ${teacher.rate} ${settings.currency} / س`
                : `راتب شهري قار: ${teacher.rate} ${settings.currency}`;

            return (
              <div
                key={teacher.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-xs p-5 flex flex-col justify-between hover:shadow-md hover:border-slate-300 transition-all space-y-4"
              >
                <div className="space-y-3">
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-sm shadow-2xs">
                        {teacher.name.substring(0, 2)}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full ${teacher.status === 'active' ? 'bg-emerald-500' : 'bg-slate-400'}`} />
                          <span className="text-[10px] font-bold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded">
                            {teacher.specialty}
                          </span>
                        </div>
                        <h3 className="font-bold text-base text-slate-900 mt-0.5">{teacher.name}</h3>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        type="button"
                        onClick={() => openTeacherModal(teacher)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition-colors cursor-pointer"
                        title="تعديل بيانات الأستاذ"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => setTeacherToDelete(teacher)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                        title="حذف الأستاذ"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Compensation & Contact Box */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 space-y-2 text-xs">
                    <div className="flex items-center justify-between text-slate-700">
                      <span className="text-slate-500">صيغة الأتعاب:</span>
                      <span className="font-bold text-indigo-900 font-mono text-[11px] bg-white px-2 py-0.5 rounded border border-slate-200">
                        {compensationLabel}
                      </span>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-slate-500">الهاتف:</span>
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-slate-800">{teacher.phone || 'غير مسجل'}</span>
                        {teacher.phone && (
                          <a
                            href={`https://wa.me/212${teacher.phone.replace(/\D/g, '').replace(/^0/, '')}`}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-emerald-600 hover:text-emerald-800 font-bold"
                            title="مراسلة الأستاذ عبر واتساب"
                          >
                            💬
                          </a>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-slate-600">
                      <span className="text-slate-500">الأفواج المشرف عليها:</span>
                      <span className="font-bold text-slate-800">
                        {assignedGroups.length} أفواج دراسية
                      </span>
                    </div>
                  </div>

                  {/* Notes if any */}
                  {teacher.notes && (
                    <p className="text-[11px] text-slate-500 italic bg-amber-50/50 p-2 rounded-lg border border-amber-100">
                      {teacher.notes}
                    </p>
                  )}
                </div>

                {/* Bottom Action: Calculate & Pay */}
                <div className="pt-2 border-t border-slate-100 flex items-center gap-2">
                  <Button
                    variant="primary"
                    size="sm"
                    className="flex-1 justify-center shadow-xs"
                    icon={<CreditCard className="w-3.5 h-3.5" />}
                    onClick={() => handleOpenPayModal(teacher)}
                  >
                    احتساب وصرف الأتعاب ({selectedMonth})
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Pay Teacher Modal */}
      {isPayModalOpen && selectedTeacherForPay && teacherEarningsData && (
        <Modal
          isOpen={isPayModalOpen}
          onClose={() => setIsPayModalOpen(false)}
          title={`صرف مستحقات: ${selectedTeacherForPay.name}`}
          subtitle={`احتساب الأتعاب لشهر ${selectedMonth} - الصيغة: ${
            selectedTeacherForPay.compensationType === 'percentage'
              ? `${selectedTeacherForPay.rate}% من المداخيل`
              : `${selectedTeacherForPay.rate} ${settings.currency}`
          }`}
          maxWidth="lg"
        >
          <div className="space-y-4 text-xs" dir="rtl">
            {/* Calculation Breakdown Cards */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="text-center">
                <span className="block text-[11px] text-slate-500 font-medium">مداخيل الأفواج بالشهر</span>
                <span className="text-base font-bold font-mono text-slate-900">
                  {teacherEarningsData.totalGroupRevenue.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <div className="text-center border-r border-slate-200">
                <span className="block text-[11px] text-slate-500 font-medium">المستحقات المحتسبة</span>
                <span className="text-base font-bold font-mono text-indigo-700">
                  {teacherEarningsData.estimatedEarnings.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <div className="text-center border-r border-slate-200">
                <span className="block text-[11px] text-slate-500 font-medium">المصروف سابقاً</span>
                <span className="text-base font-bold font-mono text-emerald-700">
                  {teacherEarningsData.paymentsAlreadyMade.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <div className="text-center border-r border-slate-200">
                <span className="block text-[11px] text-slate-500 font-medium">المتبقي للصرف</span>
                <span className="text-base font-black font-mono text-amber-700">
                  {teacherEarningsData.remainingDue.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
            </div>

            {/* Groups Detail Table */}
            {teacherEarningsData.groupsTaught.length > 0 && (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="bg-slate-100 p-2 font-bold text-slate-700 text-xs">
                  تفاصيل المداخيل حسب أفواج الأستاذ:
                </div>
                <div className="divide-y divide-slate-100 bg-white">
                  {teacherEarningsData.groupsTaught.map((grp: any) => (
                    <div key={grp.id} className="p-2.5 flex items-center justify-between">
                      <span className="font-semibold text-slate-800">{grp.name} ({grp.studentCount} تلميذ)</span>
                      <span className="font-mono font-bold text-indigo-700">
                        {grp.revenue.toLocaleString('fr-FR')} {settings.currency}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Payment Input Form */}
            <div className="p-4 bg-indigo-50/50 rounded-xl border border-indigo-100 space-y-3">
              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  المبلغ المؤدى للأستاذ(ة) بالدرهم ({settings.currency}):
                </label>
                <input
                  type="number"
                  min="1"
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  className="w-full p-2.5 text-base font-bold font-mono bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">
                  بيان وتفاصيل الدفعة (سيظهر بالوصل وقيد المصاريف):
                </label>
                <input
                  type="text"
                  value={payDetails}
                  onChange={(e) => setPayDetails(e.target.value)}
                  className="w-full p-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
              <Button variant="outline" size="sm" onClick={() => setIsPayModalOpen(false)}>
                إلغاء
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={handleConfirmPayTeacher}
                isLoading={isSavingPay}
                disabled={payAmount <= 0}
              >
                تأكيد صرف الأتعاب واستخراج الوصل 🧾
              </Button>
            </div>
          </div>
        </Modal>
      )}

      {/* Add / Edit Teacher Modal */}
      <Modal
        isOpen={isTeacherModalOpen}
        onClose={() => setIsTeacherModalOpen(false)}
        title={teacherToEdit ? 'تعديل بيانات الأستاذ(ة)' : 'إضافة أستاذ(ة) مؤطر جديد'}
        subtitle="تحديد التخصص وصيغة الأتعاب (نسبة مئوية أو أجر بالساعة أو راتب شهري)"
        maxWidth="md"
      >
        <form onSubmit={handleSaveTeacher} className="space-y-4 text-xs" dir="rtl">
          <div>
            <label className="block font-bold text-slate-700 mb-1">الاسم الكامل للأستاذ(ة) *</label>
            <input
              type="text"
              value={formName}
              onChange={(e) => setFormName(e.target.value)}
              placeholder="مثال: ذ. كريم الفاسي"
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">التخصص / المادة المؤطرة *</label>
              <input
                type="text"
                value={formSpecialty}
                onChange={(e) => setFormSpecialty(e.target.value)}
                placeholder="مثال: اللغة الألمانية، الرياضيات..."
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">رقم الهاتف (للتواصل والواتساب)</label>
              <input
                type="text"
                value={formPhone}
                onChange={(e) => setFormPhone(e.target.value)}
                placeholder="0661223344"
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-bold text-slate-700 mb-1">صيغة احتساب الأتعاب *</label>
              <select
                value={formCompensationType}
                onChange={(e) => setFormCompensationType(e.target.value as any)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="percentage">نسبة مئوية (%) من اشتراكات الفوج</option>
                <option value="hourly">أجر بالساعة أو الحصة (د.م / ساعة)</option>
                <option value="monthly_fixed">راتب شهري قار وثابت (د.م / شهر)</option>
              </select>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                {formCompensationType === 'percentage'
                  ? 'النسبة المئوية للأستاذ (%):'
                  : formCompensationType === 'hourly'
                  ? 'أجر الساعة الواحدة (د.م):'
                  : 'الراتب الشهري الثابت (د.م):'}
              </label>
              <input
                type="number"
                min="0"
                value={formRate}
                onChange={(e) => setFormRate(Number(e.target.value))}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-bold"
                required
              />
            </div>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">ملاحظات وشروط خاصة</label>
            <textarea
              rows={2}
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              placeholder="مثال: مؤطر المستويات الإشهادية فقط، التفرغ المسائي..."
              className="w-full p-2 bg-slate-50 border border-slate-200 rounded-lg focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
            <Button variant="outline" size="sm" type="button" onClick={() => setIsTeacherModalOpen(false)}>
              إلغاء
            </Button>
            <Button variant="primary" size="sm" type="submit">
              {teacherToEdit ? 'حفظ التعديلات' : 'إضافة الأستاذ'}
            </Button>
          </div>
        </form>
      </Modal>

      {/* Delete Teacher Confirmation Dialog */}
      <ConfirmDialog
        isOpen={Boolean(teacherToDelete)}
        onClose={() => setTeacherToDelete(null)}
        onConfirm={async () => {
          if (!teacherToDelete) return;
          try {
            setIsDeleting(true);
            await dataService.deleteTeacher(teacherToDelete.id);
            await onRefreshData();
            setTeacherToDelete(null);
          } finally {
            setIsDeleting(false);
          }
        }}
        title={`تأكيد حذف الأستاذ(ة) "${teacherToDelete?.name}"`}
        message={`هل أنت متأكد من حذف ملف الأستاذ "${teacherToDelete?.name}"؟ السجلات والمصاريف المؤداة سابقاً ستظل محفوظة في سجلات الخزينة.`}
        confirmText="تأكيد الحذف"
        variant="danger"
        isLoading={isDeleting}
      />

      {/* Printable Teacher Payment Voucher Modal */}
      {paymentToPrint && (
        <Modal
          isOpen={Boolean(paymentToPrint)}
          onClose={() => setPaymentToPrint(null)}
          title={`وصل صرف أتعاب: ${paymentToPrint.receiptNumber}`}
          subtitle="طباعة إيصال صرف مستحقات الأستاذ للتوقيع والتوثيق المحاسبي"
          maxWidth="md"
        >
          <div className="space-y-4 p-4 bg-white border border-slate-200 rounded-xl" dir="rtl">
            <div className="border-b-2 border-slate-800 pb-3 text-center space-y-1">
              <h2 className="font-black text-base text-slate-900">{settings.centerName}</h2>
              <p className="text-xs text-slate-500">وصل صرف مستحقات وهيئة التدريس</p>
              <div className="font-mono text-xs text-indigo-700 font-bold">{paymentToPrint.receiptNumber}</div>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">اسم الأستاذ(ة):</span>
                <span className="font-bold text-slate-900">{paymentToPrint.teacherName}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">عن شهر:</span>
                <span className="font-bold font-mono">{paymentToPrint.month}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">تاريخ الصرف:</span>
                <span className="font-mono">{paymentToPrint.paymentDate}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">المبلغ الصافي المصروف:</span>
                <span className="text-base font-black font-mono text-indigo-700">
                  {paymentToPrint.amount.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <div className="py-1">
                <span className="text-slate-500 block">البيان:</span>
                <span className="text-slate-800 font-medium">{paymentToPrint.details}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-6 text-center text-xs">
              <div className="space-y-8">
                <span className="font-bold text-slate-600 block">توقيع المسؤول المالي / الإدارة</span>
                <div className="border-t border-slate-300 w-32 mx-auto" />
              </div>
              <div className="space-y-8">
                <span className="font-bold text-slate-600 block">توقيع واستلام الأستاذ</span>
                <div className="border-t border-slate-300 w-32 mx-auto" />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
              <Button variant="outline" size="sm" onClick={() => setPaymentToPrint(null)}>
                إغلاق
              </Button>
              <Button
                variant="primary"
                size="sm"
                icon={<Printer className="w-3.5 h-3.5" />}
                onClick={() => window.print()}
              >
                طباعة الإيصال الرسمي
              </Button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};
