import React, { useState } from 'react';
import { StudentWithDetails, Level, StudyGroup, CenterSettings } from '../../types';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import {
  Search,
  UserPlus,
  Eye,
  CreditCard,
  Edit2,
  Trash2,
  ArrowLeftRight,
  Filter,
  Download,
  Phone,
  PowerOff,
  GraduationCap,
  Printer,
  LayoutGrid,
  List,
  CheckCircle,
  AlertCircle,
  Calendar,
  BookOpen,
} from 'lucide-react';

interface StudentsViewProps {
  students: StudentWithDetails[];
  levels: Level[];
  groups: StudyGroup[];
  settings: CenterSettings;
  onOpenNewModal: () => void;
  onOpenEditModal: (student: StudentWithDetails) => void;
  onSelectStudent: (student: StudentWithDetails) => void;
  onOpenPaymentModal: (student: StudentWithDetails) => void;
  onOpenTransferModal: (student: StudentWithDetails) => void;
  onToggleStatus: (student: StudentWithDetails) => void;
  onDeleteStudent: (student: StudentWithDetails) => void;
  onPrintStudentCard?: (student: StudentWithDetails) => void;
}

export const StudentsView: React.FC<StudentsViewProps> = ({
  students,
  levels,
  groups,
  settings,
  onOpenNewModal,
  onOpenEditModal,
  onSelectStudent,
  onOpenPaymentModal,
  onOpenTransferModal,
  onToggleStatus,
  onDeleteStudent,
  onPrintStudentCard,
}) => {
  const [search, setSearch] = useState('');
  const [selectedLevelId, setSelectedLevelId] = useState<string>('all');
  const [groupFilter, setGroupFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'table' | 'grid'>('grid');

  // Filter logic
  const filtered = students.filter((s) => {
    if (selectedLevelId !== 'all' && s.levelId !== selectedLevelId) return false;
    if (statusFilter !== 'all' && s.status !== statusFilter) return false;
    if (
      groupFilter &&
      !s.enrolledGroups.some((g: { id: string; name: string }) => g.id === groupFilter)
    ) {
      return false;
    }

    if (search.trim()) {
      const q = search.trim().toLowerCase();
      const matchName = s.fullName.toLowerCase().includes(q);
      const matchCode = s.code.toLowerCase().includes(q);
      const matchPhone = s.guardianPhone.includes(q);
      const matchGuardian = s.guardianName.toLowerCase().includes(q);
      if (!matchName && !matchCode && !matchPhone && !matchGuardian) return false;
    }

    return true;
  });

  const exportCSV = () => {
    const headers = [
      'رقم التسجيل',
      'الاسم الكامل',
      'ولي الأمر',
      'الهاتف',
      'المستوى الدراسي',
      'المجموعات',
      'الحالة',
      'المبلغ المستحق',
      'المؤدى',
      'المتبقي',
    ];
    const rows = filtered.map((s) => {
      const lvl = levels.find((l) => l.id === s.levelId)?.name || '';
      const grps = s.enrolledGroups.map((g: { name: string }) => g.name).join(' | ');
      return [
        s.code,
        s.fullName,
        s.guardianName,
        s.guardianPhone,
        lvl,
        grps,
        s.status === 'active' ? 'نشط' : s.status === 'suspended' ? 'موقوف' : 'غير نشط',
        s.totalCharges,
        s.totalPaid,
        s.remainingBalance,
      ];
    });

    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `students_export_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-5">
      {/* Top Header & Tactical Action Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200/90 shadow-2xs">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-black text-slate-900 tracking-tight">
              سجلات وشؤون التلاميذ
            </h2>
            <span className="bg-indigo-100 text-indigo-800 text-xs font-bold px-2.5 py-0.5 rounded-full border border-indigo-200 font-mono">
              {filtered.length} تلميذ
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-1">
            إدارة الملفات الشاملة، متابعة المستحقات المالية، الحضور، وتوليد البطاقات المدرسية
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Grid vs Table View Mode Switcher */}
          <div className="flex items-center p-1 bg-slate-100 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'grid'
                  ? 'bg-white text-indigo-600 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="عرض كبطاقات شبكية"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                viewMode === 'table'
                  ? 'bg-white text-indigo-600 shadow-2xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="عرض كجدول تنفيذي"
            >
              <List className="w-4 h-4" />
            </button>
          </div>

          <Button
            variant="outline"
            size="sm"
            icon={<Download className="w-4 h-4 text-slate-600" />}
            onClick={exportCSV}
          >
            تصدير CSV
          </Button>

          <Button
            variant="primary"
            size="sm"
            icon={<UserPlus className="w-4 h-4 text-white" />}
            onClick={onOpenNewModal}
            className="shadow-sm shadow-indigo-600/30"
          >
            تسجيل تلميذ جديد
          </Button>
        </div>
      </div>

      {/* Level Filter Tabs (Segmented Control) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-thin">
        <button
          type="button"
          onClick={() => setSelectedLevelId('all')}
          className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
            selectedLevelId === 'all'
              ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
              : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
          }`}
        >
          <span>كافة المستويات</span>
          <span
            className={`text-[10px] px-1.5 py-0.2 rounded-full ${
              selectedLevelId === 'all' ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
            }`}
          >
            {students.length}
          </span>
        </button>

        {levels.map((lvl) => {
          const count = students.filter((s) => s.levelId === lvl.id).length;
          const isSelected = selectedLevelId === lvl.id;
          return (
            <button
              key={lvl.id}
              type="button"
              onClick={() => setSelectedLevelId(lvl.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer flex items-center gap-1.5 ${
                isSelected
                  ? 'bg-indigo-600 text-white shadow-xs shadow-indigo-600/30'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <span>{lvl.name}</span>
              <span
                className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                  isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                }`}
              >
                {count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search and Advanced Filters Row */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-2xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
          {/* Main Search Input */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3 pointer-events-none" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="ابحث بالاسم الكامل، رقم التعريف (STU-...)، أو هاتف ولي الأمر..."
              className="w-full pr-9 pl-4 py-2 text-xs bg-slate-50 hover:bg-white focus:bg-white border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none transition-all"
            />
          </div>

          {/* Group Filter */}
          <div className="sm:col-span-3">
            <select
              value={groupFilter}
              onChange={(e) => setGroupFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="">كافة الأفواج الدراسية</option>
              {groups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="sm:col-span-3">
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="all">كافة الحالات (النشطون والموقوفون)</option>
              <option value="active">النشطون فقط</option>
              <option value="suspended">الموقوفون مؤقتاً</option>
              <option value="inactive">غير النشطين</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Display: Grid vs Table */}
      {filtered.length === 0 ? (
        <div className="text-center py-16 bg-white rounded-2xl border border-dashed border-slate-300 text-slate-500 space-y-3">
          <GraduationCap className="w-12 h-12 mx-auto text-slate-300" />
          <p className="text-base font-bold text-slate-800">لم يتم العثور على أي تلميذ مطابق للبحث</p>
          <p className="text-xs text-slate-400">
            جرب تعديل شروط البحث أو مسح الفلاتر المحددة لعرض التلاميذ.
          </p>
          <Button variant="primary" size="sm" onClick={onOpenNewModal}>
            تسجيل تلميذ جديد الآن
          </Button>
        </div>
      ) : viewMode === 'grid' ? (
        /* Rich Grid Card View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((s) => {
            const levelObj = levels.find((l) => l.id === s.levelId);
            const isDebtor = s.remainingBalance > 0;

            return (
              <div
                key={s.id}
                className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs hover:shadow-md transition-all duration-200 p-5 space-y-4 flex flex-col justify-between group relative overflow-hidden"
              >
                {/* Top Corner Ribbon / Badge */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    {/* Student Initials Avatar */}
                    <div className="w-12 h-12 rounded-2xl bg-linear-to-tr from-indigo-700 to-indigo-500 text-white font-black text-lg flex items-center justify-center shrink-0 shadow-xs border border-indigo-400/20">
                      {s.fullName.charAt(0)}
                    </div>
                    <div>
                      <button
                        type="button"
                        onClick={() => onSelectStudent(s)}
                        className="font-extrabold text-sm text-slate-900 hover:text-indigo-600 transition-colors text-right block cursor-pointer"
                      >
                        {s.fullName}
                      </button>
                      <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
                        <span className="font-mono text-[11px] font-bold text-slate-600 bg-slate-100 px-1.5 py-0.2 rounded">
                          {s.code}
                        </span>
                        <span>·</span>
                        <span className="text-[11px] font-medium text-indigo-700">
                          {levelObj?.name || '---'}
                        </span>
                      </div>
                    </div>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                      s.status === 'active'
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                        : s.status === 'suspended'
                        ? 'bg-amber-50 text-amber-700 border-amber-200'
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}
                  >
                    {s.status === 'active' ? 'نشط' : s.status === 'suspended' ? 'موقوف' : 'غير نشط'}
                  </span>
                </div>

                {/* Enrolled Groups */}
                <div className="space-y-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-xs">
                  <span className="text-[10px] font-semibold text-slate-400 block">
                    الأفواج والمواد:
                  </span>
                  {s.enrolledGroups.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {s.enrolledGroups.map((g) => (
                        <span
                          key={g.id}
                          className="bg-white text-slate-700 border border-slate-200 px-2 py-0.5 rounded-md text-[11px] font-medium"
                        >
                          {g.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-[11px] text-slate-400 italic">غير مسجل بأي فوج</span>
                  )}
                </div>

                {/* Guardian Phone & Contact */}
                <div className="flex items-center justify-between text-xs text-slate-600 pt-1">
                  <span className="text-[11px] text-slate-500">
                    ولي الأمر: <strong className="text-slate-800">{s.guardianName}</strong>
                  </span>
                  <a
                    href={`tel:${s.guardianPhone}`}
                    className="flex items-center gap-1 font-mono text-[11px] text-indigo-600 hover:text-indigo-800 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded-md transition-colors"
                    dir="ltr"
                  >
                    <Phone className="w-3 h-3 text-indigo-500" />
                    <span>{s.guardianPhone}</span>
                  </a>
                </div>

                {/* Financial Status Footer & Actions */}
                <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">الوضعية المالية:</span>
                    {isDebtor ? (
                      <span className="text-xs font-black text-rose-600 font-mono tabular-nums">
                        باقي: {s.remainingBalance.toFixed(2)} {settings.currency}
                      </span>
                    ) : (
                      <span className="text-xs font-bold text-emerald-700 flex items-center gap-1">
                        <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                        <span>مستوفى الأداء</span>
                      </span>
                    )}
                  </div>

                  {/* Actions Palette */}
                  <div className="flex items-center gap-1">
                    {onPrintStudentCard && (
                      <button
                        type="button"
                        onClick={() => onPrintStudentCard(s)}
                        className="p-1.5 rounded-lg text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 border border-slate-200 transition-colors cursor-pointer"
                        title="طباعة البطاقة المدرسية"
                      >
                        <Printer className="w-4 h-4" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onOpenPaymentModal(s)}
                      className="px-2.5 py-1 rounded-lg text-xs font-bold bg-emerald-50 hover:bg-emerald-100 text-emerald-700 border border-emerald-200 transition-colors flex items-center gap-1 cursor-pointer"
                      title="تسجيل أداء مالي"
                    >
                      <CreditCard className="w-3.5 h-3.5" />
                      <span>أداء</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onSelectStudent(s)}
                      className="p-1.5 rounded-lg text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors cursor-pointer"
                      title="الملف الشامل"
                    >
                      <Eye className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Executive Table View */
        <div className="bg-white rounded-2xl border border-slate-200/90 overflow-hidden shadow-2xs">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
              <tr>
                <th className="py-3 px-3">رقم التعريف</th>
                <th className="py-3 px-3">الاسم الكامل للتلميذ</th>
                <th className="py-3 px-3">المستوى الدراسي</th>
                <th className="py-3 px-3">المجموعات المقيد بها</th>
                <th className="py-3 px-3">ولي الأمر والهاتف</th>
                <th className="py-3 px-3">الحالة</th>
                <th className="py-3 px-3">المتبقي بذمته</th>
                <th className="py-3 px-3 text-left">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((s) => {
                const levelObj = levels.find((l) => l.id === s.levelId);
                const isDebtor = s.remainingBalance > 0;

                return (
                  <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                    <td className="py-3 px-3 font-mono font-bold text-slate-700">{s.code}</td>
                    <td className="py-3 px-3">
                      <button
                        type="button"
                        onClick={() => onSelectStudent(s)}
                        className="font-bold text-slate-900 hover:text-indigo-600 cursor-pointer"
                      >
                        {s.fullName}
                      </button>
                    </td>
                    <td className="py-3 px-3 text-slate-600 font-medium">
                      {levelObj?.name || '---'}
                    </td>
                    <td className="py-3 px-3 max-w-[200px] truncate text-slate-600">
                      {s.enrolledGroups.length > 0
                        ? s.enrolledGroups.map((g) => g.name).join('، ')
                        : 'غير مسجل بأي فوج'}
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-slate-800 font-semibold">{s.guardianName}</div>
                      <div className="font-mono text-[11px] text-slate-500" dir="ltr">
                        {s.guardianPhone}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${
                          s.status === 'active'
                            ? 'bg-emerald-50 text-emerald-700 border-emerald-200'
                            : s.status === 'suspended'
                            ? 'bg-amber-50 text-amber-700 border-amber-200'
                            : 'bg-rose-50 text-rose-700 border-rose-200'
                        }`}
                      >
                        {s.status === 'active'
                          ? 'نشط'
                          : s.status === 'suspended'
                          ? 'موقوف'
                          : 'غير نشط'}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-mono font-bold tabular-nums">
                      <span className={isDebtor ? 'text-rose-600 font-black' : 'text-emerald-700'}>
                        {s.remainingBalance.toFixed(2)} {settings.currency}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-left">
                      <div className="flex items-center justify-end gap-1">
                        {onPrintStudentCard && (
                          <button
                            type="button"
                            onClick={() => onPrintStudentCard(s)}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                            title="طباعة البطاقة المدرسية"
                          >
                            <Printer className="w-4 h-4" />
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onSelectStudent(s)}
                          className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                          title="عرض الملف الشامل"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenPaymentModal(s)}
                          className="p-1.5 text-slate-500 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors cursor-pointer"
                          title="تسجيل أداء مالي"
                        >
                          <CreditCard className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenTransferModal(s)}
                          className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                          title="تحويل إلى مجموعة أخرى"
                        >
                          <ArrowLeftRight className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onOpenEditModal(s)}
                          className="p-1.5 text-slate-500 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                          title="تعديل البيانات"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onToggleStatus(s)}
                          className={`p-1.5 rounded-lg transition-colors cursor-pointer ${
                            s.status === 'suspended'
                              ? 'text-emerald-600 hover:bg-emerald-50'
                              : 'text-amber-600 hover:bg-amber-50'
                          }`}
                          title={s.status === 'suspended' ? 'إعادة التفعيل' : 'إيقاف مؤقت'}
                        >
                          <PowerOff className="w-4 h-4" />
                        </button>
                        <button
                          type="button"
                          onClick={() => onDeleteStudent(s)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                          title="حذف ملف التلميذ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
