import React, { useState } from 'react';
import { StudentWithDetails, Expense, Payment, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Printer, Download, Phone, AlertTriangle, FileSpreadsheet, CheckCircle2, MessageCircle } from 'lucide-react';

interface ReportsViewProps {
  students: StudentWithDetails[];
  payments: Payment[];
  expenses: Expense[];
  settings: CenterSettings;
  onOpenPaymentModal: (student: StudentWithDetails) => void;
}

export const ReportsView: React.FC<ReportsViewProps> = ({
  students,
  payments,
  expenses,
  settings,
  onOpenPaymentModal,
}) => {
  const [reportType, setReportType] = useState<'debtors' | 'cashflow'>('debtors');

  const debtorStudents = students
    .filter((s) => s.remainingBalance > 0)
    .sort((a, b) => b.remainingBalance - a.remainingBalance);

  const totalDebtorAmount = debtorStudents.reduce((acc, s) => acc + s.remainingBalance, 0);

  const totalCollected = payments
    .filter((p) => p.status === 'completed')
    .reduce((acc, p) => acc + p.amountPaid, 0);

  const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
  const netCash = totalCollected - totalExpenses;

  const handlePrint = () => {
    window.print();
  };

  const exportDebtorsCSV = () => {
    const headers = [
      'رقم التسجيل',
      'اسم التلميذ',
      'المستوى',
      'اسم ولي الأمر',
      'رقم هاتف ولي الأمر',
      'المجموعات',
      'المبلغ المتبقي بالدرهم',
    ];
    const rows = debtorStudents.map((s) => [
      s.code,
      s.fullName,
      s.levelId,
      s.guardianName,
      s.guardianPhone,
      s.enrolledGroups.map((g: { name: string }) => g.name).join(' | '),
      s.remainingBalance,
    ]);

    const csvContent =
      '\uFEFF' +
      [headers.join(','), ...rows.map((r) => r.map((c) => `"${c}"`).join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `itqan_debtors_${new Date().toISOString().substring(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Report Switcher Toolbar */}
      <div className="no-print bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setReportType('debtors')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              reportType === 'debtors'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            تقرير المتأخرات والديون ({debtorStudents.length})
          </button>
          <button
            type="button"
            onClick={() => setReportType('cashflow')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
              reportType === 'cashflow'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            كشف المقارنة والسيولة النقدية (المداخيل / المصاريف)
          </button>
        </div>

        <div className="flex items-center gap-2">
          {reportType === 'debtors' && (
            <Button
              variant="outline"
              size="sm"
              icon={<Download className="w-3.5 h-3.5" />}
              onClick={exportDebtorsCSV}
            >
              تصدير المتأخرات (CSV)
            </Button>
          )}
          <Button
            variant="primary"
            size="sm"
            icon={<Printer className="w-3.5 h-3.5" />}
            onClick={handlePrint}
          >
            طباعة التقرير (A4)
          </Button>
        </div>
      </div>

      {/* Printable Report Document Container */}
      <div id="printable-receipt-container" className="bg-white rounded-xl border border-slate-200/90 shadow-xs p-6 space-y-6">
        {/* Printable Official Header */}
        <div className="flex items-center justify-between pb-4 border-b-2 border-slate-900">
          <div>
            <h2 className="text-lg font-bold text-slate-900">{settings.centerName}</h2>
            <p className="text-xs text-slate-500 mt-0.5">{settings.address} · هاتف: {settings.phone}</p>
          </div>
          <div className="text-left">
            <h3 className="text-sm font-bold text-slate-800">
              {reportType === 'debtors'
                ? 'تقرير التلاميذ المدينين والمتأخرات المالية'
                : 'كشف التدفقات النقدية والمصاريف التشغيلية'}
            </h3>
            <span className="text-xs text-slate-500 font-mono">
              تاريخ الاستخراج: {new Date().toISOString().substring(0, 10)}
            </span>
          </div>
        </div>

        {/* Report 1: DEBTORS */}
        {reportType === 'debtors' && (
          <div className="space-y-4">
            <div className="bg-rose-50 border border-rose-200 p-4 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-xs font-semibold text-rose-800 block">
                  إجمالي المبالغ والديون غير المحصلة في ذمة التلاميذ
                </span>
                <span className="text-2xl font-bold text-rose-700 font-mono tabular-nums">
                  {totalDebtorAmount.toFixed(2)} {settings.currency}
                </span>
              </div>
              <div className="text-left text-xs text-rose-700 font-medium">
                عدد التلاميذ المتأخرين عن الأداء:{' '}
                <strong className="font-mono text-base">{debtorStudents.length}</strong> تلميذ
              </div>
            </div>

            {debtorStudents.length === 0 ? (
              <div className="text-center py-12 text-emerald-700 bg-emerald-50 rounded-xl border border-emerald-200">
                <CheckCircle2 className="w-8 h-8 mx-auto mb-2 text-emerald-600" />
                <p className="font-bold text-sm">تهانينا! جميع التلاميذ مسددون لواجباتهم بالكامل.</p>
              </div>
            ) : (
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-100 border-b border-slate-200 text-slate-700 font-bold">
                    <tr>
                      <th className="py-2.5 px-3 w-10 text-center">#</th>
                      <th className="py-2.5 px-3">رقم التسجيل</th>
                      <th className="py-2.5 px-3">اسم التلميذ</th>
                      <th className="py-2.5 px-3">المجموعات المقيد بها</th>
                      <th className="py-2.5 px-3">اسم ولي الأمر</th>
                      <th className="py-2.5 px-3">رقم الهاتف</th>
                      <th className="py-2.5 px-3 text-left">المبلغ المتبقي</th>
                      <th className="no-print py-2.5 px-3 text-center">إجراء</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {debtorStudents.map((s, idx) => (
                      <tr key={s.id} className="hover:bg-slate-50 transition-colors">
                        <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                          {idx + 1}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-bold text-slate-700">{s.code}</td>
                        <td className="py-2.5 px-3 font-bold text-slate-900">{s.fullName}</td>
                        <td className="py-2.5 px-3 text-slate-600">
                          {s.enrolledGroups.map((g: { name: string }) => g.name).join('، ')}
                        </td>
                        <td className="py-2.5 px-3 text-slate-800">{s.guardianName}</td>
                        <td className="py-2.5 px-3 font-mono text-slate-700" dir="ltr">
                          <a
                            href={`tel:${s.guardianPhone}`}
                            className="hover:text-indigo-600 flex items-center gap-1"
                          >
                            <Phone className="w-3 h-3 text-slate-400 no-print" />
                            {s.guardianPhone}
                          </a>
                        </td>
                        <td className="py-2.5 px-3 text-left font-mono font-bold text-rose-600 tabular-nums">
                          {s.remainingBalance.toFixed(2)} {settings.currency}
                        </td>
                        <td className="no-print py-2.5 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              type="button"
                              onClick={() => onOpenPaymentModal(s)}
                              className="px-2 py-1 text-[11px] font-semibold bg-indigo-50 text-indigo-700 hover:bg-indigo-600 hover:text-white rounded-md transition-colors cursor-pointer"
                            >
                              تسجيل أداء
                            </button>
                            {s.guardianPhone && (
                              <a
                                href={dataService.getWhatsAppDebtReminderUrl(
                                  s,
                                  s.remainingBalance,
                                  settings.centerName,
                                  settings.currency
                                )}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="px-2 py-1 text-[11px] font-bold bg-emerald-50 text-emerald-800 hover:bg-emerald-600 hover:text-white border border-emerald-300 rounded-md transition-colors cursor-pointer flex items-center gap-1"
                                title="إرسال تذكير بالواجبات المستحقة عبر واتساب"
                              >
                                <span>💬 واتساب</span>
                              </a>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* Report 2: CASHFLOW STATEMENT */}
        {reportType === 'cashflow' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="bg-emerald-50 p-4 rounded-xl border border-emerald-200">
                <span className="text-xs font-semibold text-emerald-800 block">إجمالي المقبوضات المحصلة</span>
                <span className="text-2xl font-bold text-emerald-700 font-mono tabular-nums mt-1 block">
                  {totalCollected.toFixed(2)} {settings.currency}
                </span>
                <span className="text-[11px] text-emerald-600 mt-1 block">مجموع وصولات الأداء المعتمدة</span>
              </div>

              <div className="bg-rose-50 p-4 rounded-xl border border-rose-200">
                <span className="text-xs font-semibold text-rose-800 block">إجمالي المصاريف والتشغيل</span>
                <span className="text-2xl font-bold text-rose-700 font-mono tabular-nums mt-1 block">
                  {totalExpenses.toFixed(2)} {settings.currency}
                </span>
                <span className="text-[11px] text-rose-600 mt-1 block">إيجار، رواتب، وفواتير</span>
              </div>

              <div className="bg-indigo-50 p-4 rounded-xl border border-indigo-200">
                <span className="text-xs font-semibold text-indigo-800 block">صافي السيولة النقدية المتوفرة</span>
                <span className="text-2xl font-bold text-indigo-700 font-mono tabular-nums mt-1 block">
                  {netCash.toFixed(2)} {settings.currency}
                </span>
                <span className="text-[11px] text-indigo-600 mt-1 block">الفرق الصافي بين المحصل والمصروف</span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600 leading-relaxed">
              <strong>تنبيه محاسبي مهني:</strong> الفرق المحسوب يمثل (صافي السيولة النقدية / Net Cashflow)
              الفعلية المحصلة مطروحاً منها المصاريف المسجلة، ولا يمثل بالضرورة الربح المحاسبي الخالص
              إن كانت هناك التزامات أو ديون لم تُسجل بعد في النظام.
            </div>
          </div>
        )}

        {/* Official Signature line */}
        <div className="pt-8 border-t border-slate-200 flex justify-between items-end text-xs text-slate-500">
          <div>
            <span>توقيع وخاتم إدارة المؤسسة: </span>
            <div className="h-16 w-36 border-b border-dashed border-slate-300 mt-2" />
          </div>
          <div className="text-left font-mono">
            {settings.centerName} · {settings.academicYear}
          </div>
        </div>
      </div>
    </div>
  );
};
