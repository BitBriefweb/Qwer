import React from 'react';
import {
  StudentWithDetails,
  StudyGroup,
  Payment,
  Expense,
  CenterSettings,
  AuditLog,
  User,
  ConnectedDevice,
} from '../../types';
import { FinancialStats } from '../../services/data-service';
import { Button } from '../common/Button';
import {
  Users,
  GraduationCap,
  CreditCard,
  AlertCircle,
  TrendingDown,
  CalendarCheck,
  UserPlus,
  Printer,
  Phone,
  ArrowRight,
  Sparkles,
  Receipt,
  PlusCircle,
  FileSpreadsheet,
} from 'lucide-react';

interface DashboardViewProps {
  students: StudentWithDetails[];
  groups: StudyGroup[];
  payments: Payment[];
  expenses: Expense[];
  stats: FinancialStats;
  settings: CenterSettings;
  auditLogs: AuditLog[];
  currentUser?: User;
  analytics?: any;
  devices?: ConnectedDevice[];
  onOpenPaymentModal: (student?: StudentWithDetails) => void;
  onOpenNewStudentModal: () => void;
  onSelectStudent: (student: StudentWithDetails) => void;
  onPrintPayment: (payment: Payment) => void;
  onNavigateSection: (section: any) => void;
  onOpenMobileTerminal?: (device: ConnectedDevice) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  students,
  groups,
  payments,
  expenses,
  stats,
  settings,
  currentUser,
  onOpenPaymentModal,
  onOpenNewStudentModal,
  onSelectStudent,
  onPrintPayment,
  onNavigateSection,
}) => {
  const activeStudents = students.filter((s) => s.status === 'active');
  const debtorStudents = students.filter((s) => s.remainingBalance > 0);
  const recentPayments = payments.slice(0, 5);

  const todayDateFormatted = new Intl.DateTimeFormat('ar-MA', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <div className="space-y-6" dir="rtl">
      {/* 1. Welcoming & Friendly Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white rounded-2xl p-6 shadow-sm border border-slate-800 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[11px] font-bold">
              ● المنظومة جاهزة وسريعة
            </span>
            <span className="text-slate-400 text-xs font-mono">{todayDateFormatted}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-white">
            مرحباً بك في {settings.centerName || 'منظومة إتقان المدرسية'}
          </h1>
          <p className="text-xs text-indigo-200">
            {settings.directorName ? `إشراف الإدارة العامة: ${settings.directorName}` : 'لوحة التحكم السريعة'}
          </p>
        </div>

        {/* Quick Month Revenue Summary */}
        <div className="bg-white/10 backdrop-blur-md px-4 py-2.5 rounded-xl border border-white/15 text-center sm:text-right shrink-0">
          <span className="text-[11px] text-indigo-200 block">مداخيل اليوم المسجلة في الصندوق</span>
          <span className="text-xl font-black text-emerald-400 font-mono tabular-nums">
            {stats.collectedToday.toFixed(2)} {settings.currency}
          </span>
        </div>
      </div>

      {/* 2. The 4 BIG Daily Operations (أهم العمليات اليومية التي يحتاجها أي شخص) */}
      <div>
        <h2 className="text-sm font-extrabold text-slate-800 mb-3 flex items-center gap-1.5">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>ماذا تريد أن تفعل الآن؟ (عمليات سريعة بنقرة واحدة)</span>
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Card 1: Add New Student */}
          <button
            type="button"
            onClick={onOpenNewStudentModal}
            className="p-5 bg-linear-to-br from-indigo-600 to-indigo-700 hover:from-indigo-700 hover:to-indigo-800 text-white rounded-2xl shadow-md hover:shadow-lg transition-all text-right flex flex-col justify-between cursor-pointer group hover:-translate-y-0.5 border border-indigo-500/30"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                <UserPlus className="w-6 h-6" />
              </div>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-md font-bold">تسجيل جديد</span>
            </div>
            <div>
              <h3 className="font-black text-base">تسجيل تلميذ جديد</h3>
              <p className="text-xs text-indigo-100 mt-1">إدخال بيانات التلميذ وتعيين فوجه الدراسي</p>
            </div>
          </button>

          {/* Card 2: Collect Payment */}
          <button
            type="button"
            onClick={() => onOpenPaymentModal()}
            className="p-5 bg-linear-to-br from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white rounded-2xl shadow-md hover:shadow-lg transition-all text-right flex flex-col justify-between cursor-pointer group hover:-translate-y-0.5 border border-emerald-500/30"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                <CreditCard className="w-6 h-6" />
              </div>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-md font-bold">وصل مالي</span>
            </div>
            <div>
              <h3 className="font-black text-base">استخلاص واجب شهري</h3>
              <p className="text-xs text-emerald-100 mt-1">تسجيل أداء التلميذ وطباعة الوصل فوراً</p>
            </div>
          </button>

          {/* Card 3: Debtors */}
          <button
            type="button"
            onClick={() => onNavigateSection('reports')}
            className="p-5 bg-linear-to-br from-amber-500 to-orange-600 hover:from-amber-600 hover:to-orange-700 text-white rounded-2xl shadow-md hover:shadow-lg transition-all text-right flex flex-col justify-between cursor-pointer group hover:-translate-y-0.5 border border-amber-400/30"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                <AlertCircle className="w-6 h-6" />
              </div>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-md font-bold">المتأخرات</span>
            </div>
            <div>
              <h3 className="font-black text-base">شكون مازال ما خلصش</h3>
              <p className="text-xs text-amber-100 mt-1">لائحة التلاميذ المدينين وأرقام هواتفهم للاتصال</p>
            </div>
          </button>

          {/* Card 4: Add Expense */}
          <button
            type="button"
            onClick={() => onNavigateSection('expenses')}
            className="p-5 bg-linear-to-br from-rose-600 to-pink-700 hover:from-rose-700 hover:to-pink-800 text-white rounded-2xl shadow-md hover:shadow-lg transition-all text-right flex flex-col justify-between cursor-pointer group hover:-translate-y-0.5 border border-rose-500/30"
          >
            <div className="flex items-center justify-between mb-3">
              <div className="w-12 h-12 rounded-xl bg-white/20 flex items-center justify-center text-white group-hover:scale-110 transition-transform">
                <TrendingDown className="w-6 h-6" />
              </div>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-md font-bold">المصاريف</span>
            </div>
            <div>
              <h3 className="font-black text-base">تسجيل مصاريف المركز</h3>
              <p className="text-xs text-rose-100 mt-1">توثيق فواتير الماء، الكهرباء، الكراء والمشتريات</p>
            </div>
          </button>
        </div>
      </div>

      {/* 3. Essential Numbers (أرقام المركز الأساسية فقط بدون تعقيد) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Students */}
        <div
          onClick={() => onNavigateSection('students')}
          className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-indigo-400 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-700">التلاميذ المسجلون</span>
            <div className="w-8 h-8 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <GraduationCap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-slate-900 font-mono tabular-nums">
            {activeStudents.length}
          </div>
          <span className="text-[11px] text-emerald-600 font-semibold mt-1 block">
            تلميذ يتابع دراسته حالياً ←
          </span>
        </div>

        {/* Card 2: Revenue this month */}
        <div
          onClick={() => onNavigateSection('finance')}
          className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-emerald-400 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-700">مداخيل هذا الشهر</span>
            <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <CreditCard className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-emerald-700 font-mono tabular-nums">
            {stats.collectedThisMonth.toFixed(0)} <span className="text-xs">{settings.currency}</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            {stats.paymentCountThisMonth} وصولات مستخلصة ←
          </span>
        </div>

        {/* Card 3: Expenses this month */}
        <div
          onClick={() => onNavigateSection('expenses')}
          className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-rose-400 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-700">المصاريف هذا الشهر</span>
            <div className="w-8 h-8 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-rose-600 font-mono tabular-nums">
            {stats.totalExpenses.toFixed(0)} <span className="text-xs">{settings.currency}</span>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            فواتير ومصاريف المركز ←
          </span>
        </div>

        {/* Card 4: Remaining Debts */}
        <div
          onClick={() => onNavigateSection('reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200 hover:border-amber-400 hover:shadow-sm transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-slate-500 mb-2">
            <span className="text-xs font-bold text-slate-700">الديون غير المستخلصة</span>
            <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-110 transition-transform">
              <AlertCircle className="w-4 h-4" />
            </div>
          </div>
          <div className="text-2xl font-black text-amber-600 font-mono tabular-nums">
            {stats.totalRemainingDue.toFixed(0)} <span className="text-xs">{settings.currency}</span>
          </div>
          <span className="text-[11px] text-amber-700 font-semibold mt-1 block">
            {debtorStudents.length} تلميذ لم يدفعوا بعد ←
          </span>
        </div>
      </div>

      {/* 4. Split Activity Section: Last Receipts (Right) & Debtors Call List (Left) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Right Card: Recent Payments */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <Receipt className="w-4 h-4 text-emerald-600" />
                <span>آخر الوصولات المستخلصة مؤخراً</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">سجل المبالغ التي دفعها أولياء الأمور</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigateSection('finance')}
            >
              عرض الكل
            </Button>
          </div>

          {recentPayments.length === 0 ? (
            <div className="text-center py-8 text-slate-400 text-xs">
              لا توجد وصولات مستخلصة بعد.
            </div>
          ) : (
            <div className="space-y-2.5">
              {recentPayments.map((p) => {
                const stu = students.find((s) => s.id === p.studentId);
                return (
                  <div
                    key={p.id}
                    className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-100 flex items-center justify-between gap-3 transition-colors"
                  >
                    <div className="space-y-0.5 overflow-hidden">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 truncate">
                          {stu?.fullName || 'تلميذ'}
                        </span>
                        <span className="text-[10px] font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200 text-slate-600 font-bold">
                          {p.receiptNumber}
                        </span>
                      </div>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {p.paymentDate} • {p.itemsCovered || 'واجب دراسي'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-mono font-bold text-emerald-700 text-sm tabular-nums">
                        +{p.amountPaid.toFixed(2)} {settings.currency}
                      </span>
                      <button
                        type="button"
                        onClick={() => onPrintPayment(p)}
                        className="p-1.5 rounded-lg bg-white border border-slate-200 hover:bg-indigo-50 hover:border-indigo-300 text-slate-600 hover:text-indigo-600 transition-colors cursor-pointer"
                        title="طباعة الوصل"
                      >
                        <Printer className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Left Card: Who hasn't paid yet? (تنبيه الديون المتبقية) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 space-y-4 shadow-2xs">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-500" />
                <span>تلاميذ لديهم مبالغ متأخرة (الديون)</span>
              </h3>
              <p className="text-[11px] text-slate-500 mt-0.5">للتواصل مع أوليائهم أو استخلاص الواجب</p>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onNavigateSection('reports')}
            >
              لائحة الديون الكاملة
            </Button>
          </div>

          {debtorStudents.length === 0 ? (
            <div className="text-center py-8 text-emerald-700 bg-emerald-50 rounded-xl border border-emerald-200 p-4 space-y-1">
              <span className="font-bold text-sm block">🎉 ممتاز! لا توجد أي ديون متأخرة</span>
              <p className="text-xs text-emerald-600">جميع التلاميذ قاموا بتسديد واجباتهم بالكامل.</p>
            </div>
          ) : (
            <div className="space-y-2.5">
              {debtorStudents.slice(0, 5).map((stu) => (
                <div
                  key={stu.id}
                  className="p-3 bg-slate-50 hover:bg-slate-100/80 rounded-xl border border-slate-100 flex items-center justify-between gap-3 transition-colors"
                >
                  <div className="space-y-0.5 overflow-hidden">
                    <span className="font-bold text-xs text-slate-900 block truncate">
                      {stu.fullName}
                    </span>
                    <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <a href={`tel:${stu.guardianPhone}`} className="hover:text-indigo-600 font-mono" dir="ltr">
                        {stu.guardianPhone || 'لا يوجد هاتف'}
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="font-mono font-bold text-rose-600 text-xs tabular-nums bg-rose-50 px-2 py-0.5 rounded border border-rose-200">
                      باقي: {stu.remainingBalance.toFixed(0)} {settings.currency}
                    </span>
                    <button
                      type="button"
                      onClick={() => onOpenPaymentModal(stu)}
                      className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold transition-colors cursor-pointer shadow-2xs"
                    >
                      استخلاص
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
