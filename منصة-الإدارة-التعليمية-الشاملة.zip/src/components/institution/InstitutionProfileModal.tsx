import React, { useState, useRef } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import {
  School,
  Upload,
  Image as ImageIcon,
  UserCheck,
  Building,
  Phone,
  Mail,
  MapPin,
  Globe,
  FileText,
  CheckCircle2,
  Sparkles,
  Printer,
  Trash2,
  Stamp,
  Award,
  Calendar,
  DollarSign,
  PenTool,
} from 'lucide-react';

interface InstitutionProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CenterSettings;
  onSettingsSaved: (updatedSettings: CenterSettings) => void;
}

// Preset educational logos (SVG Data URIs or sleek vectors) for instant selection
const PRESET_LOGOS = [
  {
    id: 'crest-gold',
    name: 'درع التميز الذهبي',
    bg: 'from-amber-500 to-amber-700',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none"><path d="M50 8L85 24V48C85 70 70 88 50 94C30 88 15 70 15 48V24L50 8Z" fill="#B45309" stroke="#FBBF24" stroke-width="4"/><path d="M30 45L50 30L70 45V68C70 72 65 78 50 82C35 78 30 72 30 68V45Z" fill="#F59E0B"/><polygon points="50,38 53,46 62,46 55,51 57,59 50,54 43,59 45,51 38,46 47,46" fill="#FFFBEB"/></svg>`,
  },
  {
    id: 'book-blue',
    name: 'شعار كتاب المعرفة الأكاديمي',
    bg: 'from-indigo-600 to-blue-800',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none"><circle cx="50" cy="50" r="45" fill="#1E3A8A" stroke="#60A5FA" stroke-width="4"/><path d="M50 32C42 26 30 26 24 28V68C30 66 42 66 50 72C58 66 70 66 76 68V28C70 26 58 26 50 32Z" fill="#DBEAFE" stroke="#1D4ED8" stroke-width="2"/><line x1="50" y1="32" x2="50" y2="72" stroke="#1D4ED8" stroke-width="3"/><path d="M50 20L45 28H55L50 20Z" fill="#FBBF24"/></svg>`,
  },
  {
    id: 'tree-green',
    name: 'شجرة النمو والتربية الحديثة',
    bg: 'from-emerald-600 to-teal-800',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none"><circle cx="50" cy="50" r="45" fill="#065F46" stroke="#34D399" stroke-width="4"/><path d="M50 78V52M50 52C42 45 35 48 30 42C25 36 26 26 36 25C40 25 45 28 50 34C55 28 60 25 64 25C74 26 75 36 70 42C65 48 58 45 50 52Z" fill="#A7F3D0" stroke="#047857" stroke-width="2"/><circle cx="50" cy="78" r="6" fill="#FDE68A"/></svg>`,
  },
  {
    id: 'quill-crimson',
    name: 'ريشة اللغات والإشعاع الفكري',
    bg: 'from-rose-600 to-red-800',
    svg: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="none"><rect width="90" height="90" x="5" y="5" rx="20" fill="#991B1B" stroke="#F87171" stroke-width="4"/><path d="M68 22C68 22 52 38 42 54C38 60 36 72 34 76C38 74 50 72 56 68C72 58 88 42 88 42L68 22Z" fill="#FEE2E2" stroke="#EF4444" stroke-width="2"/><line x1="34" y1="76" x2="25" y2="85" stroke="#FDE047" stroke-width="4" stroke-linecap="round"/></svg>`,
  },
];

export const InstitutionProfileModal: React.FC<InstitutionProfileModalProps> = ({
  isOpen,
  onClose,
  settings,
  onSettingsSaved,
}) => {
  // Form State
  const [centerName, setCenterName] = useState(settings.centerName || '');
  const [slogan, setSlogan] = useState(settings.slogan || '');
  const [directorName, setDirectorName] = useState(settings.directorName || '');
  const [directorTitle, setDirectorTitle] = useState(settings.directorTitle || 'المدير العام والمؤسس');
  const [logoUrl, setLogoUrl] = useState(settings.logoUrl || '');
  const [stampUrl, setStampUrl] = useState(settings.directorSignatureUrl || '');
  const [phone, setPhone] = useState(settings.phone || '');
  const [phoneSecondary, setPhoneSecondary] = useState(settings.phoneSecondary || '');
  const [email, setEmail] = useState(settings.email || '');
  const [website, setWebsite] = useState(settings.website || '');
  const [address, setAddress] = useState(settings.address || '');
  const [city, setCity] = useState(settings.city || 'الدار البيضاء');
  const [taxIdOrLicense, setTaxIdOrLicense] = useState(settings.taxIdOrLicense || '');
  const [academicYear, setAcademicYear] = useState(settings.academicYear || '2025/2026');
  const [currency, setCurrency] = useState(settings.currency || 'MAD');
  const [receiptPrefix, setReceiptPrefix] = useState(settings.receiptPrefix || 'REC');
  const [receiptTermsNotice, setReceiptTermsNotice] = useState(settings.receiptTermsNotice || '');

  const [activeTab, setActiveTab] = useState<'identity' | 'logo' | 'contact' | 'financial'>('identity');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const stampInputRef = useRef<HTMLInputElement>(null);

  // Handle Logo Upload from device
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
      alert('حجم الصورة كبير جداً، يرجى اختيار صورة أقل من 2 ميغابايت.');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setLogoUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  // Handle Stamp / Signature Upload
  const handleStampUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      if (event.target?.result) {
        setStampUrl(event.target.result as string);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleSelectPresetLogo = (svgMarkup: string) => {
    const dataUri = `data:image/svg+xml;utf8,${encodeURIComponent(svgMarkup)}`;
    setLogoUrl(dataUri);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      setIsSaving(true);
      const updated = await dataService.updateSettings({
        centerName,
        slogan,
        directorName,
        directorTitle,
        logoUrl,
        directorSignatureUrl: stampUrl,
        phone,
        phoneSecondary,
        email,
        website,
        address,
        city,
        taxIdOrLicense,
        academicYear,
        currency,
        receiptPrefix,
        receiptTermsNotice,
      });

      onSettingsSaved(updated);
      setSaveSuccess(true);
      setTimeout(() => {
        setSaveSuccess(false);
        onClose();
      }, 1200);
    } catch (err) {
      console.error('Failed to update institution settings:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="بروفيل وهوية المؤسسة التعليمية"
      subtitle="تعديل الشعار الرسمي، اسم المدير العام، وسائل الاتصال والبيانات الإدارية للمؤسسة"
      maxWidth="2xl"
    >
      <div className="space-y-5" dir="rtl">
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1.5 border-b border-slate-200 pb-2 text-xs font-bold overflow-x-auto no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveTab('identity')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'identity'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>هوية المركز والمدير العام</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('logo')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'logo'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            <span>شعار المؤسسة والختم الرسمي</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('contact')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'contact'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Phone className="w-3.5 h-3.5" />
            <span>العنوان وأرقام الاتصال</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('financial')}
            className={`px-3 py-2 rounded-xl flex items-center gap-1.5 transition-all cursor-pointer ${
              activeTab === 'financial'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>الضوابط الأكاديمية والوصولات</span>
          </button>
        </div>

        {/* Live Profile Header Banner Preview */}
        <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 rounded-2xl border border-slate-800 shadow-md flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3.5">
            {/* Logo Avatar */}
            <div className="relative group">
              <div className="w-16 h-16 rounded-2xl bg-white/10 backdrop-blur-md border-2 border-indigo-400/40 p-1 flex items-center justify-center overflow-hidden shrink-0 shadow-lg">
                {logoUrl ? (
                  <img
                    src={logoUrl}
                    alt="شعار المؤسسة"
                    className="w-full h-full object-contain rounded-xl"
                  />
                ) : (
                  <School className="w-8 h-8 text-indigo-300" />
                )}
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('logo')}
                className="absolute -bottom-1 -left-1 p-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-full shadow-md text-[10px] cursor-pointer"
                title="تعديل الشعار"
              >
                <PenTool className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-1 text-center sm:text-right">
              <div className="flex items-center gap-2 justify-center sm:justify-start">
                <h2 className="font-black text-sm sm:text-base tracking-tight text-white">
                  {centerName || 'اسم المؤسسة التعليمية'}
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 text-[10px] font-bold">
                  {academicYear}
                </span>
              </div>
              <p className="text-xs text-indigo-200/80 font-medium">
                {slogan || 'شعار المؤسسة اللفظي أو الرؤية البيداغوجية'}
              </p>
              <p className="text-[11px] text-slate-400 flex items-center justify-center sm:justify-start gap-1 font-mono">
                <UserCheck className="w-3 h-3 text-emerald-400" />
                <span>إشراف وإدارة: <strong className="text-slate-200">{directorName || 'اسم المدير العام'}</strong> ({directorTitle})</span>
              </p>
            </div>
          </div>

          <div className="text-left font-mono text-[11px] text-slate-300 bg-white/5 px-3 py-2 rounded-xl border border-white/10 shrink-0">
            <span className="block text-emerald-400 font-bold">معاينة الترويسة الرسمية</span>
            <span className="text-[10px] text-slate-400">{phone || '0522...'} • {city}</span>
          </div>
        </div>

        {/* Tab 1: Identity & General Director */}
        {activeTab === 'identity' && (
          <div className="space-y-4 text-xs animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  اسم المؤسسة التعليمية الرسمي *
                </label>
                <input
                  type="text"
                  value={centerName}
                  onChange={(e) => setCenterName(e.target.value)}
                  placeholder="مثال: مؤسسة النجاح والتفوق للدعم المدرسي واللغات"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-slate-900"
                  required
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  سيظهر هذا الاسم في أعلى جميع الكشوفات، الوصولات، وشهادات التسجيل الرسمية.
                </span>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  الشعار اللفظي أو الرؤية التربوية (Slogan)
                </label>
                <input
                  type="text"
                  value={slogan}
                  onChange={(e) => setSlogan(e.target.value)}
                  placeholder="مثال: ريادة في الدعم الأكاديمي، مرافقة فردية نحو التميز"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none text-slate-800"
                />
                <span className="text-[10px] text-slate-400 mt-1 block">
                  عبارة توجيهية تظهر تحت اسم المؤسسة في الوثائق المطبوعة.
                </span>
              </div>
            </div>

            <div className="p-4 bg-indigo-50/50 rounded-2xl border border-indigo-100 space-y-3">
              <div className="flex items-center gap-2">
                <UserCheck className="w-4 h-4 text-indigo-700" />
                <h3 className="font-extrabold text-sm text-indigo-950">بيانات المدير العام والمسؤول الإداري</h3>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    الاسم الكامل للمدير العام *
                  </label>
                  <input
                    type="text"
                    value={directorName}
                    onChange={(e) => setDirectorName(e.target.value)}
                    placeholder="مثال: ذ. عبد الرحيم بناني"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-bold text-slate-900"
                    required
                  />
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    الصفة والمنصب الإداري
                  </label>
                  <input
                    type="text"
                    value={directorTitle}
                    onChange={(e) => setDirectorTitle(e.target.value)}
                    placeholder="مثال: المدير العام والمشرف التربوي"
                    className="w-full p-2.5 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-slate-800"
                  />
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  الموسم الدراسي المعتمد
                </label>
                <input
                  type="text"
                  value={academicYear}
                  onChange={(e) => setAcademicYear(e.target.value)}
                  placeholder="2025/2026"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl font-mono focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  رقم الترخيص الوزاري / السجل التجاري والضريبي (ICE / RC)
                </label>
                <input
                  type="text"
                  value={taxIdOrLicense}
                  onChange={(e) => setTaxIdOrLicense(e.target.value)}
                  placeholder="RC: 458920 / IF: 28491029 / ICE: 002948192000034"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Logo & Official Stamp */}
        {activeTab === 'logo' && (
          <div className="space-y-4 text-xs animate-in fade-in duration-150">
            {/* Logo Selection & Upload Section */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                    <ImageIcon className="w-4 h-4 text-indigo-600" />
                    <span>تخصيص شعار المؤسسة الرسمي (Logo)</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    يمكنك رفع صورة شعار مؤسستك (PNG/JPG/SVG) أو الاختيار من النماذج الاحترافية الجاهزة.
                  </p>
                </div>

                {logoUrl && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-rose-600 hover:bg-rose-50"
                    icon={<Trash2 className="w-3.5 h-3.5" />}
                    onClick={() => setLogoUrl('')}
                  >
                    حذف الشعار
                  </Button>
                )}
              </div>

              {/* Upload Input & URL option */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-indigo-300 hover:border-indigo-500 bg-white hover:bg-indigo-50/40 p-4 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all group"
                >
                  <Upload className="w-7 h-7 text-indigo-500 group-hover:scale-110 transition-transform mb-2" />
                  <span className="font-bold text-slate-800 text-xs">اضغط لرفع الشعار من جهازك</span>
                  <span className="text-[10px] text-slate-400 mt-0.5">صيغ PNG, JPG, SVG, WebP (بحد أقصى 2MB)</span>
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleLogoUpload}
                    className="hidden"
                  />
                </div>

                <div className="space-y-2">
                  <label className="block font-bold text-slate-700">
                    أو أدخل رابط الشعار المباشر (URL):
                  </label>
                  <input
                    type="url"
                    value={logoUrl}
                    onChange={(e) => setLogoUrl(e.target.value)}
                    placeholder="https://example.com/logo.png"
                    className="w-full p-2 bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-xs"
                  />
                  <p className="text-[10px] text-slate-500">
                    يتم حفظ الشعار تلقائياً في التخزين الدائم ليعمل حتى دون اتصال بالإنترنت.
                  </p>
                </div>
              </div>

              {/* Preset Logos Picker */}
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <span className="font-bold text-slate-700 block text-xs">
                  أو اختر شعاراً تعليمياً احترافياً جاهزاً للمؤسسة:
                </span>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  {PRESET_LOGOS.map((preset) => (
                    <button
                      type="button"
                      key={preset.id}
                      onClick={() => handleSelectPresetLogo(preset.svg)}
                      className="p-2.5 bg-white border-2 border-slate-200 hover:border-indigo-500 hover:shadow-md rounded-xl flex flex-col items-center gap-2 transition-all cursor-pointer group text-center"
                    >
                      <div
                        className="w-12 h-12 flex items-center justify-center"
                        dangerouslySetInnerHTML={{ __html: preset.svg }}
                      />
                      <span className="text-[11px] font-bold text-slate-700 group-hover:text-indigo-600">
                        {preset.name}
                      </span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Official Stamp & Signature Section */}
            <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                    <Stamp className="w-4 h-4 text-emerald-600" />
                    <span>الختم وتوقيع الإدارة المعتمد (Cachet & Signature)</span>
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    صورة الختم الدائري للمؤسسة لتضمينها آلياً في شواهد التسجيل ووصولات الأداء وكشوفات النقط.
                  </p>
                </div>

                {stampUrl && (
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-rose-600 hover:bg-rose-50"
                    icon={<Trash2 className="w-3.5 h-3.5" />}
                    onClick={() => setStampUrl('')}
                  >
                    حذف الختم
                  </Button>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
                <div
                  onClick={() => stampInputRef.current?.click()}
                  className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-white hover:bg-emerald-50/40 p-3 rounded-2xl flex flex-col items-center justify-center text-center cursor-pointer transition-all group"
                >
                  <Stamp className="w-6 h-6 text-emerald-600 group-hover:scale-110 transition-transform mb-1" />
                  <span className="font-bold text-slate-800 text-xs">رفع صورة الختم / التوقيع</span>
                  <span className="text-[10px] text-slate-400">يفضل صورة شفافة PNG</span>
                  <input
                    ref={stampInputRef}
                    type="file"
                    accept="image/*"
                    onChange={handleStampUpload}
                    className="hidden"
                  />
                </div>

                {/* Stamp Preview */}
                <div className="flex items-center justify-center p-3 bg-white border border-slate-200 rounded-2xl min-h-[90px]">
                  {stampUrl ? (
                    <img
                      src={stampUrl}
                      alt="ختم المؤسسة"
                      className="max-h-20 object-contain"
                    />
                  ) : (
                    <div className="text-center text-slate-400 space-y-1">
                      <div className="w-14 h-14 rounded-full border-2 border-dashed border-slate-300 mx-auto flex items-center justify-center text-[10px] text-slate-400 font-bold">
                        ختم الإدارة
                      </div>
                      <span className="text-[10px] block">لا يوجد ختم مخصص حالياً</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tab 3: Official Coordinates & Contact */}
        {activeTab === 'contact' && (
          <div className="space-y-4 text-xs animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-indigo-600" />
                  <span>رقم الهاتف الأساسي للمؤسسة *</span>
                </label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="0522 34 56 78"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <span className="text-emerald-600 font-bold">💬</span>
                  <span>رقم هاتف الواتساب والإدارة الميدانية</span>
                </label>
                <input
                  type="text"
                  value={phoneSecondary}
                  onChange={(e) => setPhoneSecondary(e.target.value)}
                  placeholder="0661 12 34 56"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Mail className="w-3.5 h-3.5 text-indigo-600" />
                  <span>البريد الإلكتروني الرسمي</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="contact@institution-edu.ma"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Globe className="w-3.5 h-3.5 text-indigo-600" />
                  <span>الموقع الإلكتروني أو صفحة التواصل الاجتماعي</span>
                </label>
                <input
                  type="text"
                  value={website}
                  onChange={(e) => setWebsite(e.target.value)}
                  placeholder="https://facebook.com/my-institution"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div className="sm:col-span-2">
                <label className="block font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-indigo-600" />
                  <span>العنوان الكامل للمقر *</span>
                </label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="شارع الحسن الثاني، عمارة الأمل، الطابق الثاني"
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">المدينة *</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="الدار البيضاء، الرباط، مراكش..."
                  className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none font-bold"
                  required
                />
              </div>
            </div>
          </div>
        )}

        {/* Tab 4: Financial & Academic Rules */}
        {activeTab === 'financial' && (
          <div className="space-y-4 text-xs animate-in fade-in duration-150">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  العملة المالية المعتمدة
                </label>
                <input
                  type="text"
                  value={currency}
                  onChange={(e) => setCurrency(e.target.value)}
                  placeholder="MAD أو درهم"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl font-bold font-mono focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1">
                  بادئة ترقيم الوصولات (Receipt Prefix)
                </label>
                <input
                  type="text"
                  value={receiptPrefix}
                  onChange={(e) => setReceiptPrefix(e.target.value)}
                  placeholder="REC"
                  className="w-full p-2 bg-slate-50 border border-slate-300 rounded-xl font-bold font-mono focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block font-bold text-slate-700 mb-1">
                نص الشروط القانونية والملاحظات في أسفل الوصولات المالية
              </label>
              <textarea
                rows={3}
                value={receiptTermsNotice}
                onChange={(e) => setReceiptTermsNotice(e.target.value)}
                placeholder="مثال: الواجبات الشهرية تؤدى بداية كل شهر. الأداء لا يمكن استرجاعه بعد انطلاق الحصص..."
                className="w-full p-2.5 bg-slate-50 border border-slate-300 rounded-xl focus:bg-white focus:ring-2 focus:ring-indigo-500 outline-none text-xs leading-relaxed"
              />
            </div>
          </div>
        )}

        {/* Success Alert */}
        {saveSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>تم حفظ وتحديث بروفيل المؤسسة وشعارها بنجاح في كامل المنظومة!</span>
          </div>
        )}

        {/* Modal Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-200">
          <Button variant="outline" size="sm" onClick={onClose}>
            إلغاء
          </Button>

          <Button
            variant="primary"
            size="md"
            icon={<CheckCircle2 className="w-4 h-4" />}
            onClick={handleSave}
            isLoading={isSaving}
          >
            حفظ واعتماد بروفيل المؤسسة 💾
          </Button>
        </div>
      </div>
    </Modal>
  );
};
