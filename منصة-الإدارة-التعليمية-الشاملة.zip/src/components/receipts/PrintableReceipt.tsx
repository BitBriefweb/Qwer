import React from 'react';
import { Payment, CenterSettings, Student } from '../../types';
import { dataService } from '../../services/data-service';
import { Button } from '../common/Button';
import { Printer, Download, X, MessageCircle } from 'lucide-react';

interface PrintableReceiptProps {
  payment: Payment & { studentName?: string; studentCode?: string; levelName?: string };
  student?: Student;
  settings: CenterSettings;
  onClose?: () => void;
  format?: 'A4' | 'thermal_80mm';
}

export const PrintableReceipt: React.FC<PrintableReceiptProps> = ({
  payment,
  student,
  settings,
  onClose,
  format: initialFormat,
}) => {
  const [format, setFormat] = React.useState<'A4' | 'thermal_80mm'>(
    initialFormat || settings.printFormatDefault || 'A4'
  );

  const handlePrint = () => {
    window.print();
  };

  const studentName = payment.studentName || student?.fullName || 'غير محدد';
  const studentCode = payment.studentCode || student?.code || '---';

  const paymentMethodLabel = {
    cash: 'نقداً (Espèces)',
    transfer: 'تحويل بنكي (Virement)',
    cheque: 'شيك بنكي (Chèque)',
    card: 'بطاقة بنكية (Carte)',
    other: 'أخرى',
  }[payment.paymentMethod];

  return (
    <div className="space-y-4">
      {/* Print Controls (Hidden when printing) */}
      <div className="no-print flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-slate-700">تنسيق الطباعة:</span>
          <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
            <button
              type="button"
              onClick={() => setFormat('A4')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                format === 'A4'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              ورقة رسمية (A4)
            </button>
            <button
              type="button"
              onClick={() => setFormat('thermal_80mm')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                format === 'thermal_80mm'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              طابعة حرارية (80mm)
            </button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {student && (
            <a
              href={dataService.getWhatsAppReceiptUrl(student, payment, settings.centerName, settings.currency)}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
              title="إرسال تفاصيل الوصل المالي لولي الأمر عبر واتساب"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>إرسال عبر واتساب</span>
            </a>
          )}
          <Button variant="primary" size="sm" icon={<Printer className="w-4 h-4" />} onClick={handlePrint}>
            طباعة الوصل الآن
          </Button>
          {onClose && (
            <Button variant="ghost" size="sm" onClick={onClose}>
              إغلاق
            </Button>
          )}
        </div>
      </div>

      {/* Actual Printable Container */}
      <div id="printable-receipt-container" className="flex justify-center p-2">
        {format === 'A4' ? (
          /* ========================================================
             STANDARD A4 RECEIPT FORMAT (2 identical copies: Center & Student)
             ======================================================== */
          <div className="w-full max-w-2xl bg-white border border-slate-300 rounded-xl p-8 shadow-sm space-y-8 text-slate-800">
            {/* Header */}
            <div className="flex items-start justify-between border-b-2 border-slate-900 pb-5">
              <div className="flex items-center gap-4">
                {settings.logoUrl && (
                  <div className="w-16 h-16 rounded-xl border border-slate-300 p-1 flex items-center justify-center shrink-0 bg-white shadow-2xs">
                    <img
                      src={settings.logoUrl}
                      alt="شعار المؤسسة"
                      className="w-full h-full object-contain"
                    />
                  </div>
                )}
                <div>
                  <h1 className="text-xl font-bold text-slate-900">{settings.centerName}</h1>
                  <p className="text-xs text-slate-600 mt-1 max-w-md">{settings.slogan}</p>
                  <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-500 mt-2">
                    <span>الهاتف: {settings.phone}</span>
                    {settings.phoneSecondary && <span>· المحمول: {settings.phoneSecondary}</span>}
                    <span>· العنوان: {settings.address}</span>
                  </div>
                </div>
              </div>

              <div className="text-left">
                <div className="inline-block bg-slate-100 border border-slate-300 rounded-lg px-4 py-2 text-center">
                  <span className="block text-[11px] font-bold text-slate-500">وصل أداء مالي</span>
                  <span className="text-base font-black text-slate-900 font-mono tracking-wider">
                    {payment.receiptNumber}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 mt-1.5 font-mono text-center">
                  التاريخ: {payment.paymentDate}
                </div>
              </div>
            </div>

            {/* Student & Payment Info Grid */}
            <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-lg border border-slate-200 text-sm">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-24">اسم التلميذ:</span>
                  <span className="font-bold text-slate-900 text-base">{studentName}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-24">رقم التسجيل:</span>
                  <span className="font-mono font-semibold text-slate-800">{studentCode}</span>
                </div>
                {payment.levelName && (
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 w-24">المستوى الدراسي:</span>
                    <span className="text-slate-800">{payment.levelName}</span>
                  </div>
                )}
              </div>

              <div className="space-y-1.5 border-r border-slate-200 pr-4">
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-24">طريقة الأداء:</span>
                  <span className="font-medium text-slate-900">{paymentMethodLabel}</span>
                </div>
                {payment.referenceNumber && (
                  <div className="flex items-center gap-2">
                    <span className="text-slate-500 w-24">مرجع العملية:</span>
                    <span className="font-mono text-slate-800">{payment.referenceNumber}</span>
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <span className="text-slate-500 w-24">المسؤول عن القبض:</span>
                  <span className="text-slate-800">{payment.recordedBy}</span>
                </div>
              </div>
            </div>

            {/* Covered Description Table */}
            <div className="border border-slate-300 rounded-lg overflow-hidden">
              <table className="w-full text-right text-sm">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-300">
                  <tr>
                    <th className="py-2.5 px-4">بيان الرسوم والاستحقاقات</th>
                    <th className="py-2.5 px-4 w-32 text-left">المبلغ بالدرهم</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  <tr>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {payment.itemsCovered}
                      {payment.notes && (
                        <p className="text-xs text-slate-500 mt-1">ملاحظة: {payment.notes}</p>
                      )}
                    </td>
                    <td className="py-3 px-4 text-left font-mono font-bold text-slate-900 tabular-nums">
                      {payment.amountPaid.toFixed(2)} {settings.currency}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Financial Summary Box */}
            <div className="flex justify-end">
              <div className="w-72 bg-slate-50 rounded-lg border border-slate-300 p-3.5 space-y-2 text-sm">
                <div className="flex justify-between items-center text-slate-600">
                  <span>المبلغ السابق المستحق:</span>
                  <span className="font-mono tabular-nums">{payment.previousBalance.toFixed(2)} {settings.currency}</span>
                </div>
                <div className="flex justify-between items-center text-base font-bold text-slate-900 border-t border-slate-200 pt-1.5">
                  <span>المبلغ المؤدى فعلياً:</span>
                  <span className="font-mono text-indigo-700 tabular-nums">{payment.amountPaid.toFixed(2)} {settings.currency}</span>
                </div>
                <div className="flex justify-between items-center text-xs font-semibold text-slate-700 border-t border-slate-200 pt-1.5">
                  <span>المبلغ المتبقي في الذمة:</span>
                  <span className={`font-mono tabular-nums ${payment.remainingBalanceAfter > 0 ? 'text-rose-600 font-bold' : 'text-emerald-700'}`}>
                    {payment.remainingBalanceAfter.toFixed(2)} {settings.currency}
                  </span>
                </div>
              </div>
            </div>

            {/* Footer Notice & Signatures */}
            <div className="border-t border-slate-200 pt-4 flex items-end justify-between">
              <div className="max-w-md">
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {settings.receiptTermsNotice}
                </p>
                {settings.taxIdOrLicense && (
                  <p className="text-[10px] text-slate-400 mt-1 font-mono">
                    {settings.taxIdOrLicense}
                  </p>
                )}
              </div>

              <div className="flex gap-8 text-center text-xs">
                <div className="w-28 pb-10 border-b border-dashed border-slate-400">
                  <span className="text-slate-600">توقيع ولي الأمر</span>
                </div>
                <div className="w-32 min-h-[55px] relative flex flex-col items-center justify-end pb-1 border-b border-dashed border-slate-400">
                  {settings.directorSignatureUrl ? (
                    <img
                      src={settings.directorSignatureUrl}
                      alt="ختم المؤسسة"
                      className="absolute -top-7 max-h-16 object-contain pointer-events-none opacity-85"
                    />
                  ) : null}
                  <span className="text-slate-600 block text-[11px] z-10">خاتم وتوقيع الإدارة</span>
                  {settings.directorName && (
                    <span className="text-[10px] text-slate-500 font-bold block mt-0.5">{settings.directorName}</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* ========================================================
             THERMAL 80MM RECEIPT FORMAT (Point of Sale printer)
             ======================================================== */
          <div className="w-72 bg-white p-4 border border-slate-300 text-slate-900 font-mono text-xs space-y-3">
            <div className="text-center pb-2 border-b border-dashed border-slate-400">
              <div className="font-bold text-sm">{settings.centerName}</div>
              <div className="text-[10px] text-slate-600">{settings.phone}</div>
              <div className="text-[10px] text-slate-600">{settings.address}</div>
            </div>

            <div className="text-center font-bold text-xs py-1 border-b border-dashed border-slate-400">
              وصل أداء: {payment.receiptNumber}
              <div className="text-[10px] font-normal text-slate-600">{payment.paymentDate}</div>
            </div>

            <div className="space-y-1 text-[11px]">
              <div>التلميذ: {studentName}</div>
              <div>الرمز: {studentCode}</div>
              <div>طريقة الأداء: {paymentMethodLabel}</div>
              <div>المستلم: {payment.recordedBy}</div>
            </div>

            <div className="border-t border-b border-dashed border-slate-400 py-2 space-y-1">
              <div className="text-[10px] font-bold">البيان:</div>
              <div className="text-[11px] leading-tight">{payment.itemsCovered}</div>
            </div>

            <div className="space-y-1 pt-1 font-bold">
              <div className="flex justify-between text-xs">
                <span>المؤدى:</span>
                <span className="tabular-nums">{payment.amountPaid.toFixed(2)} {settings.currency}</span>
              </div>
              <div className="flex justify-between text-[11px] text-slate-700">
                <span>المتبقي:</span>
                <span className="tabular-nums">{payment.remainingBalanceAfter.toFixed(2)} {settings.currency}</span>
              </div>
            </div>

            <div className="text-center pt-3 border-t border-dashed border-slate-400 text-[9px] text-slate-500 leading-tight">
              شكراً لثقتكم بمؤسستنا
              <br />
              يرجى الاحتفاظ بهذا الوصل
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
