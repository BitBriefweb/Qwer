import React, { useRef } from 'react';
import { StudentWithDetails, CenterSettings } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Printer, School, User, Phone, Calendar, ShieldCheck, Sparkles } from 'lucide-react';

interface StudentCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentWithDetails | null;
  settings: CenterSettings;
}

export const StudentCardModal: React.FC<StudentCardModalProps> = ({
  isOpen,
  onClose,
  student,
  settings,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);

  if (!student) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="بطاقة التلميذ المدرسية الرسمية"
      subtitle={`معاينة وطباعة البطاقة التعريفية الخاصة بالتلميذ: ${student.fullName}`}
      maxWidth="lg"
    >
      <div className="space-y-6">
        {/* Printable Card Container */}
        <div className="flex justify-center p-4 bg-slate-100 rounded-2xl border border-slate-200">
          <div
            ref={cardRef}
            id="printable-student-card"
            className="w-[360px] sm:w-[400px] bg-linear-to-br from-slate-900 via-slate-800 to-indigo-950 text-white rounded-2xl shadow-xl overflow-hidden border border-indigo-500/30 relative select-none print:shadow-none print:border-slate-800"
          >
            {/* Geometric Top Accent */}
            <div className="absolute top-0 right-0 left-0 h-1.5 bg-linear-to-r from-amber-400 via-indigo-500 to-emerald-400"></div>

            {/* Card Header */}
            <div className="p-4 border-b border-white/10 flex items-center justify-between gap-3 bg-white/5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center text-white shrink-0 border border-white/20 overflow-hidden p-0.5">
                  {settings.logoUrl ? (
                    <img
                      src={settings.logoUrl}
                      alt="شعار المؤسسة"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <School className="w-4 h-4 text-white" />
                  )}
                </div>
                <div>
                  <h4 className="font-bold text-xs text-white leading-tight">
                    {settings.centerName || 'مؤسسة الدعم والتميز'}
                  </h4>
                  <p className="text-[10px] text-slate-300">بطاقة التلميذ المدرسية</p>
                </div>
              </div>
              <div className="text-left font-mono text-[10px] text-amber-300 font-bold bg-amber-400/10 px-2 py-0.5 rounded border border-amber-400/20">
                {settings.academicYear || '2025/2026'}
              </div>
            </div>

            {/* Card Body */}
            <div className="p-4 space-y-4">
              <div className="flex items-start gap-4">
                {/* Photo / Avatar Box */}
                <div className="w-20 h-24 rounded-xl bg-slate-800 border-2 border-indigo-400/40 flex flex-col items-center justify-center text-slate-300 shrink-0 shadow-inner relative overflow-hidden">
                  <div className="w-12 h-12 rounded-full bg-indigo-900/80 flex items-center justify-center text-indigo-200 font-bold text-xl mb-1">
                    {student.fullName.charAt(0)}
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono tracking-tighter">
                    {student.code}
                  </span>
                </div>

                {/* Details */}
                <div className="flex-1 space-y-1.5 text-xs">
                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">الاسم الكامل:</span>
                    <span className="font-bold text-sm text-white block">
                      {student.fullName}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-400 block font-medium">المستوى الدراسي:</span>
                    <span className="font-semibold text-xs text-indigo-200 block">
                      {student.levelId === 'lvl-1'
                        ? 'الثانية باكالوريا - علوم رياضية'
                        : student.levelId === 'lvl-2'
                        ? 'الأولى باكالوريا - علوم تجريبية'
                        : student.levelId === 'lvl-3'
                        ? 'الثالثة إعدادي'
                        : 'التعليم التأهيلي'}
                    </span>
                  </div>

                  <div className="flex items-center gap-1 text-[11px] text-slate-300 pt-0.5">
                    <Phone className="w-3 h-3 text-emerald-400" />
                    <span className="font-mono text-[10px]">{student.guardianPhone}</span>
                  </div>
                </div>
              </div>

              {/* Enrolled Groups */}
              {student.enrolledGroups.length > 0 && (
                <div className="bg-white/5 p-2 rounded-lg border border-white/5 text-[10px] text-slate-300 space-y-1">
                  <span className="text-slate-400 block font-medium">الأفواج المسجلة:</span>
                  <div className="flex flex-wrap gap-1">
                    {student.enrolledGroups.map((g) => (
                      <span key={g.id} className="bg-indigo-600/30 text-indigo-200 px-1.5 py-0.5 rounded border border-indigo-400/20">
                        {g.name}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Card Footer: Barcode + Security Seal */}
              <div className="pt-2 border-t border-white/10 flex items-center justify-between">
                <div>
                  {/* Simulated Code 128 barcode pattern */}
                  <div className="font-mono tracking-[4px] text-[16px] text-slate-300 font-bold leading-none select-none">
                    ||| | || |||| | ||| ||
                  </div>
                  <span className="text-[9px] font-mono text-slate-400 block mt-0.5">
                    ID: {student.code}
                  </span>
                </div>

                <div className="text-left text-[9px] text-slate-400 flex flex-col items-end">
                  <div className="flex items-center gap-1 text-emerald-400 font-semibold">
                    <ShieldCheck className="w-3 h-3" />
                    <span>معتمد رسمياً</span>
                  </div>
                  <span>توقيع وخاتم الإدارة</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100">
          <p className="text-xs text-slate-500">
            يمكنك طباعة البطاقة وتغليفها حرارياً للتلميذ لاستخدامها عند الحضور والمكتبة.
          </p>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={onClose}>
              إغلاق
            </Button>
            <Button variant="primary" size="sm" icon={<Printer className="w-4 h-4" />} onClick={handlePrint}>
              طباعة البطاقة المدرسية
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
};
