import React, { useState, useEffect } from 'react';
import { Student, Level, StudyGroup } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Student, 'id' | 'code'> & { initialGroupIds?: string[] }) => Promise<void>;
  studentToEdit?: Student | null;
  levels: Level[];
  groups: StudyGroup[];
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  studentToEdit,
  levels,
  groups,
}) => {
  const [fullName, setFullName] = useState('');
  const [studentPhone, setStudentPhone] = useState('');
  const [birthDate, setBirthDate] = useState('');
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [guardianName, setGuardianName] = useState('');
  const [guardianPhone, setGuardianPhone] = useState('');
  const [guardianRelation, setGuardianRelation] = useState<Student['guardianRelation']>('أب');
  const [address, setAddress] = useState('');
  const [levelId, setLevelId] = useState('');
  const [status, setStatus] = useState<Student['status']>('active');
  const [notes, setNotes] = useState('');
  const [selectedGroupIds, setSelectedGroupIds] = useState<string[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (studentToEdit) {
      setFullName(studentToEdit.fullName);
      setStudentPhone('');
      setBirthDate(studentToEdit.birthDate || '');
      setGender(studentToEdit.gender);
      setGuardianName(studentToEdit.guardianName);
      setGuardianPhone(studentToEdit.guardianPhone);
      setGuardianRelation(studentToEdit.guardianRelation);
      setAddress(studentToEdit.address || '');
      setLevelId(studentToEdit.levelId);
      setStatus(studentToEdit.status);
      setNotes(studentToEdit.notes || '');
      setSelectedGroupIds([]);
    } else {
      setFullName('');
      setStudentPhone('');
      setBirthDate('');
      setGender('male');
      setGuardianName('');
      setGuardianPhone('');
      setGuardianRelation('أب');
      setAddress('');
      setLevelId(levels[0]?.id || '');
      setStatus('active');
      setNotes('');
      setSelectedGroupIds([]);
    }
    setError(null);
  }, [studentToEdit, isOpen, levels]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fullName.trim()) {
      setError('يرجى إدخال الاسم الكامل للتلميذ');
      return;
    }

    const contactPhone = guardianPhone.trim() || studentPhone.trim();
    if (!contactPhone) {
      setError('يرجى إدخال رقم هاتف للتواصل (هاتف التلميذ أو هاتف الولي)');
      return;
    }

    if (!levelId) {
      setError('يرجى اختيار المستوى الدراسي');
      return;
    }

    const finalGuardianName = guardianName.trim() || fullName.trim();
    const finalGuardianPhone = contactPhone;

    try {
      setIsSubmitting(true);
      await onSubmit({
        fullName: fullName.trim(),
        birthDate: birthDate || undefined,
        gender,
        guardianName: finalGuardianName,
        guardianPhone: finalGuardianPhone,
        guardianRelation: guardianName.trim() ? guardianRelation : 'آخر',
        address: address.trim() || undefined,
        levelId,
        status,
        registrationDate: studentToEdit?.registrationDate || new Date().toISOString().substring(0, 10),
        notes: notes.trim() || undefined,
        initialGroupIds: selectedGroupIds,
      });
      onClose();
    } catch (err) {
      setError((err as Error).message || 'حدث خطأ أثناء حفظ بيانات التلميذ');
    } finally {
      setIsSubmitting(false);
    }
  };

  const availableGroupsForLevel = groups.filter((g) => !levelId || g.levelId === levelId);

  const toggleGroupSelection = (grpId: string) => {
    setSelectedGroupIds((prev) =>
      prev.includes(grpId) ? prev.filter((id) => id !== grpId) : [...prev, grpId]
    );
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={studentToEdit ? 'تعديل بيانات التلميذ' : 'تسجيل تلميذ جديد في المؤسسة'}
      subtitle={studentToEdit ? `رقم التسجيل: ${studentToEdit.code}` : 'أدخل البيانات الأساسية والمعلومات الدراسية'}
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {error}
          </div>
        )}

        {/* Section 1: بيانات التلميذ الشخصية */}
        <div>
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 pb-1 border-b border-slate-100">
            البيانات الشخصية للتلميذ
          </h4>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                الاسم الكامل للتلميذ <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="مثال: أيوب العمراني"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">الجنس</label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value as 'male' | 'female')}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                <option value="male">ذكر</option>
                <option value="female">أنثى</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">تاريخ الازدياد</label>
              <input
                type="date"
                value={birthDate}
                onChange={(e) => setBirthDate(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                المستوى الدراسي <span className="text-rose-500">*</span>
              </label>
              <select
                value={levelId}
                onChange={(e) => setLevelId(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                required
              >
                <option value="">اختر المستوى الدراسي...</option>
                {levels.map((lvl) => (
                  <option key={lvl.id} value={lvl.id}>
                    {lvl.name} ({lvl.code})
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Section 2: بيانات التواصل وولي الأمر */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2.5 pb-1 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              بيانات التواصل وولي الأمر
            </h4>
            <span className="text-[11px] text-emerald-600 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              ولي الأمر اختياري للطلبة الكبار والراشدين
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                هاتف التلميذ الشخصي (إن وجد)
              </label>
              <input
                type="tel"
                value={studentPhone}
                onChange={(e) => setStudentPhone(e.target.value)}
                placeholder="06XXXXXXXX"
                dir="ltr"
                className="w-full px-3 py-2 text-sm text-right bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                اسم ولي الأمر <span className="text-slate-400 font-normal">(اختياري للراشدين)</span>
              </label>
              <input
                type="text"
                value={guardianName}
                onChange={(e) => setGuardianName(e.target.value)}
                placeholder="مثال: عبد القادر العمراني"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                هاتف ولي الأمر (واتساب / اتصال)
              </label>
              <input
                type="tel"
                value={guardianPhone}
                onChange={(e) => setGuardianPhone(e.target.value)}
                placeholder="06XXXXXXXX"
                dir="ltr"
                className="w-full px-3 py-2 text-sm text-right bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">صلة القرابة</label>
              <select
                value={guardianRelation}
                onChange={(e) => setGuardianRelation(e.target.value as Student['guardianRelation'])}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                <option value="أب">أب</option>
                <option value="أم">أم</option>
                <option value="ولي أمر">ولي أمر / كفيل</option>
                <option value="آخر">نفسه (تلميذ راشد / مستقل)</option>
              </select>
            </div>

            <div className="md:col-span-3">
              <label className="block text-xs font-semibold text-slate-700 mb-1">العنوان السكني</label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="الحي، رقم المنزل، المدينة"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>
          </div>
        </div>

        {/* Section 3: المجموعات الدراسية الأولية (Only upon new creation) */}
        {!studentToEdit && availableGroupsForLevel.length > 0 && (
          <div className="pt-2">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2 pb-1 border-b border-slate-100 flex items-center justify-between">
              <span>التسجيل في المجموعات المتاحة لهذا المستوى</span>
              <span className="text-[11px] font-normal text-slate-500">اختياري (يمكن إسنادها لاحقاً)</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-36 overflow-y-auto p-1">
              {availableGroupsForLevel.map((grp) => {
                const isSelected = selectedGroupIds.includes(grp.id);
                return (
                  <label
                    key={grp.id}
                    className={`flex items-start gap-2.5 p-2 rounded-lg border cursor-pointer text-xs transition-colors ${
                      isSelected
                        ? 'bg-indigo-50/80 border-indigo-300 text-indigo-950 font-medium'
                        : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                    }`}
                  >
                    <input
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => toggleGroupSelection(grp.id)}
                      className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500"
                    />
                    <div>
                      <div className="font-semibold text-slate-900">{grp.name}</div>
                      <div className="text-[11px] text-slate-500">
                        {grp.teacherName} · {grp.monthlyFee} درهم/شهر
                      </div>
                    </div>
                  </label>
                );
              })}
            </div>
          </div>
        )}

        {/* Section 4: الملاحظات وحالة التلميذ */}
        <div className="pt-2 grid grid-cols-1 md:grid-cols-3 gap-3">
          {studentToEdit && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">حالة التلميذ</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as Student['status'])}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                <option value="active">نشط (مستمر في الدراسة)</option>
                <option value="suspended">موقوف مؤقتاً</option>
                <option value="inactive">غير نشط (منقطع)</option>
              </select>
            </div>
          )}

          <div className={studentToEdit ? 'md:col-span-2' : 'md:col-span-3'}>
            <label className="block text-xs font-semibold text-slate-700 mb-1">ملاحظات إدارية أو بيداغوجية</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: خصم إخوة، توصيات الأستاذ، ظروف خاصة..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            />
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
            {studentToEdit ? 'حفظ التعديلات' : 'تأكيد تسجيل التلميذ'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
