import React, { useState } from 'react';
import { StudentWithDetails, StudyGroup } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';

interface StudentTransferModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentWithDetails | null;
  groups: StudyGroup[];
  onTransfer: (studentId: string, fromGroupId: string, toGroupId: string, reason: string) => Promise<void>;
}

export const StudentTransferModal: React.FC<StudentTransferModalProps> = ({
  isOpen,
  onClose,
  student,
  groups,
  onTransfer,
}) => {
  const [fromGroupId, setFromGroupId] = useState('');
  const [toGroupId, setToGroupId] = useState('');
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    if (student && student.enrolledGroups.length > 0) {
      setFromGroupId(student.enrolledGroups[0].id);
    } else {
      setFromGroupId('');
    }
    setToGroupId('');
    setReason('');
    setError(null);
  }, [student, isOpen]);

  if (!student) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!fromGroupId) {
      setError('يرجى تحديد المجموعة الحالية المراد التحويل منها');
      return;
    }
    if (!toGroupId) {
      setError('يرجى تحديد المجموعة المستهدفة للتحويل إليها');
      return;
    }
    if (fromGroupId === toGroupId) {
      setError('المجموعة الحالية والمستهدفة متطابقتان');
      return;
    }

    try {
      setIsSubmitting(true);
      await onTransfer(student.id, fromGroupId, toGroupId, reason);
      onClose();
    } catch (err) {
      setError((err as Error).message || 'حدث خطأ أثناء إجراء عملية التحويل');
    } finally {
      setIsSubmitting(false);
    }
  };

  const eligibleTargetGroups = groups.filter((g) => g.id !== fromGroupId);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="تحويل التلميذ بين المجموعات الدراسية"
      subtitle={`التلميذ: ${student.fullName} (المستوى: ${student.levelId})`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {error}
          </div>
        )}

        <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 leading-relaxed">
          <strong>تنبيه إداري:</strong> عملية التحويل تحافظ بالكامل على السجل المالي وسجل الأداءات
          والوصولات السابقة، وتسجل سبباً إدارياً موثقاً للتحويل دون حذف أي بيانات سابقة.
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            المجموعة الحالية (المراد الانتقال منها)
          </label>
          <select
            value={fromGroupId}
            onChange={(e) => setFromGroupId(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            required
          >
            <option value="">اختر المجموعة...</option>
            {student.enrolledGroups.map((g: { id: string; name: string; teacherName: string }) => (
              <option key={g.id} value={g.id}>
                {g.name} (مع {g.teacherName})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            المجموعة الجديدة المستهدفة
          </label>
          <select
            value={toGroupId}
            onChange={(e) => setToGroupId(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            required
          >
            <option value="">اختر المجموعة البديلة...</option>
            {eligibleTargetGroups.map((g) => (
              <option key={g.id} value={g.id}>
                {g.name} (مع {g.teacherName}) · {g.monthlyFee} درهم
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">سبب التحويل</label>
          <input
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="مثال: تعارض جدول الحصص المدرسية، رغبة ولي الأمر..."
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            required
          />
        </div>

        <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
            تأكيد التحويل
          </Button>
        </div>
      </form>
    </Modal>
  );
};
