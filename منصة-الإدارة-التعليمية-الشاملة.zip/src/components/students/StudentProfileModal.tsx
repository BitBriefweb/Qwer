import React, { useState, useEffect } from 'react';
import { StudentWithDetails, FeeCharge, Payment, AttendanceRecord, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import {
  Phone,
  User as UserIcon,
  Calendar,
  CreditCard,
  BookOpen,
  CheckCircle,
  Clock,
  Printer,
  FileText,
  ArrowLeftRight,
  PlusCircle,
} from 'lucide-react';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentWithDetails | null;
  settings: CenterSettings;
  onOpenPaymentModal: (student: StudentWithDetails) => void;
  onOpenEditModal: (student: StudentWithDetails) => void;
  onOpenTransferModal: (student: StudentWithDetails) => void;
  onPrintPayment: (payment: Payment) => void;
  onPrintStudentCard?: (student: StudentWithDetails) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  isOpen,
  onClose,
  student,
  settings,
  onOpenPaymentModal,
  onOpenEditModal,
  onOpenTransferModal,
  onPrintPayment,
  onPrintStudentCard,
}) => {
  const [charges, setCharges] = useState<FeeCharge[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [activeTab, setActiveTab] = useState<'financial' | 'groups' | 'attendance'>('financial');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (student && isOpen) {
      loadDetails();
    }
  }, [student, isOpen]);

  const loadDetails = async () => {
    if (!student) return;
    setIsLoading(true);
    try {
      const [cList, pList] = await Promise.all([
        dataService.getCharges(student.id),
        dataService.getPayments({ studentId: student.id }),
      ]);
      setCharges(cList);
      setPayments(pList);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  if (!student) return null;

  const statusBadge: Record<'active' | 'suspended' | 'inactive', React.ReactNode> = {
    active: <Badge variant="success" dot>نشط</Badge>,
    suspended: <Badge variant="warning" dot>موقوف مؤقتاً</Badge>,
    inactive: <Badge variant="danger" dot>غير نشط</Badge>,
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`الملف الشامل للتلميذ: ${student.fullName}`}
      subtitle={`رقم التعريف: ${student.code} · مسجل بتاريخ ${student.registrationDate}`}
      maxWidth="4xl"
    >
      <div className="space-y-6">
        {/* Top Summary Header */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center font-bold text-xl shadow-xs">
              {student.fullName.charAt(0)}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-slate-900">{student.fullName}</h3>
                {statusBadge[student.status]}
              </div>
              <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mt-1">
                <span className="flex items-center gap-1">
                  <UserIcon className="w-3.5 h-3.5" />
                  ولي الأمر: {student.guardianName} ({student.guardianRelation})
                </span>
                <span>·</span>
                <span className="flex items-center gap-1 font-mono text-slate-700">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <a href={`tel:${student.guardianPhone}`} className="hover:text-indigo-600">
                    {student.guardianPhone}
                  </a>
                </span>
                {student.address && (
                  <>
                    <span>·</span>
                    <span className="truncate max-w-xs">{student.address}</span>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onPrintStudentCard && (
              <Button
                variant="outline"
                size="sm"
                icon={<Printer className="w-4 h-4 text-indigo-600" />}
                onClick={() => onPrintStudentCard(student)}
                title="طباعة البطاقة التعريفية المدرسية للتلميذ"
              >
                طباعة البطاقة المدرسية
              </Button>
            )}
            <Button
              variant="primary"
              size="sm"
              icon={<CreditCard className="w-4 h-4" />}
              onClick={() => onOpenPaymentModal(student)}
            >
              تسجيل أداء مالي
            </Button>
            <Button
              variant="outline"
              size="sm"
              icon={<ArrowLeftRight className="w-4 h-4" />}
              onClick={() => onOpenTransferModal(student)}
            >
              تحويل مجموعة
            </Button>
            <Button
              variant="secondary"
              size="sm"
              onClick={() => onOpenEditModal(student)}
            >
              تعديل البيانات
            </Button>
          </div>
        </div>

        {/* Financial KPI Quick Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-500">إجمالي الرسوم المستحقة</span>
            <div className="text-xl font-bold text-slate-900 font-mono tabular-nums mt-0.5">
              {student.totalCharges.toFixed(2)} {settings.currency}
            </div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-500">إجمالي المبالغ المؤداة</span>
            <div className="text-xl font-bold text-emerald-700 font-mono tabular-nums mt-0.5">
              {student.totalPaid.toFixed(2)} {settings.currency}
            </div>
          </div>
          <div className="bg-white p-3.5 rounded-xl border border-slate-200">
            <span className="text-xs font-semibold text-slate-500">المبلغ المتبقي بذمته</span>
            <div
              className={`text-xl font-bold font-mono tabular-nums mt-0.5 ${
                student.remainingBalance > 0 ? 'text-rose-600' : 'text-emerald-600'
              }`}
            >
              {student.remainingBalance.toFixed(2)} {settings.currency}
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex items-center gap-1 border-b border-slate-200 pb-2">
          <button
            type="button"
            onClick={() => setActiveTab('financial')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'financial'
                ? 'bg-indigo-50 text-indigo-700 font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            السجل المالي والأداءات ({payments.length} وصل)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('groups')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
              activeTab === 'groups'
                ? 'bg-indigo-50 text-indigo-700 font-bold'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            }`}
          >
            المجموعات المسجل بها ({student.enrolledGroups.length})
          </button>
        </div>

        {/* Tab 1: Financial & Receipts */}
        {activeTab === 'financial' && (
          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  سجل وصولات الأداء الصادرة
                </h4>
                <span className="text-xs text-slate-500">
                  {payments.filter((p) => p.status === 'completed').length} وصل معتمد
                </span>
              </div>

              {payments.length === 0 ? (
                <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500">
                  لم يتم تسجيل أي وصل أداء لهذا التلميذ حتى الآن.
                </div>
              ) : (
                <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                  <table className="w-full text-right text-xs">
                    <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                      <tr>
                        <th className="py-2.5 px-3">رقم الوصل</th>
                        <th className="py-2.5 px-3">تاريخ الأداء</th>
                        <th className="py-2.5 px-3">البيان المالي</th>
                        <th className="py-2.5 px-3">طريقة الدفع</th>
                        <th className="py-2.5 px-3">المبلغ المؤدى</th>
                        <th className="py-2.5 px-3">المتبقي بعده</th>
                        <th className="py-2.5 px-3">الحالة</th>
                        <th className="py-2.5 px-3 text-left">إجراء</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {payments.map((pay) => (
                        <tr
                          key={pay.id}
                          className={`hover:bg-slate-50/80 transition-colors ${
                            pay.status === 'cancelled' ? 'opacity-60 bg-rose-50/20' : ''
                          }`}
                        >
                          <td className="py-3 px-3 font-mono font-bold text-slate-900">
                            {pay.receiptNumber}
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-600">{pay.paymentDate}</td>
                          <td className="py-3 px-3 max-w-xs truncate text-slate-800">
                            {pay.itemsCovered}
                          </td>
                          <td className="py-3 px-3 text-slate-600">
                            {pay.paymentMethod === 'cash' ? 'نقداً' : pay.paymentMethod === 'transfer' ? 'تحويل' : 'شيك'}
                          </td>
                          <td className="py-3 px-3 font-mono font-bold text-indigo-700 tabular-nums">
                            {pay.amountPaid.toFixed(2)} {settings.currency}
                          </td>
                          <td className="py-3 px-3 font-mono text-slate-600 tabular-nums">
                            {pay.remainingBalanceAfter.toFixed(2)} {settings.currency}
                          </td>
                          <td className="py-3 px-3">
                            {pay.status === 'completed' ? (
                              <Badge variant="success" size="sm">مكتمل</Badge>
                            ) : (
                              <Badge variant="danger" size="sm">ملغى</Badge>
                            )}
                          </td>
                          <td className="py-3 px-3 text-left">
                            <button
                              type="button"
                              onClick={() => onPrintPayment(pay)}
                              className="p-1.5 text-slate-600 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                              title="معاينة وطباعة الوصل"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>

            {/* Charges breakdown */}
            <div>
              <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                بيان الرسوم والاستحقاقات المسجلة
              </h4>
              <div className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-semibold">
                    <tr>
                      <th className="py-2.5 px-3">الرسم / الاستحقاق</th>
                      <th className="py-2.5 px-3">المبلغ الأصلي</th>
                      <th className="py-2.5 px-3">المبلغ المؤدى</th>
                      <th className="py-2.5 px-3">المبلغ المتبقي</th>
                      <th className="py-2.5 px-3">الحالة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {charges.map((chg) => (
                      <tr key={chg.id}>
                        <td className="py-2.5 px-3 font-medium text-slate-900">{chg.title}</td>
                        <td className="py-2.5 px-3 font-mono tabular-nums">{chg.amount.toFixed(2)} {settings.currency}</td>
                        <td className="py-2.5 px-3 font-mono text-emerald-700 tabular-nums">
                          {chg.paidAmount.toFixed(2)} {settings.currency}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-rose-600 tabular-nums font-semibold">
                          {chg.remainingAmount.toFixed(2)} {settings.currency}
                        </td>
                        <td className="py-2.5 px-3">
                          {chg.status === 'paid' ? (
                            <Badge variant="success" size="sm">مؤدى بالكامل</Badge>
                          ) : chg.status === 'partial' ? (
                            <Badge variant="warning" size="sm">مؤدى جزئياً</Badge>
                          ) : (
                            <Badge variant="danger" size="sm">غير مؤدى</Badge>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* Tab 2: Enrolled Groups */}
        {activeTab === 'groups' && (
          <div className="space-y-3">
            {student.enrolledGroups.length === 0 ? (
              <div className="text-center py-8 bg-slate-50 rounded-xl border border-dashed border-slate-200 text-xs text-slate-500">
                التلميذ غير مسجل في أي مجموعة دراسية حالياً.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {student.enrolledGroups.map((grp: { id: string; name: string; teacherName: string; monthlyFee: number }) => (
                  <div
                    key={grp.id}
                    className="p-4 bg-white border border-slate-200 rounded-xl flex items-center justify-between"
                  >
                    <div>
                      <h5 className="text-sm font-bold text-slate-900">{grp.name}</h5>
                      <p className="text-xs text-slate-500 mt-0.5">الأستاذ: {grp.teacherName}</p>
                    </div>
                    <div className="text-left font-mono font-bold text-slate-800 text-sm">
                      {grp.monthlyFee} {settings.currency}
                      <span className="block text-[11px] font-normal text-slate-500">شهرياً</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Close Button */}
        <div className="flex justify-end pt-4 border-t border-slate-100">
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق الملف
          </Button>
        </div>
      </div>
    </Modal>
  );
};
