import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { CenterSettings, DailyCashClosure } from '../../types';
import { dataService } from '../../services/data-service';
import {
  Lock,
  DollarSign,
  TrendingUp,
  TrendingDown,
  Printer,
  CheckCircle2,
  AlertTriangle,
  Calendar,
  FileText,
  Clock,
} from 'lucide-react';

interface DailyCashClosureModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: CenterSettings;
  onClosureSaved?: () => void;
}

export const DailyCashClosureModal: React.FC<DailyCashClosureModalProps> = ({
  isOpen,
  onClose,
  settings,
  onClosureSaved,
}) => {
  const todayStr = new Date().toISOString().substring(0, 10);
  const [closureDate, setClosureDate] = useState(todayStr);
  const [openingCash, setOpeningCash] = useState<number>(0);
  const [actualCash, setActualCash] = useState<number>(0);
  const [notes, setNotes] = useState('');
  const [summary, setSummary] = useState<any | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [savedClosure, setSavedClosure] = useState<DailyCashClosure | null>(null);

  // Load summary for chosen date
  useEffect(() => {
    if (!isOpen) return;
    dataService.calculateTodayCashSummary(closureDate).then((sum) => {
      setSummary(sum);
      if (sum.lastClosure) {
        setOpeningCash(sum.lastClosure.openingCash);
        setActualCash(sum.lastClosure.actualCashInDrawer);
        setNotes(sum.lastClosure.notes || '');
        setSavedClosure(sum.lastClosure);
      } else {
        const expected = sum.totalCashIncome - sum.totalCashExpense;
        setActualCash(expected > 0 ? expected : 0);
        setSavedClosure(null);
      }
    });
  }, [isOpen, closureDate]);

  if (!summary) return null;

  const expectedCash = openingCash + summary.totalCashIncome - summary.totalCashExpense;
  const discrepancy = actualCash - expectedCash;

  const handleSaveClosure = async () => {
    try {
      setIsSaving(true);
      const res = await dataService.recordDailyCashClosure({
        date: closureDate,
        openingCash: Number(openingCash),
        actualCashInDrawer: Number(actualCash),
        notes,
      });
      setSavedClosure(res);
      if (onClosureSaved) onClosureSaved();
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="إغلاق وموازنة الصندوق اليومي (Clôture de Caisse)"
      subtitle="حصر السيولة النقدية الفعلية ومطابقة المداخيل والمصاريف اليومية قبل إغلاق الخزينة"
      maxWidth="lg"
    >
      <div className="space-y-4 text-xs" dir="rtl">
        {/* Date Selector & Status */}
        <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-indigo-600" />
            <span className="font-bold text-slate-700">تاريخ الإغلاق الصندوقي:</span>
            <input
              type="date"
              value={closureDate}
              onChange={(e) => setClosureDate(e.target.value)}
              className="bg-white p-1 px-2 border border-slate-300 rounded-md font-mono text-xs font-semibold outline-none focus:border-indigo-500"
            />
          </div>

          {savedClosure ? (
            <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold rounded-lg flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
              <span>تم الإغلاق مسبقاً ({savedClosure.closedAt.substring(11)})</span>
            </span>
          ) : (
            <span className="px-2.5 py-1 bg-amber-100 text-amber-800 font-bold rounded-lg flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-amber-600" />
              <span>الصندوق قيد التداول اليومي</span>
            </span>
          )}
        </div>

        {/* Daily Cash Breakdown Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-center">
            <span className="text-[11px] text-slate-500 font-medium block">رصيد بداية اليوم (درج الصندوق)</span>
            <input
              type="number"
              min="0"
              value={openingCash}
              onChange={(e) => setOpeningCash(Number(e.target.value))}
              className="mt-1 w-24 p-1 text-center font-bold font-mono text-sm bg-white border border-slate-300 rounded-lg outline-none"
            />
          </div>

          <div className="p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl text-center">
            <span className="text-[11px] text-emerald-700 font-medium block">المقبوضات النقدية اليوم (+):</span>
            <span className="text-base font-black font-mono text-emerald-900 mt-1 block">
              +{summary.totalCashIncome.toLocaleString('fr-FR')} {settings.currency}
            </span>
            <span className="text-[10px] text-emerald-600 font-mono">({summary.paymentTransactionsCount} وصل)</span>
          </div>

          <div className="p-3 bg-rose-50/70 border border-rose-100 rounded-xl text-center">
            <span className="text-[11px] text-rose-700 font-medium block">المصاريف النقدية اليوم (-):</span>
            <span className="text-base font-black font-mono text-rose-900 mt-1 block">
              -{summary.totalCashExpense.toLocaleString('fr-FR')} {settings.currency}
            </span>
            <span className="text-[10px] text-rose-600 font-mono">({summary.expenseTransactionsCount} عملية)</span>
          </div>

          <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-xl text-center">
            <span className="text-[11px] text-indigo-700 font-medium block">الرصيد النقدي المتوقع بالدرج:</span>
            <span className="text-base font-black font-mono text-indigo-950 mt-1 block">
              {expectedCash.toLocaleString('fr-FR')} {settings.currency}
            </span>
            <span className="text-[10px] text-indigo-500">حساب آلي من السجلات</span>
          </div>
        </div>

        {/* Actual Counted Cash & Discrepancy Box */}
        <div className="p-4 bg-slate-50 rounded-2xl border-2 border-slate-300 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div>
              <label className="block text-slate-800 font-bold mb-1">
                المبلغ النقدي الفعلي المحسوب في درج الصندوق الآن *
              </label>
              <div className="relative">
                <input
                  type="number"
                  min="0"
                  value={actualCash}
                  onChange={(e) => setActualCash(Number(e.target.value))}
                  className="w-full p-2.5 text-lg font-black font-mono bg-white border-2 border-indigo-500 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none"
                  required
                />
                <span className="absolute left-3 top-3 font-bold text-slate-400 font-mono">{settings.currency}</span>
              </div>
            </div>

            {/* Discrepancy Result Badge */}
            <div className="p-3 rounded-xl border flex flex-col justify-center text-center">
              <span className="text-[11px] text-slate-500 font-medium">حالة المطابقة المالية الصندوقية:</span>
              {discrepancy === 0 ? (
                <div className="flex items-center justify-center gap-1.5 text-emerald-700 font-black text-sm mt-1">
                  <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                  <span>متطابق تماماً بدون أي فارق (0.00 د.م) ✓</span>
                </div>
              ) : discrepancy < 0 ? (
                <div className="flex items-center justify-center gap-1.5 text-rose-700 font-black text-sm mt-1">
                  <AlertTriangle className="w-5 h-5 text-rose-600" />
                  <span>عجز مالي في الصندوق: {discrepancy.toLocaleString('fr-FR')} {settings.currency}</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-1.5 text-amber-700 font-black text-sm mt-1">
                  <TrendingUp className="w-5 h-5 text-amber-600" />
                  <span>فائض نقدي إضافي: +{discrepancy.toLocaleString('fr-FR')} {settings.currency}</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <label className="block text-slate-700 font-bold mb-1">
              ملاحظات وتبريرات الإغلاق الصندوقي (اختياري):
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: تسليم مبالغ الصندوق للمدير، احتفاظ بـ 200 د.م كصرف للغد..."
              className="w-full p-2 bg-white border border-slate-300 rounded-lg text-xs outline-none focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Printable Official Closure Slip */}
        {savedClosure && (
          <div className="p-4 bg-white border-2 border-dashed border-slate-300 rounded-xl space-y-2 text-center text-xs">
            <p className="font-bold text-slate-800">
              تم اعتماد وإغلاق صندوق يوم {savedClosure.date} بواسطة {savedClosure.closedByUserName} الساعة {savedClosure.closedAt.substring(11)}.
            </p>
            <Button
              variant="outline"
              size="sm"
              icon={<Printer className="w-4 h-4 text-slate-700" />}
              onClick={() => window.print()}
            >
              طباعة محضر إغلاق الصندوق اليومي المعتمد 📄
            </Button>
          </div>
        )}

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق
          </Button>

          <Button
            variant="primary"
            size="sm"
            icon={<Lock className="w-4 h-4" />}
            onClick={handleSaveClosure}
            isLoading={isSaving}
          >
            اعتماد وحفظ إغلاق الصندوق اليومي 🔒
          </Button>
        </div>
      </div>
    </Modal>
  );
};
