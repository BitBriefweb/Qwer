import React, { useState, useEffect } from 'react';
import { StudentWithDetails, FeeCharge, Payment, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';

interface PaymentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: StudentWithDetails[];
  initialStudent?: StudentWithDetails | null;
  settings: CenterSettings;
  onPaymentSuccess: (payment: Payment) => void;
}

export const PaymentFormModal: React.FC<PaymentFormModalProps> = ({
  isOpen,
  onClose,
  students,
  initialStudent,
  settings,
  onPaymentSuccess,
}) => {
  const [selectedStudentId, setSelectedStudentId] = useState('');
  const [studentCharges, setStudentCharges] = useState<FeeCharge[]>([]);
  const [selectedChargeId, setSelectedChargeId] = useState<string>('');
  const [amountPaid, setAmountPaid] = useState<number | ''>('');
  const [monthsCount, setMonthsCount] = useState<number>(1);
  const [paymentMethod, setPaymentMethod] = useState<Payment['paymentMethod']>('cash');
  const [referenceNumber, setReferenceNumber] = useState('');
  const [itemsCovered, setItemsCovered] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const MONTH_NAMES = [
    'يناير', 'فبراير', 'مارس', 'أبريل', 'ماي', 'يونيو',
    'يوليوز', 'غشت', 'شتنبر', 'أكتوبر', 'نونبر', 'دجنبر'
  ];

  const getUpcomingMonthsNames = (count: number): string => {
    const currentMonthIndex = new Date().getMonth();
    const months: string[] = [];
    for (let i = 0; i < count; i++) {
      months.push(MONTH_NAMES[(currentMonthIndex + i) % 12]);
    }
    return months.join('، ');
  };

  const handleSelectMonthsDuration = (numMonths: number) => {
    setMonthsCount(numMonths);
    const stu = students.find((s) => s.id === selectedStudentId);
    const singleMonthFee =
      stu && stu.enrolledGroups.length > 0
        ? stu.enrolledGroups.reduce((acc, g) => acc + (g.monthlyFee || 0), 0)
        : (stu?.remainingBalance && stu.remainingBalance > 0 ? Math.min(stu.remainingBalance, 400) : 350);

    const calculatedTotal = singleMonthFee * numMonths;
    setAmountPaid(calculatedTotal);

    if (numMonths === 1) {
      setItemsCovered(`واجب شهر واحد (${MONTH_NAMES[new Date().getMonth()]})`);
    } else {
      setItemsCovered(`واجب ${numMonths} أشهر (${getUpcomingMonthsNames(numMonths)})`);
    }
  };

  useEffect(() => {
    if (initialStudent) {
      setSelectedStudentId(initialStudent.id);
    } else if (students.length > 0 && !selectedStudentId) {
      setSelectedStudentId(students[0].id);
    }
  }, [initialStudent, isOpen, students]);

  useEffect(() => {
    if (selectedStudentId) {
      loadStudentCharges(selectedStudentId);
    } else {
      setStudentCharges([]);
    }
  }, [selectedStudentId]);

  const loadStudentCharges = async (stuId: string) => {
    try {
      const list = await dataService.getCharges(stuId);
      const unpaidOrPartial = list.filter((c) => c.status !== 'paid');
      setStudentCharges(unpaidOrPartial);

      if (unpaidOrPartial.length > 0) {
        setSelectedChargeId(unpaidOrPartial[0].id);
        setAmountPaid(unpaidOrPartial[0].remainingAmount);
        setItemsCovered(unpaidOrPartial[0].title);
      } else {
        setSelectedChargeId('');
        const stu = students.find((s) => s.id === stuId);
        setAmountPaid(stu?.enrolledGroups[0]?.monthlyFee || 350);
        setItemsCovered('واجب الدعم والتقوية الشهري');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleChargeSelect = (chargeId: string) => {
    setSelectedChargeId(chargeId);
    if (!chargeId) {
      setItemsCovered('أداء حر / دفعة عامة');
      return;
    }
    const chg = studentCharges.find((c) => c.id === chargeId);
    if (chg) {
      setAmountPaid(chg.remainingAmount);
      setItemsCovered(chg.title);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const numericAmount = Number(amountPaid);
    if (!selectedStudentId) {
      setError('يرجى تحديد التلميذ');
      return;
    }
    if (!numericAmount || numericAmount <= 0) {
      setError('يرجى إدخال مبلغ صحيح أكبر من 0 درهم');
      return;
    }
    if (!itemsCovered.trim()) {
      setError('يرجى توضيح سبب أو بيان الأداء (مثال: واجب شهر أكتوبر)');
      return;
    }

    try {
      setIsSubmitting(true);
      const payment = await dataService.recordPayment({
        studentId: selectedStudentId,
        chargeId: selectedChargeId || undefined,
        amountPaid: numericAmount,
        paymentMethod,
        referenceNumber: referenceNumber.trim() || undefined,
        notes: notes.trim() || undefined,
        itemsCovered: itemsCovered.trim(),
      });

      onPaymentSuccess(payment);
      onClose();
    } catch (err) {
      setError((err as Error).message || 'حدث خطأ أثناء تسجيل عملية الأداء');
    } finally {
      setIsSubmitting(false);
    }
  };

  const currentStudent = students.find((s) => s.id === selectedStudentId);

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="تسجيل أداء مالي وإصدار وصل"
      subtitle="إدخال دفعة مالية لحساب التلميذ وتحديث الرصيد التلقائي"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {error}
          </div>
        )}

        {/* Student Selector */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            التلميذ المعني بالأداء <span className="text-rose-500">*</span>
          </label>
          <select
            value={selectedStudentId}
            onChange={(e) => setSelectedStudentId(e.target.value)}
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            required
          >
            <option value="">اختر التلميذ...</option>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.fullName} ({s.code}) - المتبقي في ذمته: {s.remainingBalance} {settings.currency}
              </option>
            ))}
          </select>
        </div>

        {/* Student Financial summary pill */}
        {currentStudent && (
          <div className="bg-slate-50 border border-slate-200 p-3 rounded-lg flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500">إجمالي المتبقي على التلميذ:</span>
              <span className="font-mono font-bold text-rose-600 mr-1.5 tabular-nums">
                {currentStudent.remainingBalance.toFixed(2)} {settings.currency}
              </span>
            </div>
            <div>
              <span className="text-slate-500">المجموعات:</span>
              <span className="font-medium text-slate-800 mr-1.5">
                {currentStudent.enrolledGroups.map((g: { name: string }) => g.name).join('، ') || 'بدون مجموعة'}
              </span>
            </div>
          </div>
        )}

        {/* Charges Dropdown (if any) */}
        {studentCharges.length > 0 && (
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              ربط الأداء باستحقاق مسجل مسبقاً (اختياري)
            </label>
            <select
              value={selectedChargeId}
              onChange={(e) => handleChargeSelect(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            >
              <option value="">أداء حر / غير مرتبط برسم محدد</option>
              {studentCharges.map((chg) => (
                <option key={chg.id} value={chg.id}>
                  {chg.title} (المتبقي: {chg.remainingAmount} {settings.currency})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* Months Duration Selector (دفع لشهر، شهرين، 3 أشهر، 4 أشهر...) */}
        <div className="bg-indigo-50/70 border border-indigo-100 p-3 rounded-xl space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
              <span>📅 تحديد مدة الأداء (كم شهراً يريد الدفع؟):</span>
            </label>
            <span className="text-[11px] text-indigo-600 font-semibold">
              يُحسب المبلغ واسم الأشهر تلقائياً
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {[
              { count: 1, label: 'شهر واحد (1)' },
              { count: 2, label: 'شهرين (2)' },
              { count: 3, label: '3 أشهر (فصل)' },
              { count: 4, label: '4 أشهر' },
              { count: 5, label: 'نصف سنة (5)' },
            ].map((item) => (
              <button
                key={item.count}
                type="button"
                onClick={() => handleSelectMonthsDuration(item.count)}
                className={`py-1.5 px-2 rounded-lg text-xs font-bold transition-all cursor-pointer text-center border ${
                  monthsCount === item.count
                    ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-indigo-50 hover:text-indigo-700'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>
        </div>

        {/* Amount & Method */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              المبلغ المؤدى بالدرهم <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <input
                type="number"
                step="any"
                min="1"
                value={amountPaid}
                onChange={(e) => setAmountPaid(e.target.value === '' ? '' : Number(e.target.value))}
                placeholder="0.00"
                className="w-full px-3 py-2 text-base font-mono font-bold bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none tabular-nums"
                required
              />
              <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                {settings.currency}
              </span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">طريقة الدفع</label>
            <select
              value={paymentMethod}
              onChange={(e) => setPaymentMethod(e.target.value as Payment['paymentMethod'])}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            >
              <option value="cash">نقداً (Espèces)</option>
              <option value="transfer">تحويل بنكي (Virement)</option>
              <option value="cheque">شيك بنكي (Chèque)</option>
              <option value="card">بطاقة بنكية (TPE)</option>
              <option value="other">أخرى</option>
            </select>
          </div>
        </div>

        {/* Reference & Items Covered */}
        <div className="space-y-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              بيان الأداء (الظاهر في الوصل المطبوع) <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={itemsCovered}
              onChange={(e) => setItemsCovered(e.target.value)}
              placeholder="مثال: واجب شهر أكتوبر 2026 - مادة الرياضيات"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              required
            />
          </div>

          {paymentMethod !== 'cash' && (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                رقم الشيك أو مرجع التحويل البنكي
              </label>
              <input
                type="text"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                placeholder="مثال: CHQ-984021 أو VIR-ATW-0091"
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">ملاحظات مالية</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="أي ملاحظة إضافية للتوثيق..."
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
            />
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
            تسجيل الأداء وإصدار الوصل
          </Button>
        </div>
      </form>
    </Modal>
  );
};
