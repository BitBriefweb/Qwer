import React, { useState } from 'react';
import { Payment } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { AlertTriangle } from 'lucide-react';

interface CancelPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  payment: Payment | null;
  onConfirmCancel: (paymentId: string, reason: string) => Promise<void>;
}

export const CancelPaymentModal: React.FC<CancelPaymentModalProps> = ({
  isOpen,
  onClose,
  payment,
  onConfirmCancel,
}) => {
  const [reason, setReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!payment) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!reason.trim() || reason.trim().length < 5) {
      setError('يرجى كتابة سبب مفصل لإلغاء هذا الوصل المالي (5 أحرف على الأقل)');
      return;
    }

    try {
      setIsSubmitting(true);
      await onConfirmCancel(payment.id, reason.trim());
      onClose();
    } catch (err) {
      setError((err as Error).message || 'حدث خطأ أثناء إلغاء الوصل');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="إلغاء / تصحيح عملية مالية موثقة"
      subtitle={`الوصل رقم: ${payment.receiptNumber} بقيمة ${payment.amountPaid} درهم`}
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {error}
          </div>
        )}

        <div className="flex items-start gap-3 p-3 bg-amber-50 border border-amber-200 rounded-lg text-xs text-amber-900 leading-relaxed">
          <AlertTriangle className="w-5 h-5 shrink-0 text-amber-600 mt-0.5" />
          <div>
            <strong>ضوابط الحماية المحاسبية:</strong> لن يتم حذف الوصل نهائياً من قاعدة البيانات، بل
            سيتم وسمه كـ "ملغى" مع إعادة احتساب المبلغ المتبقي على التلميذ، وتوثيق سبب الإلغاء
            واسم المستخدم في سجل التدقيق المالي.
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            سبب الإلغاء أو التصحيح <span className="text-rose-500">*</span>
          </label>
          <textarea
            rows={3}
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="مثال: خطأ في إدخال المبلغ، تراجع ولي الأمر عن التسجيل، إلغاء الشيك..."
            className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-rose-500 focus:border-rose-500 outline-none"
            required
          />
        </div>

        <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            تراجع
          </Button>
          <Button type="submit" variant="danger" size="sm" isLoading={isSubmitting}>
            تأكيد إلغاء الوصل
          </Button>
        </div>
      </form>
    </Modal>
  );
};
