import React, { useState } from 'react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';
import {
  MonthlyFinanceTrend,
  AttendanceDistributionItem,
  SubjectAnalyticsItem,
} from '../../services/data-service';
import { CenterSettings, ConnectedDevice } from '../../types';
import {
  TrendingUp,
  BarChart3,
  PieChart as PieIcon,
  Tablet,
  CalendarCheck,
  Smartphone,
  ChevronLeft,
  Sparkles,
  Layers,
  ArrowUpRight,
} from 'lucide-react';
import { Button } from '../common/Button';

interface DashboardChartsProps {
  monthlyTrends: MonthlyFinanceTrend[];
  attendanceDistribution: AttendanceDistributionItem[];
  subjectAnalytics: SubjectAnalyticsItem[];
  overallAttendanceRate: number;
  totalPresent: number;
  totalAbsent: number;
  totalLate: number;
  settings: CenterSettings;
  devices: ConnectedDevice[];
  onNavigateSection: (section: any) => void;
  onOpenMobileTerminal: (device: ConnectedDevice) => void;
}

export const DashboardCharts: React.FC<DashboardChartsProps> = ({
  monthlyTrends,
  attendanceDistribution,
  subjectAnalytics,
  overallAttendanceRate,
  totalPresent,
  totalAbsent,
  totalLate,
  settings,
  devices,
  onNavigateSection,
  onOpenMobileTerminal,
}) => {
  const [activeTab, setActiveTab] = useState<'finance' | 'attendance' | 'branches'>('finance');
  const [financeChartType, setFinanceChartType] = useState<'area' | 'bar'>('area');

  const totalAttendanceRecords = totalPresent + totalAbsent + totalLate;

  // Calculate cumulative financial KPIs over the 6 months period
  const totalPeriodRevenue = monthlyTrends.reduce((sum, item) => sum + (item.revenue || 0), 0);
  const totalPeriodExpenses = monthlyTrends.reduce((sum, item) => sum + (item.expenses || 0), 0);
  const totalPeriodNet = totalPeriodRevenue - totalPeriodExpenses;

  // Custom Currency Tooltip for AreaChart & BarChart
  const CustomFinanceTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-right text-xs space-y-1.5 font-sans" dir="rtl">
          <p className="font-bold text-slate-300 pb-1 border-b border-slate-700">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={`item-${index}`} className="flex items-center justify-between gap-4">
              <span className="flex items-center gap-1.5" style={{ color: entry.color }}>
                <span className="w-2 h-2 rounded-full inline-block" style={{ backgroundColor: entry.color }} />
                <span>{entry.name}:</span>
              </span>
              <span className="font-mono font-bold text-white tabular-nums">
                {Number(entry.value).toLocaleString('fr-FR')} {settings.currency}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  // Custom Attendance Pie Tooltip
  const CustomAttendanceTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0];
      return (
        <div className="bg-slate-900 text-white p-2.5 rounded-xl shadow-xl border border-slate-700 text-right text-xs font-sans" dir="rtl">
          <p className="font-bold flex items-center gap-1.5" style={{ color: data.payload.color }}>
            <span className="w-2 h-2 rounded-full" style={{ backgroundColor: data.payload.color }} />
            <span>{data.name}</span>
          </p>
          <p className="text-[11px] text-slate-300 mt-1">
            العدد: <span className="font-mono font-bold text-white">{data.value} تلميذاً</span> ({data.payload.percentage}%)
          </p>
        </div>
      );
    }
    return null;
  };

  // Custom Subject Bar Tooltip
  const CustomSubjectTooltip = ({ active, payload }: any) => {
    if (active && payload && payload.length) {
      const data = payload[0].payload;
      return (
        <div className="bg-slate-900 text-white p-3 rounded-xl shadow-xl border border-slate-700 text-right text-xs space-y-1 font-sans" dir="rtl">
          <p className="font-bold text-white text-sm">{data.name}</p>
          <p className="text-[11px] text-slate-300">
            المداخيل: <span className="font-mono font-bold text-emerald-400">{Number(data.revenue).toLocaleString('fr-FR')} {settings.currency}</span>
          </p>
          <p className="text-[11px] text-slate-300">
            التلاميذ: <span className="font-mono font-bold text-indigo-300">{data.studentsCount} تلميذاً</span>
          </p>
          <p className="text-[11px] text-slate-300">
            الأفواج: <span className="font-mono font-bold text-amber-300">{data.groupsCount} أفواج</span>
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="space-y-4">
      {/* Chart Navigation Tabs & Quick Tablet CTA */}
      <div className="bg-white p-3 rounded-2xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
          <button
            type="button"
            onClick={() => setActiveTab('finance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'finance'
                ? 'bg-white text-indigo-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <TrendingUp className="w-4 h-4 text-indigo-600" />
            <span>الأداء المالي والسيولة (Recharts)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'attendance'
                ? 'bg-white text-emerald-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CalendarCheck className="w-4 h-4 text-emerald-600" />
            <span>إحصائيات حضور التلاميذ (التابليت والحاسوب)</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('branches')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg transition-all cursor-pointer ${
              activeTab === 'branches'
                ? 'bg-white text-cyan-700 shadow-xs font-bold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4 text-cyan-600" />
            <span>مداخيل الفروع واللغات</span>
          </button>
        </div>

        {/* Quick Link to Connected Devices */}
        <div className="flex items-center gap-2">
          {devices.length > 0 && (
            <button
              type="button"
              onClick={() => onOpenMobileTerminal(devices[0])}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200 transition-colors cursor-pointer shadow-xs"
            >
              <Tablet className="w-3.5 h-3.5 text-emerald-600" />
              <span>📱 فتح التابليت ({devices[0].name})</span>
            </button>
          )}

          <Button
            variant="outline"
            size="sm"
            icon={<Smartphone className="w-3.5 h-3.5 text-indigo-600" />}
            onClick={() => onNavigateSection('devices')}
          >
            إدارة أجهزة التابليت والهاتف ({devices.length})
          </Button>
        </div>
      </div>

      {/* 1. Tab: Financial Cashflow & Revenue Trends (Recharts AreaChart / BarChart) */}
      {activeTab === 'finance' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-indigo-600" />
                <span>الرسم البياني التفاعلي لتطور المداخيل والمصاريف وصافي السيولة</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                تتبع شهري تفاعلي ومباشر للتدفقات النقدية الصندوقية الحقيقية بالدرهم المغربي ({settings.currency})
              </p>
            </div>

            {/* Controls: Area vs Bar chart switch */}
            <div className="flex items-center gap-2">
              <div className="flex items-center bg-slate-100 p-0.5 rounded-lg text-xs font-medium">
                <button
                  type="button"
                  onClick={() => setFinanceChartType('area')}
                  className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                    financeChartType === 'area'
                      ? 'bg-white text-indigo-700 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  منحنى انسيابي (Area)
                </button>
                <button
                  type="button"
                  onClick={() => setFinanceChartType('bar')}
                  className={`px-2.5 py-1 rounded-md transition-colors cursor-pointer ${
                    financeChartType === 'bar'
                      ? 'bg-white text-indigo-700 font-bold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  أعمدة متقابلة (Bars)
                </button>
              </div>

              <div className="hidden sm:flex items-center gap-3 text-xs font-bold border-r pr-3 border-slate-200">
                <span className="flex items-center gap-1 text-indigo-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-indigo-600 inline-block" />
                  المداخيل
                </span>
                <span className="flex items-center gap-1 text-rose-500">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block" />
                  المصاريف
                </span>
                <span className="flex items-center gap-1 text-emerald-600">
                  <span className="w-2.5 h-2.5 rounded-full bg-emerald-600 inline-block" />
                  صافي الفائض
                </span>
              </div>
            </div>
          </div>

          {/* Quick Metrics Banner */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[11px] text-indigo-700 font-medium block">مجموع المداخيل المحصلة (6 أشهر)</span>
                <span className="text-base font-black font-mono text-indigo-900">
                  {totalPeriodRevenue.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <span className="w-2.5 h-2.5 rounded-full bg-indigo-600"></span>
            </div>

            <div className="p-3 bg-rose-50/60 border border-rose-100 rounded-xl flex items-center justify-between">
              <div>
                <span className="text-[11px] text-rose-700 font-medium block">مجموع المصاريف التشغيلية (6 أشهر)</span>
                <span className="text-base font-black font-mono text-rose-900">
                  {totalPeriodExpenses.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
            </div>

            <div className={`p-3 rounded-xl border flex items-center justify-between ${
              totalPeriodNet >= 0
                ? 'bg-emerald-50/60 border-emerald-100 text-emerald-900'
                : 'bg-amber-50/60 border-amber-100 text-amber-900'
            }`}>
              <div>
                <span className="text-[11px] font-medium block">صافي الفائض الصندوقي التراكمي</span>
                <span className="text-base font-black font-mono">
                  {totalPeriodNet.toLocaleString('fr-FR')} {settings.currency}
                </span>
              </div>
              <span className={`w-2.5 h-2.5 rounded-full ${totalPeriodNet >= 0 ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
            </div>
          </div>

          {/* Recharts Area / Bar Display */}
          <div className="h-[300px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              {financeChartType === 'area' ? (
                <AreaChart data={monthlyTrends} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#4f46e5" stopOpacity={0.4} />
                      <stop offset="95%" stopColor="#4f46e5" stopOpacity={0.0} />
                    </linearGradient>
                    <linearGradient id="colorExpenses" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.35} />
                      <stop offset="95%" stopColor="#f43f5e" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis
                    dataKey="monthName"
                    tickLine={false}
                    stroke="#94a3b8"
                    fontSize={11}
                    dy={6}
                  />
                  <YAxis
                    tickLine={false}
                    stroke="#94a3b8"
                    fontSize={11}
                    dx={-6}
                    tickFormatter={(val) => `${val}`}
                  />
                  <Tooltip content={<CustomFinanceTooltip />} />
                  <Area
                    type="monotone"
                    dataKey="revenue"
                    name="المداخيل المحصلة"
                    stroke="#4f46e5"
                    strokeWidth={2.5}
                    fillOpacity={1}
                    fill="url(#colorRevenue)"
                  />
                  <Area
                    type="monotone"
                    dataKey="expenses"
                    name="المصاريف التشغيلية"
                    stroke="#f43f5e"
                    strokeWidth={2}
                    fillOpacity={1}
                    fill="url(#colorExpenses)"
                  />
                </AreaChart>
              ) : (
                <BarChart data={monthlyTrends} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis
                    dataKey="monthName"
                    tickLine={false}
                    stroke="#94a3b8"
                    fontSize={11}
                    dy={6}
                  />
                  <YAxis
                    tickLine={false}
                    stroke="#94a3b8"
                    fontSize={11}
                    dx={-6}
                    tickFormatter={(val) => `${val}`}
                  />
                  <Tooltip content={<CustomFinanceTooltip />} />
                  <Bar dataKey="revenue" name="المداخيل المحصلة" fill="#4f46e5" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="expenses" name="المصاريف التشغيلية" fill="#f43f5e" radius={[4, 4, 0, 0]} />
                </BarChart>
              )}
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* 2. Tab: Student Attendance Analytics (PieChart & Metrics & Device Link) */}
      {activeTab === 'attendance' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <CalendarCheck className="w-4 h-4 text-emerald-600" />
                <span>توزيع نسب الحضور والغياب والتأخر للتلاميذ</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                مؤشرات بصرية دقيقة لتسجيل الحضور عبر أجهزة التابليت والهواتف المتنقلة مع الحفظ التلقائي في الحاسوب
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-xl text-xs font-bold">
                نسبة الحضور الإجمالية: {overallAttendanceRate}%
              </span>
              <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-xl text-xs font-mono font-medium">
                {totalAttendanceRecords} تسجيل مسجل
              </span>
            </div>
          </div>

          {totalAttendanceRecords === 0 ? (
            /* Friendly Empty State if no records taken yet */
            <div className="p-8 text-center bg-slate-50/70 rounded-2xl border-2 border-dashed border-slate-200 space-y-4">
              <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mx-auto">
                <Tablet className="w-7 h-7" />
              </div>
              <div className="space-y-1 max-w-lg mx-auto">
                <h4 className="font-bold text-sm text-slate-900">
                  لا توجد تسجيلات غياب أو حضور مسجلة حتى الآن
                </h4>
                <p className="text-xs text-slate-500 leading-relaxed">
                  يمكن للأستاذ حمل الهاتف أو التابليت لتسجيل غياب التلاميذ داخل القاعة بنقرة زر واحدة دون الحاجة لحمل الحاسوب، وستظهر كافة الرسوم البيانية التفاعلية هنا في الحاسوب فوراً!
                </p>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
                {devices.length > 0 && (
                  <Button
                    variant="primary"
                    size="sm"
                    icon={<Tablet className="w-4 h-4" />}
                    onClick={() => onOpenMobileTerminal(devices[0])}
                  >
                    📱 تجربة تسجيل الحضور عبر التابليت الآن
                  </Button>
                )}
                <Button
                  variant="outline"
                  size="sm"
                  icon={<Smartphone className="w-4 h-4 text-indigo-600" />}
                  onClick={() => onNavigateSection('devices')}
                >
                  إضافة وربط تابليت أو هاتف جديد
                </Button>
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => onNavigateSection('attendance')}
                >
                  تسجيل الحضور من الحاسوب
                </Button>
              </div>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
              {/* Donut Pie Chart */}
              <div className="h-[260px] w-full flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Tooltip content={<CustomAttendanceTooltip />} />
                    <Pie
                      data={attendanceDistribution}
                      dataKey="count"
                      nameKey="name"
                      cx="50%"
                      cy="50%"
                      innerRadius={55}
                      outerRadius={88}
                      paddingAngle={4}
                    >
                      {attendanceDistribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Attendance Legends & Counts (2 Columns) */}
              <div className="md:col-span-2 grid grid-cols-2 gap-3">
                {attendanceDistribution.map((item) => (
                  <div
                    key={item.name}
                    className="p-3.5 rounded-xl border border-slate-200 bg-slate-50/50 space-y-1.5"
                    style={{ borderRightWidth: '4px', borderRightColor: item.color }}
                  >
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-800">{item.name}</span>
                      <span className="font-mono font-bold text-slate-900">{item.percentage}%</span>
                    </div>
                    <div className="text-lg font-black font-mono" style={{ color: item.color }}>
                      {item.count} <span className="text-xs font-normal text-slate-500">تسجيل</span>
                    </div>
                  </div>
                ))}

                {/* Tablet Info box */}
                <div className="col-span-2 p-3.5 bg-linear-to-r from-indigo-50 to-emerald-50 border border-indigo-100 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="p-1.5 bg-indigo-600 text-white rounded-lg">
                      <Tablet className="w-4 h-4" />
                    </span>
                    <span className="text-slate-800 font-medium">
                      يسجل الأستاذ الغياب بالتابليت داخل القاعة، وتتزامن النتائج فوراً مع الحاسوب.
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {devices.length > 0 && (
                      <button
                        type="button"
                        onClick={() => onOpenMobileTerminal(devices[0])}
                        className="px-2.5 py-1 bg-white hover:bg-slate-100 text-indigo-700 border border-indigo-200 rounded-lg font-bold text-xs cursor-pointer shadow-2xs"
                      >
                        فتح التابليت الآن 📱
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onNavigateSection('devices')}
                      className="font-bold text-indigo-700 hover:text-indigo-900 underline cursor-pointer text-xs"
                    >
                      ربط أجهزة جديدة ←
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* 3. Tab: Branch & Language Revenues (BarChart) */}
      {activeTab === 'branches' && (
        <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div>
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-600" />
                <span>مقارنة مداخيل الفروع واللغات (الألمانية، الإنجليزية، الفرنسية...)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                حجم المداخيل المحصلة لكل مادة أو فرع دراسي مستقل مع أعداد التلاميذ المسجلين
              </p>
            </div>
            <button
              type="button"
              onClick={() => onNavigateSection('branches')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors"
            >
              عرض مساحة تسيير الفروع ←
            </button>
          </div>

          <div className="h-[280px] w-full pt-2">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={subjectAnalytics} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis
                  dataKey="name"
                  tickLine={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  dy={6}
                />
                <YAxis
                  tickLine={false}
                  stroke="#94a3b8"
                  fontSize={11}
                  dx={-6}
                />
                <Tooltip content={<CustomSubjectTooltip />} />
                <Bar dataKey="revenue" name="المداخيل (د.م)" radius={[6, 6, 0, 0]}>
                  {subjectAnalytics.map((entry, index) => (
                    <Cell key={`bar-${index}`} fill={entry.color || '#4f46e5'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}
    </div>
  );
};
