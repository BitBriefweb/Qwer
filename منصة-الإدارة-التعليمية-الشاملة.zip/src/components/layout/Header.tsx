import React from 'react';
import { Button } from '../common/Button';
import {
  UserPlus,
  CreditCard,
  Calendar,
  HardDriveDownload,
  ShieldCheck,
  Search,
  Sparkles,
  School,
  Lock,
} from 'lucide-react';
import { CenterSettings, User } from '../../types';

interface HeaderProps {
  sectionTitle: string;
  settings: CenterSettings;
  currentUser: User;
  onOpenNewStudentModal: () => void;
  onOpenPaymentModal: () => void;
  onQuickBackup: () => void;
  onOpenSearch?: () => void;
  onOpenCashClosure?: () => void;
  onOpenInstitutionProfile?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  sectionTitle,
  settings,
  currentUser,
  onOpenNewStudentModal,
  onOpenPaymentModal,
  onQuickBackup,
  onOpenSearch,
  onOpenCashClosure,
  onOpenInstitutionProfile,
}) => {
  const todayFormatted = new Intl.DateTimeFormat('ar-MA', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date());

  return (
    <header className="h-16 bg-white/95 backdrop-blur-md border-b border-slate-200/90 px-6 flex items-center justify-between shrink-0 shadow-2xs z-10 sticky top-0">
      {/* Zone 1: Institutional Breadcrumb & Profile Trigger */}
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={onOpenInstitutionProfile}
          className="flex items-center gap-2 p-1.5 -mr-1.5 rounded-xl hover:bg-slate-100 transition-all text-right group cursor-pointer"
          title="اضغط لتعديل بروفيل المؤسسة وشعارها واسم المدير العام"
        >
          <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-200 p-0.5 flex items-center justify-center shrink-0 overflow-hidden group-hover:border-indigo-400 group-hover:scale-105 transition-all shadow-2xs">
            {settings.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="شعار المؤسسة"
                className="w-full h-full object-contain rounded-md"
              />
            ) : (
              <School className="w-4 h-4 text-indigo-600" />
            )}
          </div>
          <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
            <span className="text-slate-900 font-bold hidden sm:inline-block group-hover:text-indigo-600 transition-colors">
              {settings.centerName || 'منظومة إتقان'}
            </span>
            <span className="text-slate-400 hidden sm:inline-block">/</span>
          </div>
        </button>
        <h2 className="text-sm sm:text-base font-extrabold text-slate-900 tracking-tight">
          {sectionTitle}
        </h2>
      </div>

      {/* Zone 2: Middle - Global Quick Search */}
      <div className="hidden md:flex items-center gap-3">
        {onOpenSearch && (
          <button
            type="button"
            onClick={onOpenSearch}
            className="flex items-center gap-2.5 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200/70 text-slate-500 hover:text-slate-800 text-xs transition-colors border border-slate-200 cursor-pointer shadow-2xs group min-w-[240px]"
          >
            <Search className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-600 transition-colors" />
            <span className="flex-1 text-right">بحث سريع عن تلميذ أو وصل...</span>
            <kbd className="font-mono text-[10px] bg-white text-slate-400 px-1.5 py-0.5 rounded border border-slate-300">
              Ctrl+K
            </kbd>
          </button>
        )}

        <div className="flex items-center gap-2 text-xs text-slate-500 border-r border-slate-200 pr-3 font-mono">
          <Calendar className="w-3.5 h-3.5 text-indigo-500" />
          <span>{todayFormatted}</span>
        </div>
      </div>

      {/* Zone 3: Essential Action Buttons */}
      <div className="flex items-center gap-2">
        {onOpenCashClosure && (
          <button
            type="button"
            onClick={onOpenCashClosure}
            title="إغلاق وموازنة الصندوق اليومي"
            className="p-2 text-slate-600 hover:text-amber-700 hover:bg-amber-50 rounded-xl border border-slate-200 hover:border-amber-300 transition-colors cursor-pointer text-xs flex items-center gap-1 font-bold"
          >
            <Lock className="w-3.5 h-3.5 text-amber-600" />
            <span className="hidden lg:inline">إغلاق الصندوق</span>
          </button>
        )}

        <Button
          variant="secondary"
          size="sm"
          icon={<CreditCard className="w-3.5 h-3.5 text-emerald-600" />}
          onClick={onOpenPaymentModal}
          className="hover:border-emerald-300 font-bold"
        >
          <span>استخلاص واجب</span>
        </Button>

        <Button
          variant="primary"
          size="sm"
          icon={<UserPlus className="w-3.5 h-3.5 text-white" />}
          onClick={onOpenNewStudentModal}
          className="shadow-sm font-bold"
        >
          <span>تلميذ جديد +</span>
        </Button>
      </div>
    </header>
  );
};
