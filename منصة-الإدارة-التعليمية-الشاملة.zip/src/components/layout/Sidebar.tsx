import React from 'react';
import {
  LayoutDashboard,
  GraduationCap,
  Users,
  CreditCard,
  TrendingDown,
  CalendarCheck,
  BarChart3,
  Settings,
  ShieldCheck,
  Monitor,
  School,
  ChevronLeft,
  Sparkles,
  Cpu,
  Languages,
  Tablet,
  Briefcase,
  Layers,
} from 'lucide-react';
import { CenterSettings, LicenseInfo, User, StudentWithDetails } from '../../types';

export type NavSection =
  | 'dashboard'
  | 'branches'
  | 'students'
  | 'groups'
  | 'attendance'
  | 'devices'
  | 'teachers'
  | 'finance'
  | 'expenses'
  | 'reports'
  | 'settings';

interface SidebarProps {
  activeSection: NavSection;
  onSelectSection: (section: NavSection) => void;
  settings: CenterSettings;
  license: LicenseInfo;
  currentUser: User;
  onOpenTauriGuide: () => void;
  studentsCount?: number;
  debtorsCount?: number;
  subjectsCount?: number;
  devicesCount?: number;
  onOpenInstitutionProfile?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeSection,
  onSelectSection,
  settings,
  license,
  currentUser,
  onOpenTauriGuide,
  studentsCount = 0,
  debtorsCount = 0,
  subjectsCount = 0,
  devicesCount = 0,
  onOpenInstitutionProfile,
}) => {
  interface NavGroup {
    groupTitle: string;
    items: Array<{
      id: NavSection;
      label: string;
      icon: React.ReactNode;
      badge?: string | number;
      badgeColor?: string;
    }>;
  }

  const navGroups: NavGroup[] = [
    {
      groupTitle: 'العمل الأساسي',
      items: [
        {
          id: 'dashboard',
          label: 'الرئيسية (الخلاصة السريعة)',
          icon: <LayoutDashboard className="w-4 h-4 text-indigo-400" />,
        },
        {
          id: 'students',
          label: 'سجل التلاميذ (كل تلميذ ومادته)',
          icon: <GraduationCap className="w-4 h-4 text-emerald-400" />,
          badge: studentsCount > 0 ? studentsCount : undefined,
          badgeColor: 'bg-emerald-900/60 text-emerald-300 border-emerald-700/50',
        },
        {
          id: 'finance',
          label: 'الخلاص والوصولات',
          icon: <CreditCard className="w-4 h-4 text-emerald-400" />,
        },
        {
          id: 'reports',
          label: 'الديون (شكون مازال ما خلصش)',
          icon: <BarChart3 className="w-4 h-4 text-amber-400" />,
          badge: debtorsCount > 0 ? `${debtorsCount} ما خلصوش` : undefined,
          badgeColor: 'bg-amber-950/80 text-amber-300 border-amber-800/60',
        },
        {
          id: 'branches',
          label: 'المواد والأفواج (المادة ⬅️ الفوج ⬅️ التلاميذ)',
          icon: <Layers className="w-4 h-4 text-sky-400" />,
        },
        {
          id: 'settings',
          label: 'إعدادات المركز والنسخ',
          icon: <Settings className="w-4 h-4 text-slate-400" />,
        },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-slate-950 text-slate-300 flex flex-col h-screen shrink-0 border-l border-slate-800/90 select-none shadow-xl z-20">
      {/* Brand Header & Institution Profile Trigger */}
      <div
        onClick={onOpenInstitutionProfile}
        className="p-3.5 border-b border-slate-800/80 bg-linear-to-b from-slate-900 via-slate-900/95 to-slate-950 cursor-pointer hover:bg-slate-900 transition-all group relative select-none"
        title="اضغط هنا لتعديل بروفيل المؤسسة وشعارها واسم المدير العام"
      >
        <div className="flex items-center gap-3">
          {/* Institution Logo / Icon */}
          <div className="w-11 h-11 rounded-xl bg-slate-900 border-2 border-indigo-500/40 p-1 flex items-center justify-center shrink-0 shadow-lg shadow-indigo-950/80 group-hover:scale-105 group-hover:border-indigo-400 group-hover:shadow-indigo-500/20 transition-all overflow-hidden relative">
            {settings.logoUrl ? (
              <img
                src={settings.logoUrl}
                alt="شعار المؤسسة"
                className="w-full h-full object-contain rounded-lg"
              />
            ) : (
              <div className="w-full h-full rounded-lg bg-linear-to-br from-indigo-500 to-indigo-700 flex items-center justify-center text-white">
                <School className="w-5 h-5 text-white" />
              </div>
            )}
            <div className="absolute inset-0 bg-indigo-600/0 group-hover:bg-indigo-600/10 transition-colors rounded-lg" />
          </div>

          <div className="overflow-hidden flex-1">
            <div className="flex items-center justify-between gap-1">
              <h1 className="font-extrabold text-xs text-white truncate tracking-tight group-hover:text-indigo-300 transition-colors">
                {settings.centerName || 'منظومة إتقان'}
              </h1>
              <span className="opacity-0 group-hover:opacity-100 text-[10px] text-amber-400 font-bold transition-opacity shrink-0">
                ⚙️
              </span>
            </div>
            <p className="text-[10px] text-slate-400 truncate font-medium flex items-center gap-1 mt-0.5 group-hover:text-slate-300 transition-colors">
              <Sparkles className="w-2.5 h-2.5 text-amber-400 shrink-0" />
              <span className="truncate">
                {settings.directorName ? `إدارة: ${settings.directorName}` : 'نظام الإدارة المدرسية'}
              </span>
            </p>
          </div>
        </div>

        {/* Quick Click Hint Pill */}
        <div className="mt-2 pt-1.5 border-t border-slate-800/60 flex items-center justify-between text-[9px] text-slate-500 group-hover:text-indigo-300 transition-colors">
          <span className="flex items-center gap-1 font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>بروفيل وشعار المؤسسة</span>
          </span>
          <span className="font-bold underline decoration-indigo-400/50">تعديل البيانات</span>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-5 scrollbar-thin">
        {navGroups.map((group, gIdx) => (
          <div key={gIdx} className="space-y-1.5">
            <div className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500">
              {group.groupTitle}
            </div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const isActive = activeSection === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => onSelectSection(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer relative group ${
                      isActive
                        ? 'bg-linear-to-l from-indigo-600 to-indigo-700 text-white shadow-md shadow-indigo-950/40 font-bold'
                        : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/80'
                    }`}
                  >
                    {isActive && (
                      <div className="absolute right-0 top-1.5 bottom-1.5 w-1 bg-amber-400 rounded-l-full"></div>
                    )}
                    <div className="flex items-center gap-2.5">
                      <span
                        className={`p-1 rounded-lg transition-colors ${
                          isActive
                            ? 'text-white'
                            : 'text-slate-400 group-hover:text-indigo-400'
                        }`}
                      >
                        {item.icon}
                      </span>
                      <span>{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {item.badge !== undefined && (
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${item.badgeColor || 'bg-slate-800 text-slate-300'}`}
                        >
                          {item.badge}
                        </span>
                      )}
                      {isActive && <ChevronLeft className="w-3.5 h-3.5 text-white/80" />}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* Footer / User Profile & Status */}
      <div className="p-3 border-t border-slate-800/80 bg-slate-950 text-xs">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-xl bg-linear-to-tr from-indigo-700 to-indigo-500 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-xs border border-indigo-400/20">
              {currentUser.fullName.charAt(0)}
            </div>
            <div className="overflow-hidden leading-tight flex-1">
              <div className="font-bold text-slate-200 truncate text-[11px]">{currentUser.fullName}</div>
              <div className="text-[10px] text-emerald-400 truncate mt-0.5 flex items-center gap-1 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span>النظام يعمل محلياً</span>
              </div>
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenTauriGuide}
            className="p-1.5 text-slate-500 hover:text-indigo-300 rounded-lg hover:bg-slate-900 transition-colors cursor-pointer"
            title="تحميل برنامج الويندوز المكتبي (.exe)"
          >
            <Monitor className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
};
