import React from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { StudentWithDetails, GradeRecord, StudyGroup, CenterSettings } from '../../types';
import { Printer, X, Award, CheckCircle2 } from 'lucide-react';

interface PrintableGradeReportProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentWithDetails;
  grade: GradeRecord;
  group: StudyGroup;
  settings: CenterSettings;
}

export const PrintableGradeReport: React.FC<PrintableGradeReportProps> = ({
  isOpen,
  onClose,
  student,
  grade,
  group,
  settings,
}) => {
  const percentage = Math.round((grade.score / (grade.maxScore || 20)) * 100);
  const appreciation =
    percentage >= 85
      ? 'ممتاز جداً - تهانينا'
      : percentage >= 70
      ? 'جيد جداً - استمر في التقدم'
      : percentage >= 50
      ? 'مستحسن - في حاجة لتعزيز المكتسبات'
      : 'دون المتوسط - يوصى بمراجعة مكثفة';

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="كشف النقط والتقييم الأكاديمي الرسمي"
      subtitle="معاينة وطباعة بطاقة النقط لتسليمها لولي الأمر"
      maxWidth="md"
    >
      <div className="space-y-4" dir="rtl">
        {/* Printable Card Area */}
        <div id="printable-grade-bulletin" className="p-6 bg-white border-2 border-slate-800 rounded-2xl space-y-5 text-slate-900 shadow-sm print:border-none print:p-0">
          {/* Institution Header */}
          <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3.5">
              {settings.logoUrl && (
                <div className="w-14 h-14 rounded-xl border border-slate-300 p-1 flex items-center justify-center shrink-0 bg-white shadow-2xs">
                  <img
                    src={settings.logoUrl}
                    alt="شعار المؤسسة"
                    className="w-full h-full object-contain"
                  />
                </div>
              )}
              <div>
                <h1 className="text-lg font-black text-slate-900">{settings.centerName}</h1>
                <p className="text-[11px] text-slate-600">{settings.slogan}</p>
                <p className="text-[10px] text-slate-500 font-mono mt-0.5">{settings.phone} • {settings.address}</p>
              </div>
            </div>
            <div className="text-left font-mono text-xs">
              <span className="block font-bold text-slate-800">الموسم الدراسي</span>
              <span className="bg-slate-100 px-2 py-0.5 rounded border border-slate-300 font-bold text-[11px]">
                {settings.academicYear}
              </span>
            </div>
          </div>

          {/* Bulletin Title */}
          <div className="text-center py-1">
            <span className="inline-block px-4 py-1 rounded-full bg-slate-900 text-white font-extrabold text-sm tracking-wide shadow-xs">
              كشف النقط والتقييم الأكاديمي
            </span>
            <p className="text-xs font-bold text-slate-600 mt-1">{grade.evaluationTitle}</p>
          </div>

          {/* Student & Class Info Grid */}
          <div className="grid grid-cols-2 gap-3 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <div>
              <span className="text-slate-500 text-[10px] block">اسم التلميذ(ة):</span>
              <span className="font-extrabold text-sm text-slate-900">{student.fullName}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">رمز التلميذ:</span>
              <span className="font-mono font-bold text-indigo-700">{student.code}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">المستوى / الفوج:</span>
              <span className="font-bold text-slate-800">{group.name}</span>
            </div>
            <div>
              <span className="text-slate-500 text-[10px] block">تاريخ الإجراء:</span>
              <span className="font-mono text-slate-700">{grade.date}</span>
            </div>
          </div>

          {/* Result Highlight Box */}
          <div className="p-4 bg-linear-to-r from-indigo-50 to-emerald-50 rounded-xl border-2 border-indigo-200 text-center space-y-1">
            <span className="text-xs text-indigo-900 font-semibold block">النقطة المحصل عليها:</span>
            <div className="text-3xl font-black font-mono text-indigo-950">
              {grade.score} <span className="text-base text-slate-500 font-bold">/ {grade.maxScore || 20}</span>
            </div>
            <div className="text-xs font-bold text-emerald-800 flex items-center justify-center gap-1 mt-1">
              <Award className="w-3.5 h-3.5" />
              <span>التقدير العام: {appreciation} ({percentage}%)</span>
            </div>
          </div>

          {/* Teacher Remark */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
            <span className="font-bold text-slate-700 block">ملاحظات وتوجيهات الأستاذ(ة) المؤطر(ة):</span>
            <p className="text-slate-800 leading-relaxed italic">
              {grade.notes || 'مواظبة جيدة، نرجو مواصلة الاجتهاد والتفاعل الإيجابي مع الدروس.'}
            </p>
          </div>

          {/* Signatures */}
          <div className="grid grid-cols-2 gap-4 pt-4 text-center text-xs">
            <div className="space-y-8">
              <span className="font-bold text-slate-600 block">توقيع الأستاذ المؤطر</span>
              <div className="border-t border-slate-300 w-28 mx-auto" />
            </div>
            <div className="space-y-2 flex flex-col items-center">
              <span className="font-bold text-slate-700 block">ختم وتوقيع إدارة المركز</span>
              <div className="w-32 min-h-[50px] relative flex flex-col items-center justify-end pb-1 border-t border-slate-300">
                {settings.directorSignatureUrl ? (
                  <img
                    src={settings.directorSignatureUrl}
                    alt="ختم المؤسسة"
                    className="max-h-16 object-contain pointer-events-none opacity-85"
                  />
                ) : null}
                {settings.directorName && (
                  <span className="text-[10px] text-slate-600 font-bold block">{settings.directorName}</span>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق
          </Button>
          <Button
            variant="primary"
            size="sm"
            icon={<Printer className="w-4 h-4" />}
            onClick={() => window.print()}
          >
            طباعة كشف النقط الرسمي (A4)
          </Button>
        </div>
      </div>
    </Modal>
  );
};
