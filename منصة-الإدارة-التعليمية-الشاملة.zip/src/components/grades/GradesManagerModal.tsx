import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { StudyGroup, StudentWithDetails, GradeRecord, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import {
  GraduationCap,
  Save,
  Printer,
  Sparkles,
  BarChart2,
  CheckCircle2,
  Calendar,
  Layers,
  Award,
} from 'lucide-react';
import { PrintableGradeReport } from './PrintableGradeReport';

interface GradesManagerModalProps {
  isOpen: boolean;
  onClose: () => void;
  groups: StudyGroup[];
  students: StudentWithDetails[];
  settings: CenterSettings;
}

export const GradesManagerModal: React.FC<GradesManagerModalProps> = ({
  isOpen,
  onClose,
  groups,
  students,
  settings,
}) => {
  const [selectedGroupId, setSelectedGroupId] = useState<string>(groups[0]?.id || '');
  const [evaluationTitle, setEvaluationTitle] = useState('الفرض المحروس الأول');
  const [evaluationDate, setEvaluationDate] = useState(new Date().toISOString().substring(0, 10));
  const [maxScore, setMaxScore] = useState<number>(20);
  const [scores, setScores] = useState<Record<string, { score: number; notes: string }>>({});
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Print student bulletin
  const [studentToPrintBulletin, setStudentToPrintBulletin] = useState<{
    student: StudentWithDetails;
    grade: GradeRecord;
  } | null>(null);

  const selectedGroup = groups.find((g) => g.id === selectedGroupId) || groups[0];

  // Students belonging to selected group
  const groupStudents = students.filter((s) =>
    s.enrolledGroups.some((g) => g.id === selectedGroup?.id)
  );

  // Load existing grades when group or evaluation changes
  useEffect(() => {
    if (!selectedGroup) return;
    dataService.getGrades({ groupId: selectedGroup.id }).then((records) => {
      const currentEvalRecords = records.filter((r) => r.evaluationTitle === evaluationTitle);
      const scoreMap: Record<string, { score: number; notes: string }> = {};
      currentEvalRecords.forEach((r) => {
        scoreMap[r.studentId] = { score: r.score, notes: r.notes || '' };
      });
      setScores(scoreMap);
    });
  }, [selectedGroupId, evaluationTitle]);

  const handleScoreChange = (studentId: string, scoreVal: number) => {
    setScores((prev) => ({
      ...prev,
      [studentId]: {
        score: scoreVal,
        notes: prev[studentId]?.notes || '',
      },
    }));
  };

  const handleNotesChange = (studentId: string, notesVal: string) => {
    setScores((prev) => ({
      ...prev,
      [studentId]: {
        score: prev[studentId]?.score || 0,
        notes: notesVal,
      },
    }));
  };

  const handleSaveGrades = async () => {
    if (!selectedGroup) return;
    try {
      setIsSaving(true);
      const batchRecords: Array<Omit<GradeRecord, 'id'>> = Object.entries(scores)
        .filter(([_, data]) => data.score !== undefined && data.score !== null)
        .map(([studentId, data]) => ({
          studentId,
          groupId: selectedGroup.id,
          subjectId: selectedGroup.subjectId,
          evaluationTitle,
          date: evaluationDate,
          score: Number(data.score),
          maxScore: Number(maxScore),
          notes: data.notes,
        }));

      await dataService.saveGradesBatch(batchRecords);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  // Group Stats Calculation
  const scoresArray = Object.values(scores)
    .map((s) => s.score)
    .filter((s) => s > 0);
  const averageScore =
    scoresArray.length > 0
      ? (scoresArray.reduce((acc, curr) => acc + curr, 0) / scoresArray.length).toFixed(2)
      : '0.00';
  const highestScore = scoresArray.length > 0 ? Math.max(...scoresArray) : 0;
  const lowestScore = scoresArray.length > 0 ? Math.min(...scoresArray) : 0;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="دفتر النقط والتقييمات الدورية (كشوفات النقط)"
      subtitle="إدخال نقط الفروض والامتحانات، حساب المعدلات الفوجية، وطباعة كشف النقط الرسمي لولي الأمر"
      maxWidth="2xl"
    >
      <div className="space-y-4" dir="rtl">
        {/* Top Controls: Group & Evaluation Selection */}
        <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block font-bold text-slate-700 mb-1">الفوج الدراسي *</label>
            <select
              value={selectedGroupId}
              onChange={(e) => setSelectedGroupId(e.target.value)}
              className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-semibold text-slate-900"
            >
              {groups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">عنوان الفرض / التقييم *</label>
            <select
              value={evaluationTitle}
              onChange={(e) => setEvaluationTitle(e.target.value)}
              className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              <option value="الفرض المحروس الأول">الفرض المحروس الأول</option>
              <option value="الفرض المحروس الثاني">الفرض المحروس الثاني</option>
              <option value="الاختبار الشفوي والمحادثة">الاختبار الشفوي والمحادثة</option>
              <option value="الامتحان التجريبي">الامتحان التجريبي النهائي</option>
              <option value="تقييم نهاية الدورة">تقييم نهاية الدورة التدريبية</option>
            </select>
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">تاريخ إجراء الفرض</label>
            <input
              type="date"
              value={evaluationDate}
              onChange={(e) => setEvaluationDate(e.target.value)}
              className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
            />
          </div>

          <div>
            <label className="block font-bold text-slate-700 mb-1">النقطة القصوى (المعيار)</label>
            <input
              type="number"
              min="1"
              value={maxScore}
              onChange={(e) => setMaxScore(Number(e.target.value))}
              className="w-full p-2 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-bold"
            />
          </div>
        </div>

        {/* Quick Stats Bar */}
        <div className="grid grid-cols-4 gap-2 bg-indigo-50/60 p-2.5 rounded-xl border border-indigo-100 text-center text-xs">
          <div>
            <span className="text-slate-500 text-[10px] block">تلاميذ الفوج:</span>
            <span className="font-bold text-slate-900 font-mono text-sm">{groupStudents.length}</span>
          </div>
          <div className="border-r border-indigo-200">
            <span className="text-slate-500 text-[10px] block">معدل الفوج:</span>
            <span className="font-bold text-indigo-700 font-mono text-sm">{averageScore} / {maxScore}</span>
          </div>
          <div className="border-r border-indigo-200">
            <span className="text-slate-500 text-[10px] block">أعلى نقطة:</span>
            <span className="font-bold text-emerald-700 font-mono text-sm">{highestScore} / {maxScore}</span>
          </div>
          <div className="border-r border-indigo-200">
            <span className="text-slate-500 text-[10px] block">أدنى نقطة:</span>
            <span className="font-bold text-rose-700 font-mono text-sm">{lowestScore} / {maxScore}</span>
          </div>
        </div>

        {/* Success Alert */}
        {saveSuccess && (
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs font-bold text-emerald-800 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>تم حفظ وتحديث نقط وتقييمات الفوج بنجاح في قاعدة البيانات!</span>
          </div>
        )}

        {/* Students Grade Input Table */}
        <div className="border border-slate-200 rounded-xl overflow-hidden max-h-[340px] overflow-y-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-100/90 text-slate-700 font-bold sticky top-0 border-b border-slate-200 z-10">
              <tr>
                <th className="p-2.5">رمز التلميذ</th>
                <th className="p-2.5">اسم التلميذ الكامل</th>
                <th className="p-2.5 w-28 text-center">النقطة (من {maxScore})</th>
                <th className="p-2.5">ملاحظة الأستاذ(ة) التوجيهية</th>
                <th className="p-2.5 w-24 text-center">كشف النقط</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {groupStudents.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-6 text-center text-slate-400">
                    لا يوجد تلاميذ مسجلون في هذا الفوج حالياً.
                  </td>
                </tr>
              ) : (
                groupStudents.map((stu) => {
                  const studentGrade = scores[stu.id]?.score ?? '';
                  const studentNotes = scores[stu.id]?.notes ?? '';

                  return (
                    <tr key={stu.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-2.5 font-mono text-slate-600 font-semibold">{stu.code}</td>
                      <td className="p-2.5 font-bold text-slate-900">{stu.fullName}</td>
                      <td className="p-2.5 text-center">
                        <input
                          type="number"
                          step="0.25"
                          min="0"
                          max={maxScore}
                          value={studentGrade}
                          onChange={(e) => handleScoreChange(stu.id, parseFloat(e.target.value))}
                          placeholder={`/ ${maxScore}`}
                          className={`w-20 p-1.5 text-center font-mono font-bold rounded-lg border text-xs outline-none focus:ring-2 ${
                            typeof studentGrade === 'number' && studentGrade >= maxScore / 2
                              ? 'bg-emerald-50/70 border-emerald-300 text-emerald-900 focus:ring-emerald-500'
                              : typeof studentGrade === 'number'
                              ? 'bg-rose-50/70 border-rose-300 text-rose-900 focus:ring-rose-500'
                              : 'bg-white border-slate-300'
                          }`}
                        />
                      </td>
                      <td className="p-2.5">
                        <input
                          type="text"
                          value={studentNotes}
                          onChange={(e) => handleNotesChange(stu.id, e.target.value)}
                          placeholder="مثال: مستوى ممتاز، استيعاب جيد، يحتاج لمزيد من التركيز..."
                          className="w-full p-1.5 bg-slate-50 border border-slate-200 rounded-lg text-[11px] focus:bg-white focus:ring-1 focus:ring-indigo-500 outline-none"
                        />
                      </td>
                      <td className="p-2.5 text-center">
                        <button
                          type="button"
                          disabled={!scores[stu.id]?.score}
                          onClick={() =>
                            setStudentToPrintBulletin({
                              student: stu,
                              grade: {
                                id: 'grd-' + stu.id,
                                studentId: stu.id,
                                groupId: selectedGroup.id,
                                subjectId: selectedGroup.subjectId,
                                evaluationTitle,
                                date: evaluationDate,
                                score: scores[stu.id]?.score || 0,
                                maxScore,
                                notes: scores[stu.id]?.notes,
                              },
                            })
                          }
                          className="p-1 px-2 text-[11px] font-bold rounded-md bg-indigo-50 hover:bg-indigo-100 text-indigo-700 border border-indigo-200 transition-colors cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed inline-flex items-center gap-1"
                          title="طباعة كشف النقط الرسمي لولي الأمر"
                        >
                          <Printer className="w-3 h-3" />
                          <span>كشف</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-100">
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق
          </Button>

          <Button
            variant="primary"
            size="sm"
            icon={<Save className="w-4 h-4" />}
            onClick={handleSaveGrades}
            isLoading={isSaving}
            disabled={groupStudents.length === 0}
          >
            حفظ واعتماد النقط في السجل الأكاديمي
          </Button>
        </div>
      </div>

      {/* Printable Student Bulletin Modal */}
      {studentToPrintBulletin && (
        <PrintableGradeReport
          isOpen={Boolean(studentToPrintBulletin)}
          onClose={() => setStudentToPrintBulletin(null)}
          student={studentToPrintBulletin.student}
          grade={studentToPrintBulletin.grade}
          group={selectedGroup}
          settings={settings}
        />
      )}
    </Modal>
  );
};
