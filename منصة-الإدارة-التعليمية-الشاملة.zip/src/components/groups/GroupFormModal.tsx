import React, { useState, useEffect } from 'react';
import { StudyGroup, Level, Subject, GroupSchedule } from '../../types';
import { dataService } from '../../services/data-service';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Plus, Trash2, Check, Sparkles } from 'lucide-react';

interface GroupFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<StudyGroup, 'id'>) => Promise<void>;
  groupToEdit?: StudyGroup | null;
  levels: Level[];
  subjects: Subject[];
  initialSubjectId?: string;
}

const DAYS_OF_WEEK: GroupSchedule['day'][] = [
  'الاثنين',
  'الثلاثاء',
  'الأربعاء',
  'الخميس',
  'الجمعة',
  'السبت',
  'الأحد',
];

export const GroupFormModal: React.FC<GroupFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  groupToEdit,
  levels,
  subjects,
  initialSubjectId,
}) => {
  const [name, setName] = useState('');
  const [levelId, setLevelId] = useState('');
  const [subjectId, setSubjectId] = useState('');
  const [teacherName, setTeacherName] = useState('');
  const [maxCapacity, setMaxCapacity] = useState(20);
  const [monthlyFee, setMonthlyFee] = useState(400);
  const [registrationFee, setRegistrationFee] = useState(200);
  const [status, setStatus] = useState<StudyGroup['status']>('active');
  const [academicYear, setAcademicYear] = useState('2025/2026');
  const [notes, setNotes] = useState('');
  const [schedules, setSchedules] = useState<GroupSchedule[]>([
    { day: 'الثلاثاء', timeStart: '18:00', timeEnd: '20:00', classroom: 'قاعة 1' },
  ]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [localSubjects, setLocalSubjects] = useState<Subject[]>(subjects);
  const [isQuickAddingSubject, setIsQuickAddingSubject] = useState(false);
  const [newSubName, setNewSubName] = useState('');
  const [isCreatingSub, setIsCreatingSub] = useState(false);

  useEffect(() => {
    setLocalSubjects(subjects);
  }, [subjects]);

  const handleQuickAddSubject = async () => {
    if (!newSubName.trim()) return;
    try {
      setIsCreatingSub(true);
      const created = await dataService.addSubject({
        name: newSubName.trim(),
        levelId: levelId || levels[0]?.id || 'lvl-1',
        monthlyFeeDefault: Number(monthlyFee) || 400,
        registrationFeeDefault: Number(registrationFee) || 200,
        isActive: true,
      });
      setLocalSubjects((prev) => [...prev, created]);
      setSubjectId(created.id);
      if (!name || name.startsWith('فوج ')) {
        setName(`فوج ${created.name} الجديد`);
      }
      setNewSubName('');
      setIsQuickAddingSubject(false);
    } catch (e) {
      alert((e as Error).message || 'حدث خطأ أثناء إضافة المادة');
    } finally {
      setIsCreatingSub(false);
    }
  };

  useEffect(() => {
    if (groupToEdit) {
      setName(groupToEdit.name);
      setLevelId(groupToEdit.levelId);
      setSubjectId(groupToEdit.subjectId);
      setTeacherName(groupToEdit.teacherName);
      setMaxCapacity(groupToEdit.maxCapacity);
      setMonthlyFee(groupToEdit.monthlyFee);
      setRegistrationFee(groupToEdit.registrationFee);
      setStatus(groupToEdit.status);
      setAcademicYear(groupToEdit.academicYear);
      setNotes(groupToEdit.notes || '');
      setSchedules(groupToEdit.schedule || []);
    } else {
      const targetSubId = initialSubjectId || subjects[0]?.id || '';
      const matchedSubject = subjects.find((s) => s.id === targetSubId);

      setName(matchedSubject ? `فوج ${matchedSubject.name} الجديد` : '');
      setLevelId(matchedSubject?.levelId || levels[0]?.id || '');
      setSubjectId(targetSubId);
      setTeacherName(matchedSubject?.teacherDefault || '');
      setMaxCapacity(18);
      setMonthlyFee(matchedSubject?.monthlyFeeDefault ?? 400);
      setRegistrationFee(matchedSubject?.registrationFeeDefault ?? 200);
      setStatus('active');
      setAcademicYear('2025/2026');
      setNotes('');
      setSchedules([
        { day: 'الثلاثاء', timeStart: '18:00', timeEnd: '20:00', classroom: 'قاعة 1' },
      ]);
    }
    setError(null);
  }, [groupToEdit, isOpen, levels, subjects, initialSubjectId]);

  const addScheduleRow = () => {
    setSchedules((prev) => [
      ...prev,
      { day: 'السبت', timeStart: '16:00', timeEnd: '18:00', classroom: 'قاعة 1' },
    ]);
  };

  const removeScheduleRow = (idx: number) => {
    setSchedules((prev) => prev.filter((_, i) => i !== idx));
  };

  const updateSchedule = (idx: number, field: keyof GroupSchedule, value: string) => {
    setSchedules((prev) =>
      prev.map((item, i) => (i === idx ? { ...item, [field]: value } : item))
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim()) {
      setError('يرجى كتابة اسم المجموعة');
      return;
    }
    if (!teacherName.trim()) {
      setError('يرجى تحديد اسم الأستاذ المسؤول');
      return;
    }
    if (!levelId) {
      setError('يرجى تحديد المستوى الدراسي');
      return;
    }

    try {
      setIsSubmitting(true);
      await onSubmit({
        name: name.trim(),
        levelId,
        subjectId: subjectId || subjects[0]?.id || 'sub-1',
        teacherName: teacherName.trim(),
        maxCapacity: Number(maxCapacity),
        monthlyFee: Number(monthlyFee),
        registrationFee: Number(registrationFee),
        schedule: schedules,
        status,
        academicYear,
        notes: notes.trim() || undefined,
      });
      onClose();
    } catch (err) {
      setError((err as Error).message || 'حدث خطأ أثناء حفظ المجموعة');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={groupToEdit ? 'تعديل بيانات المجموعة الدراسية' : 'إنشاء فوج / مجموعة دراسية جديدة'}
      subtitle="تحديد الأستاذ، التوقيت، الطاقة الاستيعابية، والرسوم الشهرية"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {error && (
          <div className="p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium">
            {error}
          </div>
        )}

        {/* Basic Details */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              اسم المجموعة / الفوج <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: فوج النخبة - رياضيات 2 باك"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              الأستاذ(ة) المسؤول <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              value={teacherName}
              onChange={(e) => setTeacherName(e.target.value)}
              placeholder="مثال: ذ. عبد الرحيم"
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              المستوى الدراسي <span className="text-rose-500">*</span>
            </label>
            <select
              value={levelId}
              onChange={(e) => setLevelId(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              required
            >
              {levels.map((lvl) => (
                <option key={lvl.id} value={lvl.id}>
                  {lvl.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-xs font-semibold text-slate-700">المادة التعليمية / الفرع</label>
              <button
                type="button"
                onClick={() => setIsQuickAddingSubject(!isQuickAddingSubject)}
                className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer flex items-center gap-1"
              >
                <span>{isQuickAddingSubject ? 'إلغاء' : '+ مادة جديدة'}</span>
              </button>
            </div>

            {isQuickAddingSubject ? (
              <div className="flex items-center gap-1.5 p-1 bg-indigo-50/80 rounded-lg border border-indigo-200">
                <input
                  type="text"
                  value={newSubName}
                  onChange={(e) => setNewSubName(e.target.value)}
                  placeholder="اسم المادة (مثال: ألماني A1)"
                  className="flex-1 px-2.5 py-1 text-xs bg-white border border-indigo-300 rounded outline-none"
                  autoFocus
                />
                <button
                  type="button"
                  disabled={!newSubName.trim() || isCreatingSub}
                  onClick={handleQuickAddSubject}
                  className="px-2 py-1 bg-indigo-600 text-white rounded text-xs font-bold hover:bg-indigo-700 disabled:opacity-50 cursor-pointer"
                >
                  إضافة
                </button>
              </div>
            ) : (
              <select
                value={subjectId}
                onChange={(e) => setSubjectId(e.target.value)}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                {localSubjects.map((sub) => (
                  <option key={sub.id} value={sub.id}>
                    {sub.name}
                  </option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">الطاقة القصوى (تلميذ)</label>
            <input
              type="number"
              min="1"
              max="50"
              value={maxCapacity}
              onChange={(e) => setMaxCapacity(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              required
            />
          </div>
        </div>

        {/* Fees */}
        <div className="pt-2">
          <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2.5 pb-1 border-b border-slate-100">
            الرسوم والتعريفات المالية (MAD)
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                الواجب الشهري (درهم) <span className="text-rose-500">*</span>
              </label>
              <input
                type="number"
                min="0"
                value={monthlyFee}
                onChange={(e) => setMonthlyFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">رسوم التسجيل السنوي (درهم)</label>
              <input
                type="number"
                min="0"
                value={registrationFee}
                onChange={(e) => setRegistrationFee(Number(e.target.value))}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">حالة المجموعة</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value as StudyGroup['status'])}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none"
              >
                <option value="active">نشطة (مستمرة)</option>
                <option value="paused">متوقفة مؤقتاً</option>
              </select>
            </div>
          </div>
        </div>

        {/* Schedule */}
        <div className="pt-2">
          <div className="flex items-center justify-between mb-2 pb-1 border-b border-slate-100">
            <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
              أوقات الحصص والقاعات
            </h4>
            <button
              type="button"
              onClick={addScheduleRow}
              className="text-xs text-indigo-600 font-semibold flex items-center gap-1 hover:text-indigo-800"
            >
              <Plus className="w-3.5 h-3.5" />
              إضافة حصة
            </button>
          </div>

          <div className="space-y-2">
            {schedules.map((item, idx) => (
              <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2 rounded-lg border border-slate-200">
                <select
                  value={item.day}
                  onChange={(e) => updateSchedule(idx, 'day', e.target.value)}
                  className="px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-md focus:ring-1 focus:ring-indigo-500 outline-none"
                >
                  {DAYS_OF_WEEK.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>

                <div className="flex items-center gap-1 text-xs">
                  <span>من:</span>
                  <input
                    type="time"
                    value={item.timeStart}
                    onChange={(e) => updateSchedule(idx, 'timeStart', e.target.value)}
                    className="px-2 py-1 text-xs bg-white border border-slate-300 rounded-md font-mono"
                  />
                  <span>إلى:</span>
                  <input
                    type="time"
                    value={item.timeEnd}
                    onChange={(e) => updateSchedule(idx, 'timeEnd', e.target.value)}
                    className="px-2 py-1 text-xs bg-white border border-slate-300 rounded-md font-mono"
                  />
                </div>

                <input
                  type="text"
                  placeholder="القاعة (مثال: قاعة 1)"
                  value={item.classroom || ''}
                  onChange={(e) => updateSchedule(idx, 'classroom', e.target.value)}
                  className="px-2 py-1.5 text-xs bg-white border border-slate-300 rounded-md flex-1"
                />

                {schedules.length > 1 && (
                  <button
                    type="button"
                    onClick={() => removeScheduleRow(idx)}
                    className="text-slate-400 hover:text-rose-600 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Modal Actions */}
        <div className="flex items-center justify-end gap-2 pt-4 border-t border-slate-100">
          <Button type="button" variant="outline" size="sm" onClick={onClose} disabled={isSubmitting}>
            إلغاء
          </Button>
          <Button type="submit" variant="primary" size="sm" isLoading={isSubmitting}>
            {groupToEdit ? 'حفظ التعديلات' : 'تأكيد إنشاء المجموعة'}
          </Button>
        </div>
      </form>
    </Modal>
  );
};
