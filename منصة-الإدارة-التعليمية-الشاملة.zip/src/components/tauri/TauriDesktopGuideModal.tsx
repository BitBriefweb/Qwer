import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Copy, Check, Terminal, FolderCheck, ShieldAlert, Monitor } from 'lucide-react';
import { getTauriEnvironmentInfo } from '../../services/tauri-bridge';

interface TauriDesktopGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const TauriDesktopGuideModal: React.FC<TauriDesktopGuideModalProps> = ({
  isOpen,
  onClose,
}) => {
  const envInfo = getTauriEnvironmentInfo();
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2500);
  };

  const tauriConfJson = `{
  "$schema": "https://schema.tauri.app/config/2",
  "productName": "ItqanSchoolOS",
  "version": "1.0.0",
  "identifier": "com.itqan.schoolmanager",
  "build": {
    "frontendDist": "../dist",
    "devUrl": "http://localhost:3000"
  },
  "app": {
    "windows": [
      {
        "title": "منظومة إتقان لإدارة المدارس والتقوية",
        "width": 1366,
        "height": 768,
        "minWidth": 1024,
        "minHeight": 640,
        "resizable": true,
        "fullscreen": false,
        "decorations": true
      }
    ],
    "security": {
      "csp": null
    }
  },
  "plugins": {
    "sql": {
      "preload": ["sqlite:itqan_database.sqlite"]
    }
  }
}`;

  const buildCommands = `# 1. إضافة Tauri إلى المشروع
npm install --save-dev @tauri-apps/cli @tauri-apps/api
npm install @tauri-apps/plugin-sql

# 2. إنشاء نسخة الإنتاج لسطح المكتب (Windows .exe Installer)
npm run build
npx tauri build --target x86_64-pc-windows-msvc

# الناتج: ملف التثبيت المستقل في المجلد:
# src-tauri/target/release/bundle/nsis/ItqanSchoolOS_1.0.0_x64-setup.exe`;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="دليل بناء وتثبيت النسخة المكتبية المستقلة (Windows Desktop - Tauri + SQLite)"
      subtitle="كيفية توزيع البرنامج على أجهزة المدارس برخصة تجارية دائمة دون متصفح ودون إنترنت"
      maxWidth="4xl"
    >
      <div className="space-y-6 text-sm text-slate-700">
        {/* Status card */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
              <Monitor className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-bold text-slate-900 text-sm">
                معمارية التطبيق المكتبي المستقل (Tauri 2.0 + SQLite)
              </h4>
              <p className="text-xs text-slate-500 mt-0.5">
                حالة البيئة الحالية: {envInfo.isDesktopRuntime ? 'تطبيق Windows مكتبي' : 'بيئة المعاينة والتطوير (تخزين محلي دائم متوافق)'}
              </p>
            </div>
          </div>
          <div className="text-left font-mono text-xs text-slate-500">
            <div>المسار المستهدف:</div>
            <code className="text-slate-800 font-bold">{envInfo.databasePath}</code>
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-4">
          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2 mb-2">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-mono font-bold">1</span>
              كيف تم فصل الواجهة عن طبقة البيانات لضمان العمل المستقل؟
            </h4>
            <p className="text-xs text-slate-600 leading-relaxed">
              تم بناء التطبيق باستخدام نمط <code>StorageAdapter</code> المجرد ومخطط SQLite الكامل الموثق في ملف <code>src/database/sqlite-schema.sql</code>.
              في بيئة الويب والمتصفح، يعمل المحوّل التلقائي على حفظ كافة الجداول والعلاقات داخل التخزين المحلي، وحين يتم تشغيل التطبيق في بيئة Tauri،
              يقوم نفس الكود باستدعاء محرك SQLite3 مباشرة دون الحاجة لأي تعديل في واجهات المستخدم!
            </p>
          </div>

          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-mono font-bold">2</span>
                أوامر البناء وإنشاء ملف التثبيت (Windows .exe Installer)
              </h4>
              <button
                type="button"
                onClick={() => copyToClipboard(buildCommands, 'build')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'build' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'build' ? 'تم النسخ' : 'نسخ الأوامر'}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-slate-200 rounded-lg text-xs font-mono overflow-x-auto whitespace-pre leading-relaxed text-left" dir="ltr">
              {buildCommands}
            </pre>
          </div>

          <div className="border border-slate-200 rounded-xl p-4 bg-white">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-mono font-bold">3</span>
                ملف إعدادات Tauri (tauri.conf.json)
              </h4>
              <button
                type="button"
                onClick={() => copyToClipboard(tauriConfJson, 'conf')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1 cursor-pointer"
              >
                {copiedKey === 'conf' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedKey === 'conf' ? 'تم النسخ' : 'نسخ الإعدادات'}
              </button>
            </div>
            <pre className="p-3 bg-slate-900 text-emerald-300 rounded-lg text-xs font-mono overflow-x-auto max-h-48 whitespace-pre leading-relaxed text-left" dir="ltr">
              {tauriConfJson}
            </pre>
          </div>
        </div>

        <div className="flex justify-end pt-4 border-t border-slate-100">
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق النافذة
          </Button>
        </div>
      </div>
    </Modal>
  );
};
