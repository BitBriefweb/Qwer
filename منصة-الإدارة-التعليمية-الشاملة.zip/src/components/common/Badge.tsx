import React from 'react';

export type BadgeVariant =
  | 'success'
  | 'warning'
  | 'danger'
  | 'neutral'
  | 'indigo'
  | 'sky';

interface BadgeProps {
  children: React.ReactNode;
  variant?: BadgeVariant;
  size?: 'sm' | 'md';
  dot?: boolean;
}

export const Badge: React.FC<BadgeProps> = ({
  children,
  variant = 'neutral',
  size = 'md',
  dot = false,
}) => {
  const variantStyles: Record<BadgeVariant, { bg: string; text: string; dotColor: string }> = {
    success: {
      bg: 'bg-emerald-50 text-emerald-800 border-emerald-200/60',
      text: 'text-emerald-800',
      dotColor: 'bg-emerald-600',
    },
    warning: {
      bg: 'bg-amber-50 text-amber-800 border-amber-200/60',
      text: 'text-amber-800',
      dotColor: 'bg-amber-600',
    },
    danger: {
      bg: 'bg-rose-50 text-rose-800 border-rose-200/60',
      text: 'text-rose-800',
      dotColor: 'bg-rose-600',
    },
    neutral: {
      bg: 'bg-slate-100 text-slate-700 border-slate-200/60',
      text: 'text-slate-700',
      dotColor: 'bg-slate-500',
    },
    indigo: {
      bg: 'bg-indigo-50 text-indigo-800 border-indigo-200/60',
      text: 'text-indigo-800',
      dotColor: 'bg-indigo-600',
    },
    sky: {
      bg: 'bg-sky-50 text-sky-800 border-sky-200/60',
      text: 'text-sky-800',
      dotColor: 'bg-sky-600',
    },
  };

  const style = variantStyles[variant];
  const sizeClass = size === 'sm' ? 'text-xs px-2 py-0.5' : 'text-xs px-2.5 py-1';

  return (
    <span
      className={`inline-flex items-center gap-1.5 font-medium rounded-md border ${style.bg} ${sizeClass}`}
    >
      {dot && <span className={`w-1.5 h-1.5 rounded-full ${style.dotColor}`} />}
      <span>{children}</span>
    </span>
  );
};
