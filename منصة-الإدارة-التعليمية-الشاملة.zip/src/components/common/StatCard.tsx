import React from 'react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: React.ReactNode;
  variant?: 'default' | 'success' | 'warning' | 'danger' | 'indigo' | 'gold';
  trendText?: string;
  progressPercent?: number;
  actionText?: string;
  onAction?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon,
  variant = 'default',
  trendText,
  progressPercent,
  actionText,
  onAction,
}) => {
  const variantStyles = {
    default: {
      bg: 'bg-white',
      border: 'border-slate-200/90 hover:border-slate-300',
      iconBg: 'bg-slate-100 text-slate-700',
      accent: 'from-slate-400 to-slate-600',
      badge: 'bg-slate-100 text-slate-700',
      progress: 'bg-slate-700',
    },
    indigo: {
      bg: 'bg-gradient-to-bl from-white via-white to-indigo-50/40',
      border: 'border-slate-200/90 hover:border-indigo-300',
      iconBg: 'bg-indigo-600 text-white shadow-xs shadow-indigo-200',
      accent: 'from-indigo-500 to-indigo-700',
      badge: 'bg-indigo-50 text-indigo-700 border-indigo-100',
      progress: 'bg-indigo-600',
    },
    success: {
      bg: 'bg-gradient-to-bl from-white via-white to-emerald-50/40',
      border: 'border-slate-200/90 hover:border-emerald-300',
      iconBg: 'bg-emerald-600 text-white shadow-xs shadow-emerald-200',
      accent: 'from-emerald-500 to-emerald-700',
      badge: 'bg-emerald-50 text-emerald-800 border-emerald-100',
      progress: 'bg-emerald-600',
    },
    warning: {
      bg: 'bg-gradient-to-bl from-white via-white to-amber-50/40',
      border: 'border-slate-200/90 hover:border-amber-300',
      iconBg: 'bg-amber-600 text-white shadow-xs shadow-amber-200',
      accent: 'from-amber-400 to-amber-600',
      badge: 'bg-amber-50 text-amber-800 border-amber-100',
      progress: 'bg-amber-600',
    },
    danger: {
      bg: 'bg-gradient-to-bl from-white via-white to-rose-50/40',
      border: 'border-rose-200 hover:border-rose-300',
      iconBg: 'bg-rose-600 text-white shadow-xs shadow-rose-200',
      accent: 'from-rose-500 to-rose-700',
      badge: 'bg-rose-50 text-rose-700 border-rose-100',
      progress: 'bg-rose-600',
    },
    gold: {
      bg: 'bg-gradient-to-bl from-white via-white to-amber-50/30',
      border: 'border-amber-200/80 hover:border-amber-300',
      iconBg: 'bg-linear-to-tr from-amber-600 to-amber-500 text-white shadow-xs shadow-amber-200',
      accent: 'from-amber-400 to-amber-600',
      badge: 'bg-amber-100/70 text-amber-900 border-amber-200',
      progress: 'bg-amber-500',
    },
  };

  const style = variantStyles[variant];

  return (
    <div
      className={`${style.bg} p-5 rounded-2xl border ${style.border} shadow-2xs hover:shadow-md transition-all duration-200 flex flex-col justify-between relative overflow-hidden group`}
    >
      {/* Top subtle highlight line */}
      <div className={`absolute top-0 right-0 left-0 h-1 bg-gradient-to-l ${style.accent} opacity-80`}></div>

      <div>
        <div className="flex items-start justify-between gap-3 mb-2">
          <p className="text-xs font-bold text-slate-500 tracking-normal">{title}</p>
          <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${style.iconBg} transition-transform group-hover:scale-105 duration-200`}>
            {icon}
          </div>
        </div>

        <div className="mt-1">
          <div className="text-2xl lg:text-[26px] font-black text-slate-900 font-mono tracking-tight tabular-nums leading-none">
            {value}
          </div>
        </div>

        {typeof progressPercent === 'number' && (
          <div className="mt-3 space-y-1">
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
              <div
                className={`h-full rounded-full transition-all duration-500 ${style.progress}`}
                style={{ width: `${Math.min(100, Math.max(0, progressPercent))}%` }}
              ></div>
            </div>
          </div>
        )}
      </div>

      {(subtitle || trendText || actionText) && (
        <div className="mt-4 pt-3 border-t border-slate-100/90 flex items-center justify-between text-xs text-slate-500">
          {subtitle && <span className="text-[11px] text-slate-500 truncate">{subtitle}</span>}
          {trendText && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${style.badge} shrink-0`}>
              {trendText}
            </span>
          )}
          {actionText && (
            <button
              type="button"
              onClick={onAction}
              className="text-[11px] font-bold text-indigo-600 hover:text-indigo-800 hover:underline cursor-pointer"
            >
              {actionText}
            </button>
          )}
        </div>
      )}
    </div>
  );
};
