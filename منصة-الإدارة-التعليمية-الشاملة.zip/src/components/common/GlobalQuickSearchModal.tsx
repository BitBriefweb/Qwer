import React, { useState, useEffect, useRef } from 'react';
import { StudentWithDetails, Payment, StudyGroup, CenterSettings } from '../../types';
import { Modal } from './Modal';
import { Search, User, Receipt, Users, ArrowRight, Printer, CreditCard, X } from 'lucide-react';

interface GlobalQuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: StudentWithDetails[];
  payments: Payment[];
  groups: StudyGroup[];
  settings: CenterSettings;
  onSelectStudent: (student: StudentWithDetails) => void;
  onOpenPaymentModal: (student: StudentWithDetails) => void;
  onPrintPayment: (payment: Payment) => void;
  onNavigateSection: (section: any) => void;
}

export const GlobalQuickSearchModal: React.FC<GlobalQuickSearchModalProps> = ({
  isOpen,
  onClose,
  students,
  payments,
  groups,
  settings,
  onSelectStudent,
  onOpenPaymentModal,
  onPrintPayment,
  onNavigateSection,
}) => {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
    } else {
      setQuery('');
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const cleanQuery = query.trim().toLowerCase();

  const matchedStudents = cleanQuery
    ? students
        .filter(
          (s) =>
            s.fullName.toLowerCase().includes(cleanQuery) ||
            s.code.toLowerCase().includes(cleanQuery) ||
            s.guardianPhone.includes(cleanQuery) ||
            s.guardianName.toLowerCase().includes(cleanQuery)
        )
        .slice(0, 5)
    : [];

  const matchedPayments = cleanQuery
    ? payments
        .filter(
          (p) =>
            p.receiptNumber.toLowerCase().includes(cleanQuery) ||
            p.itemsCovered.toLowerCase().includes(cleanQuery) ||
            String(p.amountPaid).includes(cleanQuery)
        )
        .slice(0, 5)
    : [];

  const matchedGroups = cleanQuery
    ? groups
        .filter(
          (g) =>
            g.name.toLowerCase().includes(cleanQuery) ||
            g.teacherName.toLowerCase().includes(cleanQuery)
        )
        .slice(0, 3)
    : [];

  const totalResults =
    matchedStudents.length + matchedPayments.length + matchedGroups.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-20 p-4 bg-slate-900/60 backdrop-blur-xs animate-fade-in">
      <div className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 flex items-center gap-3 bg-slate-50/50">
          <Search className="w-5 h-5 text-indigo-600 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث بالاسم، رقم التلميذ (STU-...)، رقم الوصل (REC-...)، الهاتف، أو الفوج..."
            className="w-full bg-transparent text-sm font-semibold text-slate-900 outline-none placeholder:text-slate-400"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="text-xs bg-slate-200 hover:bg-slate-300 text-slate-700 px-2 py-1 rounded font-bold"
          >
            Esc
          </button>
        </div>

        {/* Results Body */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {!query ? (
            <div className="py-12 text-center text-xs text-slate-400 space-y-2">
              <Search className="w-8 h-8 mx-auto text-slate-300" />
              <p className="font-semibold text-slate-600">اكتب للبحث الفوري في قاعدة البيانات المحلية</p>
              <p className="text-[11px]">
                يمكنك كتابة اسم تلميذ، رقم هاتفه، رقم وصل مالي، أو اسم أستاذ.
              </p>
            </div>
          ) : totalResults === 0 ? (
            <div className="py-10 text-center text-xs text-slate-500">
              لم يتم العثور على أي نتائج تطابق: <strong className="text-slate-800">"{query}"</strong>
            </div>
          ) : (
            <div className="space-y-4">
              {/* Students Results */}
              {matchedStudents.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <User className="w-3.5 h-3.5 text-indigo-600" />
                    <span>التلاميذ المطابقون ({matchedStudents.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedStudents.map((s) => (
                      <div
                        key={s.id}
                        className="p-3 rounded-xl border border-slate-200/80 hover:border-indigo-300 hover:bg-indigo-50/40 transition-colors flex items-center justify-between gap-3 group"
                      >
                        <div className="space-y-0.5">
                          <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                            <span>{s.fullName}</span>
                            <span className="font-mono text-[10px] bg-slate-100 px-1.5 py-0.2 rounded text-slate-600">
                              {s.code}
                            </span>
                          </div>
                          <div className="text-[11px] text-slate-500">
                            ولي الأمر: {s.guardianName} ({s.guardianPhone})
                          </div>
                        </div>

                        <div className="flex items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onOpenPaymentModal(s);
                            }}
                            className="text-xs px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-700 rounded-lg font-bold border border-emerald-200 flex items-center gap-1 cursor-pointer"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>أداء</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => {
                              onClose();
                              onSelectStudent(s);
                            }}
                            className="text-xs px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-700 rounded-lg font-bold border border-slate-300 cursor-pointer"
                          >
                            عرض الملف
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Payments Results */}
              {matchedPayments.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                    <span>الوصولات المالية المطابقة ({matchedPayments.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedPayments.map((p) => {
                      const stu = students.find((s) => s.id === p.studentId);
                      return (
                        <div
                          key={p.id}
                          className="p-3 rounded-xl border border-slate-200/80 hover:border-emerald-300 hover:bg-emerald-50/30 transition-colors flex items-center justify-between gap-3"
                        >
                          <div className="space-y-0.5">
                            <div className="font-bold text-xs text-slate-900 flex items-center gap-2">
                              <span className="font-mono bg-slate-100 px-1.5 py-0.2 rounded text-slate-800">
                                {p.receiptNumber}
                              </span>
                              <span>{stu?.fullName || p.studentId}</span>
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {p.itemsCovered} · {p.paymentDate}
                            </div>
                          </div>

                          <div className="flex items-center gap-3 shrink-0">
                            <span className="font-mono font-bold text-emerald-700 text-xs">
                              {p.amountPaid.toFixed(2)} {settings.currency}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onClose();
                                onPrintPayment(p);
                              }}
                              className="p-1.5 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 text-slate-600 cursor-pointer"
                              title="طباعة الوصل"
                            >
                              <Printer className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Groups Results */}
              {matchedGroups.length > 0 && (
                <div className="space-y-2">
                  <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                    <Users className="w-3.5 h-3.5 text-blue-600" />
                    <span>الأفواج الدراسية ({matchedGroups.length})</span>
                  </div>
                  <div className="space-y-1">
                    {matchedGroups.map((g) => (
                      <div
                        key={g.id}
                        className="p-3 rounded-xl border border-slate-200/80 hover:border-blue-300 hover:bg-blue-50/30 transition-colors flex items-center justify-between gap-3"
                      >
                        <div>
                          <div className="font-bold text-xs text-slate-900">{g.name}</div>
                          <div className="text-[11px] text-slate-500">
                            الأستاذ: {g.teacherName} · الواجب: {g.monthlyFee} {settings.currency}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            onClose();
                            onNavigateSection('groups');
                          }}
                          className="text-xs px-2.5 py-1 bg-white hover:bg-slate-100 rounded-lg border border-slate-300 text-slate-700 font-bold cursor-pointer"
                        >
                          عرض الفوج
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer shortcuts */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-500">
          <span>انقر على النتيجة للوصول المباشر أو الأداء</span>
          <div className="flex items-center gap-2 font-mono text-[10px]">
            <span>للإغلاق اضغط [Esc]</span>
          </div>
        </div>
      </div>
    </div>
  );
};
