import React, { useState, useEffect } from 'react';
import { CenterSettings, LicenseInfo, User } from '../../types';
import { storageAdapter } from '../../database/storage-adapter';
import { dataService } from '../../services/data-service';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Modal } from '../common/Modal';
import {
  Download,
  Upload,
  RefreshCw,
  ShieldCheck,
  Building,
  Key,
  Users,
  Database,
  CheckCircle,
  AlertCircle,
  Copy,
  Check,
  Lock,
  KeyRound,
  Sparkles,
  Terminal,
  EyeOff,
  CheckCheck,
  School,
} from 'lucide-react';
import {
  generateLicenseKeyForCenter,
  DEVELOPER_MASTER_PIN,
} from '../../services/license-security';

interface SettingsManagerProps {
  settings: CenterSettings;
  license: LicenseInfo;
  users: User[];
  currentUser: User;
  onUpdateSettings: (newSettings: Partial<CenterSettings>) => Promise<void>;
  onRefreshData: () => Promise<void>;
  onUserSwitched: (user: User) => void;
  onOpenInstitutionProfile?: () => void;
}

export const SettingsManager: React.FC<SettingsManagerProps> = ({
  settings,
  license,
  users,
  currentUser,
  onUpdateSettings,
  onRefreshData,
  onUserSwitched,
  onOpenInstitutionProfile,
}) => {
  const [activeTab, setActiveTab] = useState<'center' | 'backup' | 'license' | 'users'>('center');

  // Center form state
  const [formData, setFormData] = useState<CenterSettings>(settings);
  const [isSavingSettings, setIsSavingSettings] = useState(false);
  const [settingsSuccess, setSettingsSuccess] = useState(false);

  // Backup & Restore state
  const [backupMsg, setBackupMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(
    null
  );
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);

  // License state
  const [licenseKeyInput, setLicenseKeyInput] = useState('');
  const [licenseCenterInput, setLicenseCenterInput] = useState(license.centerName || settings.centerName);
  const [licenseMsg, setLicenseMsg] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [copiedMachineId, setCopiedMachineId] = useState(false);
  const [showActivationForm, setShowActivationForm] = useState(!license.isValid);

  // Exclusive Hidden System Console state (لوحة الإشراف الفني المخفية للمطور فقط)
  const [isSystemConsoleOpen, setIsSystemConsoleOpen] = useState(false);
  const [consolePin, setConsolePin] = useState('');
  const [isConsoleUnlocked, setIsConsoleUnlocked] = useState(false);
  const [consolePinError, setConsolePinError] = useState(false);
  const [consoleTab, setConsoleTab] = useState<'rollover' | 'keygen' | 'reset'>('rollover');
  const [versionClicks, setVersionClicks] = useState(0);

  // Key generator state inside the hidden console
  const [devCenterName, setDevCenterName] = useState('');
  const [devMachineId, setDevMachineId] = useState('');
  const [generatedKey, setGeneratedKey] = useState('');
  const [copiedGeneratedKey, setCopiedGeneratedKey] = useState(false);

  // Annual Rollover state inside the hidden console
  const [nextYearInput, setNextYearInput] = useState('2026/2027');
  const [isProcessingRollover, setIsProcessingRollover] = useState(false);

  const handleUnlockConsole = (e: React.FormEvent) => {
    e.preventDefault();
    if (consolePin.trim() === DEVELOPER_MASTER_PIN) {
      setIsConsoleUnlocked(true);
      setConsolePinError(false);
      setDevCenterName(license.centerName || settings.centerName);
      setDevMachineId(license.machineFingerprint);
    } else {
      setConsolePinError(true);
    }
  };

  const handleAnnualRollover = async () => {
    if (
      !window.confirm(
        `تنبيه المشرف الفني: هل تريد أرشفة بيانات موسم (${settings.academicYear}) في ملف فلاشة، وتصفير المنظومة لبدء الموسم الجديد (${nextYearInput})؟`
      )
    ) {
      return;
    }

    try {
      setIsProcessingRollover(true);
      // 1. Export the archive file first so it downloads automatically to USB
      const db = await storageAdapter.getDatabase();
      const exportBlob = new Blob([JSON.stringify(db, null, 2)], {
        type: 'application/json',
      });
      const url = URL.createObjectURL(exportBlob);
      const link = document.createElement('a');
      const cleanCenter = (settings.centerName || 'المركز').replace(/\s+/g, '_');
      const cleanYear = (settings.academicYear || 'الموسم').replace(/[\/\\]/g, '-');
      link.href = url;
      link.download = `ارشيف_موسم_${cleanYear}_${cleanCenter}_محفوظ_فلاشة.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      // 2. Clear transactional data
      await storageAdapter.clearTransactionalData();

      // 3. Update academic year and reset receipt number
      await onUpdateSettings({
        academicYear: nextYearInput,
        receiptNextNumber: 1,
      });

      await onRefreshData();

      setBackupMsg({
        type: 'success',
        text: `تمت أرشفة العام السابق بنجاح في ملف فلاشة، وتم إطلاق الموسم الدراسي الجديد (${nextYearInput}) بنجاح تام!`,
      });
      setIsSystemConsoleOpen(false);
    } catch (err) {
      setBackupMsg({ type: 'error', text: (err as Error).message });
    } finally {
      setIsProcessingRollover(false);
    }
  };

  const handleGenerateLicenseKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!devCenterName || !devMachineId) return;
    const key = await generateLicenseKeyForCenter(devCenterName, devMachineId, 'lifetime');
    setGeneratedKey(key);
  };

  const handleCopyGeneratedKey = () => {
    navigator.clipboard.writeText(generatedKey);
    setCopiedGeneratedKey(true);
    setTimeout(() => setCopiedGeneratedKey(false), 2500);
  };

  const handleCopyMachineId = () => {
    navigator.clipboard.writeText(license.machineFingerprint);
    setCopiedMachineId(true);
    setTimeout(() => setCopiedMachineId(false), 2500);
  };

  // Handle center info save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);
    try {
      await onUpdateSettings(formData);
      setSettingsSuccess(true);
      setTimeout(() => setSettingsSuccess(false), 3000);
    } catch (e) {
      alert((e as Error).message);
    } finally {
      setIsSavingSettings(false);
    }
  };

  // Handle Backup Export
  const handleExportBackup = async () => {
    try {
      setIsExporting(true);
      const backup = await storageAdapter.exportBackup();
      const blob = new Blob([backup.jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = backup.filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setBackupMsg({
        type: 'success',
        text: `تم تصدير النسخة الاحتياطية بنجاح (${backup.filename}) برمز التحقق: ${backup.checksum}`,
      });
    } catch (e) {
      setBackupMsg({
        type: 'error',
        text: `فشل إنشاء النسخة الاحتياطية: ${(e as Error).message}`,
      });
    } finally {
      setIsExporting(false);
    }
  };

  // Handle Backup Import
  const handleImportFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!window.confirm('تنبيه هام: استعادة النسخة الاحتياطية ستقوم باستبدال البيانات الحالية بالنسخة المحددة. سيقوم النظام بحفظ نسخة أمان تلقائية للرجوع إليها إن أردت. هل ترغب بالاستمرار؟')) {
      e.target.value = '';
      return;
    }

    try {
      setIsRestoring(true);
      const text = await file.text();
      const res = await storageAdapter.importBackup(text);
      if (res.success) {
        setBackupMsg({ type: 'success', text: res.message });
        await onRefreshData();
      } else {
        setBackupMsg({ type: 'error', text: res.message });
      }
    } catch (err) {
      setBackupMsg({
        type: 'error',
        text: `حدث خطأ أثناء قراءة الملف: ${(err as Error).message}`,
      });
    } finally {
      setIsRestoring(false);
      e.target.value = '';
    }
  };

  // Reset to default starter data
  const handleResetData = async () => {
    if (
      !window.confirm(
        'هل أنت متأكد من إعادة تعيين قاعدة البيانات إلى بيانات البداية النموذجية؟ سيتم مسح التعديلات غير المحفوظة في ملف خارجي.'
      )
    ) {
      return;
    }
    await storageAdapter.resetToInitial();
    await onRefreshData();
    alert('تمت إعادة ضبط قاعدة البيانات إلى الحالة النموذجية.');
  };

  // Clear all dummy/transactional data to start 100% clean
  const handleClearTransactionalData = async () => {
    if (
      !window.confirm(
        'تنبيه هام: هل أنت متأكد من تفريغ وتصفير جميع بيانات التلاميذ والمصاريف والوصولات للبدء من الصفر؟ ستبقى إعدادات المؤسسة والفروع واللغات كما هي.'
      )
    ) {
      return;
    }

    try {
      await storageAdapter.clearTransactionalData();
      await onRefreshData();
      setBackupMsg({
        type: 'success',
        text: 'تم تفريغ وتصفير جميع بيانات التلاميذ والمصاريف والوصولات بنجاح. النظام جاهز الآن للبدء من الصفر بإدخال بياناتك الحقيقية.',
      });
    } catch (err) {
      setBackupMsg({ type: 'error', text: (err as Error).message });
    }
  };

  // License Activation
  const handleActivateLicense = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await dataService.activateLicense(licenseKeyInput, licenseCenterInput);
      await onRefreshData();
      setLicenseMsg({
        type: 'success',
        text: 'تم التحقق من كود التفعيل المشفر بنجاح! تم تثبيت وقفل الرخصة التجارية الدائمة لهذا الجهاز مدى الحياة.',
      });
      setLicenseKeyInput('');
      setShowActivationForm(false);
      setTimeout(() => setLicenseMsg(null), 5000);
    } catch (e) {
      setLicenseMsg({
        type: 'error',
        text: (e as Error).message || 'فشل تفعيل الترخيص.',
      });
    }
  };

  return (
    <div className="space-y-6">
      {/* Settings Navigation Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-slate-200 pb-3">
        <button
          type="button"
          onClick={() => setActiveTab('center')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'center'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Building className="w-4 h-4" />
          بيانات وهوية المؤسسة
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('backup')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'backup'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Database className="w-4 h-4" />
          النسخ الاحتياطي والاستعادة
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('license')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'license'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Key className="w-4 h-4" />
          الترخيص التجاري
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('users')}
          className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeTab === 'users'
              ? 'bg-indigo-600 text-white shadow-xs'
              : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
        >
          <Users className="w-4 h-4" />
          المستخدمون والصلاحيات
        </button>
      </div>

      {/* Tab 1: Center Information */}
      {activeTab === 'center' && (
        <form onSubmit={handleSaveSettings} className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-6">
          {/* Quick Profile & Logo Editor Banner */}
          <div className="bg-linear-to-r from-slate-900 via-indigo-950 to-slate-900 text-white p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 border border-indigo-900/50 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-white/10 p-1 flex items-center justify-center shrink-0 border border-white/20">
                {formData.logoUrl ? (
                  <img src={formData.logoUrl} alt="شعار المؤسسة" className="w-full h-full object-contain rounded-lg" />
                ) : (
                  <School className="w-6 h-6 text-white" />
                )}
              </div>
              <div>
                <h4 className="font-bold text-sm text-white">بروفيل وهوية المؤسسة والشعار المتقدم</h4>
                <p className="text-xs text-indigo-200">
                  تعديل الشعار الرسمي، الختم وتوقيع الإدارة، واسم المدير العام وكل التفاصيل.
                </p>
              </div>
            </div>
            {onOpenInstitutionProfile && (
              <Button
                type="button"
                variant="primary"
                size="sm"
                onClick={onOpenInstitutionProfile}
                className="bg-white text-indigo-900 hover:bg-indigo-50 font-bold shrink-0"
              >
                تعديل بروفيل المؤسسة والشعار ⚙️
              </Button>
            )}
          </div>

          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">معلومات المؤسسة والترويسة الرسمية</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                تظهر هذه البيانات على الوصولات المطبوعة والتقارير الإدارية والمالية
              </p>
            </div>
            {settingsSuccess && (
              <span className="text-xs font-medium text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" />
                تم حفظ التعديلات بنجاح
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                اسم المؤسسة أو المركز التربوي
              </label>
              <input
                type="text"
                value={formData.centerName}
                onChange={(e) => setFormData({ ...formData, centerName: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-semibold text-slate-900"
                required
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                شعار أو عبارة المؤسسة (Slogan)
              </label>
              <input
                type="text"
                value={formData.slogan}
                onChange={(e) => setFormData({ ...formData, slogan: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none text-slate-700"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">رقم الهاتف الرئيسي</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                رقم الهاتف الثانوي / واتساب
              </label>
              <input
                type="text"
                value={formData.phoneSecondary || ''}
                onChange={(e) => setFormData({ ...formData, phoneSecondary: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">العنوان الكامل للمقر</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                المعرف الضريبي / السجل التجاري
              </label>
              <input
                type="text"
                value={formData.taxIdOrLicense || ''}
                onChange={(e) => setFormData({ ...formData, taxIdOrLicense: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-xs"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">اسم المدير(ة)</label>
              <input
                type="text"
                value={formData.directorName}
                onChange={(e) => setFormData({ ...formData, directorName: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">العملة الافتراضية</label>
              <input
                type="text"
                value={formData.currency}
                onChange={(e) => setFormData({ ...formData, currency: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono font-bold"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">السنة الدراسية الحالية</label>
              <input
                type="text"
                value={formData.academicYear}
                onChange={(e) => setFormData({ ...formData, academicYear: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">بادئة رقم الوصل</label>
              <input
                type="text"
                value={formData.receiptPrefix}
                onChange={(e) => setFormData({ ...formData, receiptPrefix: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                تنسيق الطباعة الافتراضي
              </label>
              <select
                value={formData.printFormatDefault}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    printFormatDefault: e.target.value as 'A4' | 'thermal_80mm',
                  })
                }
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              >
                <option value="A4">ورق قياسي A4 (نسختان في الصفحة)</option>
                <option value="thermal_80mm">طابعة حرارية POS (80mm)</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                إشعار وشروط الوصل المالي (أسفل الوصل)
              </label>
              <textarea
                rows={2}
                value={formData.receiptTermsNotice}
                onChange={(e) => setFormData({ ...formData, receiptTermsNotice: e.target.value })}
                className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100">
            <Button type="submit" variant="primary" size="md" isLoading={isSavingSettings}>
              حفظ وتطبيق إعدادات المؤسسة
            </Button>
          </div>
        </form>
      )}

      {/* Tab 2: Backup & Restore */}
      {activeTab === 'backup' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-4">
            <div>
              <h3 className="text-base font-bold text-slate-900">النسخ الاحتياطي اليدوي والتصدير</h3>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                يقوم النظام بتجميع قاعدة البيانات كاملة (شؤون التلاميذ، الأداءات، الوصولات، الحضور،
                والمصاريف) في ملف مستقل مشفر بمفتاح تحقق رقمي (Checksum). يمكنك حفظ هذا الملف على
                مفتاح USB أو قرص صلب خارجي لحماية البيانات.
              </p>
            </div>

            {backupMsg && (
              <div
                className={`p-3.5 rounded-lg border text-xs font-medium flex items-center gap-2 ${
                  backupMsg.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {backupMsg.type === 'success' ? (
                  <CheckCircle className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{backupMsg.text}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex items-center gap-2">
                  <Download className="w-5 h-5 text-indigo-600" />
                  <h4 className="text-sm font-bold text-slate-900">تصدير وحفظ نسخة احتياطية الآن</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  تنزيل ملف النسخة الاحتياطية بصيغة JSON مع التاريخ والوقت واسم المركز تلقائياً.
                </p>
                <Button
                  variant="primary"
                  size="sm"
                  icon={<Download className="w-4 h-4" />}
                  isLoading={isExporting}
                  onClick={handleExportBackup}
                >
                  تصدير النسخة الاحتياطية (.json)
                </Button>
              </div>

              <div className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 space-y-3">
                <div className="flex items-center gap-2">
                  <Upload className="w-5 h-5 text-indigo-600" />
                  <h4 className="text-sm font-bold text-slate-900">استعادة البيانات من ملف سابق</h4>
                </div>
                <p className="text-xs text-slate-600 leading-relaxed">
                  استرجاع البيانات من نسخة احتياطية سابقة مع فحص سلامة الهيكل وحفظ لقطة أمان للرجوع
                  عند الحاجة.
                </p>
                <label className="inline-flex items-center justify-center gap-2 text-xs px-3.5 py-2 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 font-medium cursor-pointer transition-colors shadow-xs">
                  <Upload className="w-4 h-4" />
                  <span>{isRestoring ? 'جاري الفحص والاستعادة...' : 'اختيار ملف النسخة الاحتياطية'}</span>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleImportFile}
                    disabled={isRestoring}
                    className="hidden"
                  />
                </label>
              </div>
            </div>
          </div>

          {/* Best Practices & Security Protocol card */}
          <div className="bg-slate-50/80 p-5 rounded-xl border border-slate-200 text-xs space-y-2">
            <div className="flex items-center gap-2 text-slate-800 font-bold">
              <ShieldCheck className="w-4 h-4 text-indigo-600" />
              <span>بروتوكول السلامة الرقمية لحماية بيانات المؤسسة</span>
            </div>
            <p className="text-slate-600 leading-relaxed text-[11px]">
              تُحفظ جميع السجلات المالية وشؤون التلاميذ محلياً وبشكل دائم على القرص الصلب لحاسوب المؤسسة. يُنصح بتصدير نسخة احتياطية أسبوعياً بصيغة (<span className="font-mono text-indigo-600">.json</span>) وتخزينها في مفتاح USB خارجي، لضمان استمرارية العمل التامة وحماية الأرشيف المدرسي في حال حدوث أي عطل بالعتاد.
            </p>
          </div>
        </div>
      )}

      {/* Tab 3: Commercial License */}
      {activeTab === 'license' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200/90 shadow-xs space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-emerald-600" />
                  <h3 className="text-base font-bold text-slate-900">شهادة الترخيص التجاري المستقل</h3>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  رخصة استخدام تجارية أحادية دائمة (One-Time Perpetual License) مخصصة للجهاز المحلي للمؤسسة بدون اشتراك شهري
                </p>
              </div>
              <Badge variant={license.isValid ? 'success' : 'warning'} dot>
                {license.isValid ? 'رخصة تجارية نشطة ومدى الحياة' : 'نسخة تجريبية / غير مفعلة'}
              </Badge>
            </div>

            {licenseMsg && (
              <div
                className={`p-3.5 rounded-xl border text-xs font-medium flex items-center gap-2 ${
                  licenseMsg.type === 'success'
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}
              >
                {licenseMsg.type === 'success' ? (
                  <CheckCircle className="w-4 h-4 shrink-0 text-emerald-600" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                )}
                <span>{licenseMsg.text}</span>
              </div>
            )}

            {/* Hardware Fingerprint & Certificate Details */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50/80 p-5 rounded-xl border border-slate-200 text-xs">
              <div className="space-y-1">
                <span className="text-slate-500 font-medium">المؤسسة المرخص لها:</span>
                <span className="font-bold text-slate-900 text-sm block">
                  {license.centerName || settings.centerName}
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-slate-500 font-medium">نوع الترخيص المعتمد:</span>
                <span className="font-semibold text-slate-800 block">
                  رخصة تجارية دائمة مدى الحياة (Perpetual Commercial)
                </span>
              </div>

              <div className="space-y-1">
                <span className="text-slate-500 font-medium">تاريخ التفعيل الموثق:</span>
                <span className="font-mono text-slate-700 block">
                  {license.activatedAt || license.issueDate || '2025-09-01'}
                </span>
              </div>

              {/* Machine ID Box */}
              <div className="md:col-span-2 pt-3 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-slate-500 font-medium block">
                    بصمة العتاد المكتبي المسجل (Hardware Machine ID):
                  </span>
                  <span className="font-mono font-bold text-slate-900 text-sm tracking-wider mt-0.5 block">
                    {license.machineFingerprint}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleCopyMachineId}
                  className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold rounded-lg border border-slate-300 shadow-2xs transition-colors cursor-pointer shrink-0"
                >
                  {copiedMachineId ? (
                    <>
                      <CheckCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">تم نسخ البصمة!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-slate-500" />
                      <span>نسخ بصمة الجهاز للإرسال</span>
                    </>
                  )}
                </button>
              </div>

              {/* Masked License Key */}
              <div className="pt-3 border-t border-slate-200 space-y-1">
                <div className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-slate-400" />
                  <span className="text-slate-500 font-medium">كود التفعيل المحجوب (أمان مشفر):</span>
                </div>
                <span className="font-mono font-bold text-slate-800 bg-slate-200/70 px-2.5 py-1 rounded inline-block tracking-wider">
                  {license.maskedKey || 'ITQAN-9481-••••-••••-7A21'}
                </span>
              </div>
            </div>

            {/* Reassuring Enterprise Guarantee Note */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 text-xs space-y-1.5">
              <div className="flex items-center gap-2 text-indigo-700 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>شهادة ترخيص الاستخدام القانوني المعتمد</span>
              </div>
              <p className="text-slate-600 leading-relaxed text-[11px]">
                هذه النسخة مرخصة تجارياً وتعمل باستقلالية تامة داخل هذا الحاسوب. البيانات المالية وسجلات التلاميذ محمية بترميز محلي آمن، ولا يتم إرسال أي معلومات خارج هذا الجهاز لضمان الخصوصية وسرية السجلات.
              </p>
            </div>

            {/* Manual Activation Drawer toggle */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => setShowActivationForm(!showActivationForm)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1.5"
              >
                <KeyRound className="w-3.5 h-3.5" />
                <span>{showActivationForm ? 'إخفاء نموذج إدخال التفعيل' : 'إدخال أو تحديث كود تفعيل جديد'}</span>
              </button>
            </div>

            {showActivationForm && (
              <form onSubmit={handleActivateLicense} className="space-y-4 pt-2 bg-slate-50/70 p-4 rounded-xl border border-slate-200">
                <h4 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-2">
                  <Key className="w-4 h-4 text-indigo-600" />
                  <span>تأكيد تفعيل الترخيص التجاري الجديد</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">اسم المؤسسة المرخصة</label>
                    <input
                      type="text"
                      value={licenseCenterInput}
                      onChange={(e) => setLicenseCenterInput(e.target.value)}
                      placeholder="مثال: مؤسسة النجاح والتفوق للدعم التربوي"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">كود التفعيل المشفر المعتمد</label>
                    <input
                      type="text"
                      value={licenseKeyInput}
                      onChange={(e) => setLicenseKeyInput(e.target.value)}
                      placeholder="ITQAN-XXXX-XXXX-XXXX-XXXX"
                      className="w-full px-3 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
                      required
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2 pt-2">
                  <Button type="button" variant="outline" size="sm" onClick={() => setShowActivationForm(false)}>
                    إلغاء
                  </Button>
                  <Button type="submit" variant="primary" size="sm">
                    تأكيد وتفعيل الترخيص الآن
                  </Button>
                </div>
              </form>
            )}
          </div>

        </div>
      )}

      {/* Tab 4: Multi-User Switcher & Roles */}
      {activeTab === 'users' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200/90 shadow-xs space-y-6">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-base font-bold text-slate-900">إدارة المستخدمين والصلاحيات المحلية</h3>
              <p className="text-xs text-slate-500 mt-0.5">
                حسابات متعددة على نفس الجهاز المكتبي مع ضبط صلاحيات الاطلاع والتسجيل المالي
              </p>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500">المستخدم النشط حالياً:</span>
              <Badge variant="indigo" dot>
                {currentUser.fullName}
              </Badge>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {users.map((u) => {
              const isActive = u.id === currentUser.id;
              const roleTitle = {
                director: 'مدير المؤسسة (صلاحيات كاملة)',
                accountant: 'مسؤول الحسابات والمالية',
                admin: 'موظف الاستقبال والتسجيل',
                viewer: 'مستخدم محدود الصلاحيات',
              }[u.role];

              return (
                <div
                  key={u.id}
                  className={`p-4 rounded-xl border transition-all ${
                    isActive
                      ? 'border-indigo-600 bg-indigo-50/30 ring-2 ring-indigo-500/20 shadow-xs'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-mono font-semibold text-slate-500">
                      @{u.username}
                    </span>
                    {isActive ? (
                      <Badge variant="success" size="sm">
                        الجلسة الحالية
                      </Badge>
                    ) : (
                      <button
                        type="button"
                        onClick={() => onUserSwitched(u)}
                        className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
                      >
                        تبديل إلى هذا الحساب
                      </button>
                    )}
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm">{u.fullName}</h4>
                  <p className="text-xs text-slate-500 mt-0.5">{roleTitle}</p>

                  <div className="mt-4 pt-3 border-t border-slate-100 text-[11px] text-slate-500 space-y-1">
                    <div>آخر تسجيل دخول: {u.lastLogin || 'الآن'}</div>
                    <div>
                      الصلاحيات: {u.permissions.includes('all') ? 'كافة أقسام النظام' : `${u.permissions.length} صلاحيات`}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Discrete Professional Enterprise Footer */}
      <div className="pt-6 pb-2 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-400 gap-3">
        <div className="flex items-center gap-2">
          <span>منظومة إتقان لإدارة المراكز التربوية والمؤسسات</span>
          <span>•</span>
          <button
            type="button"
            onClick={() => {
              setVersionClicks((c) => {
                if (c + 1 >= 5) {
                  setIsSystemConsoleOpen(true);
                  return 0;
                }
                return c + 1;
              });
            }}
            className="font-mono text-slate-500 hover:text-slate-800 transition-colors cursor-pointer select-none"
            title="الإصدار المكتبي المستقر"
          >
            v2.4 (مستقر)
          </button>
        </div>

        <div className="flex items-center gap-4">
          <span className="text-[11px] text-slate-400">التخزين: محلي آمن ومؤمّن</span>
        </div>
      </div>

      {/* Exclusive Hidden System Console Modal (خاص بالتقني والمطور ومحمي بـ PIN) */}
      <Modal
        isOpen={isSystemConsoleOpen}
        onClose={() => setIsSystemConsoleOpen(false)}
        title="وحدة الإشراف الفني والصيانة المتقدمة (Administration Système)"
        subtitle="الإجراءات السنوية، إدارة التراخيص المشفرة، والتهيئة الفنية المعتمدة"
        maxWidth="2xl"
      >
        <div className="space-y-5">
          {!isConsoleUnlocked ? (
            <form onSubmit={handleUnlockConsole} className="space-y-4 py-2">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center gap-2 text-slate-800 font-bold text-xs">
                  <Lock className="w-4 h-4 text-indigo-600" />
                  <span>المصادقة الأمنية للمشرف التقني المعتمد</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed">
                  هذه النافذة مخصصة لإجراءات الصيانة الدورية السنوية وإدارة رخص التشغيل. يُرجى إدخال رمز التحقق الأمني الخاص بالمشرف المعتمد للمتابعة.
                </p>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-semibold text-slate-700">
                  رمز التحقق الأمني (Code PIN):
                </label>
                <div className="flex gap-2">
                  <input
                    type="password"
                    value={consolePin}
                    onChange={(e) => setConsolePin(e.target.value)}
                    placeholder="••••"
                    className="px-3.5 py-2 text-sm bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none w-48 font-mono tracking-widest text-center"
                    autoFocus
                  />
                  <Button type="submit" variant="primary" size="md">
                    تأكيد الهوية والدخول
                  </Button>
                </div>
                {consolePinError && (
                  <p className="text-xs text-rose-600 font-medium flex items-center gap-1 mt-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>رمز التحقق غير صحيح. تواصل مع المشرف التقني المعتمد.</span>
                  </p>
                )}
              </div>
            </form>
          ) : (
            <div className="space-y-5">
              {/* Console Navigation */}
              <div className="flex items-center gap-2 border-b border-slate-200 pb-2.5">
                <button
                  type="button"
                  onClick={() => setConsoleTab('rollover')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    consoleTab === 'rollover'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  الترحيل السنوي (شتنبر)
                </button>
                <button
                  type="button"
                  onClick={() => setConsoleTab('keygen')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    consoleTab === 'keygen'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  توليد التراخيص
                </button>
                <button
                  type="button"
                  onClick={() => setConsoleTab('reset')}
                  className={`px-3 py-1.5 text-xs font-bold rounded-lg transition-colors cursor-pointer ${
                    consoleTab === 'reset'
                      ? 'bg-indigo-600 text-white'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  إعادة الضبط
                </button>
              </div>

              {/* Console Tab 1: Annual Rollover */}
              {consoleTab === 'rollover' && (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50/80 border border-emerald-200 rounded-xl space-y-3">
                    <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      <span>إجراء شتنبر: أرشفة الموسم القديم في فلاشة + إطلاق الموسم الجديد</span>
                    </div>
                    <p className="text-xs text-emerald-800 leading-relaxed">
                      بنقرة واحدة سيتم: تنزيل ملف الأرشيف الكامل لموسم ({settings.academicYear}) على الفلاشة، وتصفير سجلات التلاميذ والوصولات والمصاريف، وضبط رقم أول وصل على (1)، وتحديث الموسم إلى السنة الجديدة مع الاحتفاظ بالأفواج والأسعار.
                    </p>

                    <div className="flex flex-wrap items-center gap-3 pt-2">
                      <div className="flex items-center gap-2 text-xs font-semibold text-slate-700">
                        <span>الموسم الدراسي الجديد:</span>
                        <input
                          type="text"
                          value={nextYearInput}
                          onChange={(e) => setNextYearInput(e.target.value)}
                          className="px-2.5 py-1.5 text-xs font-bold text-indigo-700 bg-white border border-slate-300 rounded-md w-28 text-center"
                        />
                      </div>

                      <Button
                        variant="primary"
                        size="sm"
                        isLoading={isProcessingRollover}
                        icon={<Download className="w-4 h-4" />}
                        onClick={handleAnnualRollover}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold"
                      >
                        أرشفة القديم ففلاشة + إطلاق الموسم الجديد الآن
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Console Tab 2: Key Generator */}
              {consoleTab === 'keygen' && (
                <form onSubmit={handleGenerateLicenseKey} className="space-y-4">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-600">
                    توليد كود التفعيل المعتمد لمؤسسة معينة بناءً على بصمة حاسوبها الشخصي.
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">اسم المؤسسة المرخصة:</label>
                      <input
                        type="text"
                        value={devCenterName}
                        onChange={(e) => setDevCenterName(e.target.value)}
                        placeholder="مثال: مركز التفوق للغات"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-1 focus:ring-indigo-500 outline-none"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-slate-700 mb-1">بصمة جهاز العميل (Machine ID):</label>
                      <input
                        type="text"
                        value={devMachineId}
                        onChange={(e) => setDevMachineId(e.target.value)}
                        placeholder="مثال: WIN-48BF-7A21"
                        className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg font-mono focus:ring-1 focus:ring-indigo-500 outline-none"
                        required
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <Button type="submit" variant="primary" size="sm" icon={<Sparkles className="w-4 h-4 text-amber-300" />}>
                      توليد كود التفعيل المشفر
                    </Button>
                    <button
                      type="button"
                      onClick={() => {
                        setDevCenterName(license.centerName || settings.centerName);
                        setDevMachineId(license.machineFingerprint);
                      }}
                      className="text-xs text-indigo-600 hover:underline"
                    >
                      ملء بيانات هذا الجهاز
                    </button>
                  </div>

                  {generatedKey && (
                    <div className="p-3.5 rounded-xl bg-slate-900 border border-indigo-500/40 space-y-2 mt-3">
                      <span className="text-xs text-indigo-300 font-semibold block">
                        كود التفعيل المشفر المعتمد (مقفل على جهاز العميل):
                      </span>
                      <div className="flex items-center justify-between gap-3 bg-slate-950 p-2 rounded-lg border border-slate-800 font-mono text-emerald-400 text-sm font-bold tracking-widest">
                        <span>{generatedKey}</span>
                        <button
                          type="button"
                          onClick={handleCopyGeneratedKey}
                          className="text-xs px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors flex items-center gap-1 cursor-pointer font-sans"
                        >
                          {copiedGeneratedKey ? (
                            <>
                              <Check className="w-3.5 h-3.5 text-emerald-400" />
                              <span>تم النسخ!</span>
                            </>
                          ) : (
                            <>
                              <Copy className="w-3.5 h-3.5 text-slate-300" />
                              <span>نسخ الكود</span>
                            </>
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                </form>
              )}

              {/* Console Tab 3: System Reset */}
              {consoleTab === 'reset' && (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                  <div className="p-3 rounded-lg border border-amber-200 bg-amber-50/60 space-y-2">
                    <h4 className="text-xs font-bold text-amber-900">تفريغ بيانات التجربة (البدء من الصفر)</h4>
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                      حذف سجلات التلاميذ والمصاريف التجريبية مع الاحتفاظ الكامل باسم المؤسسة والأفواج والأسعار.
                    </p>
                    <Button
                      variant="outline"
                      size="sm"
                      className="bg-white text-amber-800 border-amber-300 hover:bg-amber-100"
                      icon={<RefreshCw className="w-3.5 h-3.5" />}
                      onClick={handleClearTransactionalData}
                    >
                      تفريغ التلاميذ والمصاريف (0 تلميذ)
                    </Button>
                  </div>

                  <div className="p-3 rounded-lg border border-rose-200 bg-rose-50/60 space-y-2">
                    <h4 className="text-xs font-bold text-rose-900">إعادة تعيين قاعدة البيانات النموذجية</h4>
                    <p className="text-[11px] text-rose-800 leading-relaxed">
                      استعادة النسخة النموذجية الأصلية للنظام بالكامل مع مسح كافة السجلات.
                    </p>
                    <Button
                      variant="danger"
                      size="sm"
                      icon={<RefreshCw className="w-3.5 h-3.5" />}
                      onClick={handleResetData}
                    >
                      استعادة الحالة الأولية
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </Modal>
    </div>
  );
};
