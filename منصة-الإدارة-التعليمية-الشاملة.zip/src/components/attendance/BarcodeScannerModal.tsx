import React, { useEffect, useRef, useState } from 'react';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { StudentWithDetails } from '../../types';
import { Html5Qrcode } from 'html5-qrcode';
import { Camera, CheckCircle2, AlertCircle, Scan, Volume2, Sparkles, X } from 'lucide-react';

interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  groupStudents: StudentWithDetails[];
  onStudentScanned: (student: StudentWithDetails) => void;
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  groupStudents,
  onStudentScanned,
}) => {
  const [manualCode, setManualCode] = useState('');
  const [scannerActive, setScannerActive] = useState(false);
  const [lastScannedStudent, setLastScannedStudent] = useState<StudentWithDetails | null>(null);
  const [scanMessage, setScanMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const scannerContainerId = 'qr-barcode-reader-container';

  // Sound feedback using Web Audio API
  const playBeep = (isSuccess: boolean) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (isSuccess) {
        osc.frequency.setValueAtTime(880, audioCtx.currentTime); // A5 note
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.15);
      } else {
        osc.frequency.setValueAtTime(300, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.3, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.25);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.25);
      }
    } catch (e) {
      // Audio not permitted or not supported
    }
  };

  const handleProcessCode = (code: string) => {
    const cleanCode = code.trim().toUpperCase();
    if (!cleanCode) return;

    // Search in group students by code or ID or partial QR text
    const matched = groupStudents.find(
      (s) =>
        s.code.toUpperCase() === cleanCode ||
        s.id.toUpperCase() === cleanCode ||
        cleanCode.includes(s.code.toUpperCase()) ||
        cleanCode.includes(s.id.toUpperCase())
    );

    if (matched) {
      playBeep(true);
      setLastScannedStudent(matched);
      setScanMessage({
        type: 'success',
        text: `تم تسجيل حضور: ${matched.fullName} (${matched.code}) بنجاح!`,
      });
      onStudentScanned(matched);
      setManualCode('');
    } else {
      playBeep(false);
      setScanMessage({
        type: 'error',
        text: `الرمز "${cleanCode}" غير مسجل في هذا الفوج الدراسي!`,
      });
    }

    setTimeout(() => {
      setScanMessage(null);
    }, 3500);
  };

  // Start Camera Scanner when Modal opens
  useEffect(() => {
    if (!isOpen) {
      if (scannerRef.current) {
        try {
          scannerRef.current.stop().then(() => {
            scannerRef.current?.clear();
            scannerRef.current = null;
          }).catch(() => {});
        } catch (e) {}
      }
      setScannerActive(false);
      return;
    }

    const timer = setTimeout(() => {
      try {
        const html5QrCode = new Html5Qrcode(scannerContainerId);
        scannerRef.current = html5QrCode;

        html5QrCode
          .start(
            { facingMode: 'environment' },
            {
              fps: 10,
              qrbox: { width: 250, height: 250 },
            },
            (decodedText) => {
              handleProcessCode(decodedText);
            },
            () => {
              // Parse error / frame skip
            }
          )
          .then(() => {
            setScannerActive(true);
          })
          .catch((err) => {
            console.warn('Camera failed to start:', err);
            setScannerActive(false);
          });
      } catch (err) {
        console.warn('Scanner init error:', err);
      }
    }, 400);

    return () => {
      clearTimeout(timer);
      if (scannerRef.current) {
        try {
          scannerRef.current.stop().then(() => {
            scannerRef.current?.clear();
            scannerRef.current = null;
          }).catch(() => {});
        } catch (e) {}
      }
    };
  }, [isOpen]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleProcessCode(manualCode);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="مسح بطاقة التلميذ وتسجيل الحضور الفوري"
      subtitle="وجه كاميرا الهاتف/التابليت نحو بطاقة التلميذ أو استخدم قارئ الباركود الضوئي"
      maxWidth="md"
    >
      <div className="space-y-4" dir="rtl">
        {/* Scanner Viewport */}
        <div className="relative bg-slate-900 rounded-2xl overflow-hidden border-2 border-slate-700 aspect-video max-h-[260px] flex items-center justify-center">
          <div id={scannerContainerId} className="w-full h-full" />

          {/* Visual Scanning Reticle */}
          <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
            <div className="w-48 h-48 border-2 border-emerald-400/80 rounded-2xl animate-pulse relative">
              <span className="absolute top-0 right-0 w-4 h-4 border-t-4 border-r-4 border-emerald-400 rounded-tr-lg" />
              <span className="absolute top-0 left-0 w-4 h-4 border-t-4 border-l-4 border-emerald-400 rounded-tl-lg" />
              <span className="absolute bottom-0 right-0 w-4 h-4 border-b-4 border-r-4 border-emerald-400 rounded-br-lg" />
              <span className="absolute bottom-0 left-0 w-4 h-4 border-b-4 border-l-4 border-emerald-400 rounded-bl-lg" />
              <div className="absolute left-0 right-0 top-1/2 h-0.5 bg-emerald-400/70 shadow-xs shadow-emerald-400 animate-bounce" />
            </div>
          </div>

          {!scannerActive && (
            <div className="absolute inset-0 bg-slate-900/90 flex flex-col items-center justify-center p-4 text-center text-xs text-slate-300 space-y-2">
              <Camera className="w-8 h-8 text-slate-500 animate-pulse" />
              <p>جاري تشغيل كاميرا التابليت / الحاسوب...</p>
              <p className="text-[11px] text-slate-400">تأكد من السماح للمتصفح بالوصول للكاميرا أو استخدم الإدخال اليدوي أدناه</p>
            </div>
          )}
        </div>

        {/* Status Alert Banner */}
        {scanMessage && (
          <div
            className={`p-3 rounded-xl border flex items-center gap-2.5 text-xs font-bold animate-in fade-in duration-150 ${
              scanMessage.type === 'success'
                ? 'bg-emerald-50 text-emerald-900 border-emerald-200'
                : 'bg-rose-50 text-rose-900 border-rose-200'
            }`}
          >
            {scanMessage.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            )}
            <span>{scanMessage.text}</span>
          </div>
        )}

        {/* Manual Barcode / Code Form (Works with USB Laser Gun or Keyboard) */}
        <form onSubmit={handleManualSubmit} className="flex items-center gap-2">
          <div className="relative flex-1">
            <Scan className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
            <input
              type="text"
              value={manualCode}
              onChange={(e) => setManualCode(e.target.value)}
              placeholder="اكتب رمز التلميذ أو امسح بقارئ الباركود USB (مثال: STU-101)..."
              className="w-full pr-9 pl-3 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
              autoFocus
            />
          </div>
          <Button variant="primary" size="sm" type="submit">
            تسجيل
          </Button>
        </form>

        {/* Last Scanned Student Preview */}
        {lastScannedStudent && (
          <div className="p-3 bg-emerald-50/70 border border-emerald-100 rounded-xl flex items-center justify-between text-xs">
            <div className="flex items-center gap-2.5">
              <span className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center font-bold text-xs">
                ✓
              </span>
              <div>
                <span className="text-slate-500 text-[10px] block">آخر تلميذ سُجل حضوره:</span>
                <span className="font-bold text-slate-900 text-sm">{lastScannedStudent.fullName}</span>
                <span className="font-mono text-emerald-700 text-xs mr-2">({lastScannedStudent.code})</span>
              </div>
            </div>
            <span className="px-2 py-0.5 bg-emerald-100 text-emerald-800 text-[11px] font-bold rounded-md">
              حاضر الآن
            </span>
          </div>
        )}

        {/* Footer info */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
          <span className="flex items-center gap-1">
            <Volume2 className="w-3.5 h-3.5 text-slate-400" />
            <span>الصوت التفاعلي مفعّل (Beep) عند كل مسح ناجح</span>
          </span>
          <Button variant="outline" size="sm" onClick={onClose}>
            إغلاق
          </Button>
        </div>
      </div>
    </Modal>
  );
};
