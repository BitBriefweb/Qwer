import React, { useState, useEffect } from 'react';
import { StudyGroup, StudentWithDetails, AttendanceRecord, AttendanceStatus, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Button } from '../common/Button';
import { Badge } from '../common/Badge';
import { Check, X, Clock, HelpCircle, Save, CheckCheck, Printer, Scan, MessageCircle, History } from 'lucide-react';
import { BarcodeScannerModal } from './BarcodeScannerModal';
import { StudentAbsenceHistoryModal } from './StudentAbsenceHistoryModal';

interface AttendanceSheetProps {
  groups: StudyGroup[];
  students: StudentWithDetails[];
  settings?: CenterSettings;
}

export const AttendanceSheet: React.FC<AttendanceSheetProps> = ({ groups, students, settings }) => {
  const [selectedGroupId, setSelectedGroupId] = useState<string>(groups[0]?.id || '');
  const [sessionDate, setSessionDate] = useState<string>(
    new Date().toISOString().substring(0, 10)
  );
  const [sessionTime, setSessionTime] = useState<string>('18:00');
  const [attendanceMap, setAttendanceMap] = useState<
    Record<string, { status: AttendanceStatus; notes: string }>
  >({});
  const [isSaving, setIsSaving] = useState(false);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [selectedStudentForAbsences, setSelectedStudentForAbsences] = useState<StudentWithDetails | null>(null);

  useEffect(() => {
    if (selectedGroupId && sessionDate) {
      loadAttendance();
    }
  }, [selectedGroupId, sessionDate]);

  // Students enrolled in selected group
  const groupStudents = students.filter((s) =>
    s.enrolledGroups.some((g: { id: string }) => g.id === selectedGroupId)
  );

  const currentGroup = groups.find((g) => g.id === selectedGroupId);

  const loadAttendance = async () => {
    try {
      const records = await dataService.getAttendanceByGroupAndDate(selectedGroupId, sessionDate);
      const map: Record<string, { status: AttendanceStatus; notes: string }> = {};

      // Seed with existing records
      records.forEach((r) => {
        map[r.studentId] = { status: r.status, notes: r.notes || '' };
      });

      // For unrecorded students, default to 'present'
      groupStudents.forEach((s) => {
        if (!map[s.id]) {
          map[s.id] = { status: 'present', notes: '' };
        }
      });

      setAttendanceMap(map);
      setSuccessMsg(null);
    } catch (e) {
      console.error(e);
    }
  };

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendanceMap((prev) => ({
      ...prev,
      [studentId]: {
        status,
        notes: prev[studentId]?.notes || '',
      },
    }));
  };

  const handleNotesChange = (studentId: string, notes: string) => {
    setAttendanceMap((prev) => ({
      ...prev,
      [studentId]: {
        status: prev[studentId]?.status || 'present',
        notes,
      },
    }));
  };

  const markAll = (status: AttendanceStatus) => {
    const updated: Record<string, { status: AttendanceStatus; notes: string }> = {};
    groupStudents.forEach((s) => {
      updated[s.id] = {
        status,
        notes: attendanceMap[s.id]?.notes || '',
      };
    });
    setAttendanceMap(updated);
  };

  const handleSave = async () => {
    if (!selectedGroupId || groupStudents.length === 0) return;

    try {
      setIsSaving(true);
      const recordsToSave = groupStudents.map((s) => ({
        studentId: s.id,
        status: attendanceMap[s.id]?.status || 'present',
        notes: attendanceMap[s.id]?.notes || undefined,
      }));

      await dataService.saveAttendanceBatch(
        selectedGroupId,
        sessionDate,
        sessionTime,
        recordsToSave
      );
      setSuccessMsg('تم حفظ وتوثيق لائحة الحضور والغياب بنجاح.');
      setTimeout(() => setSuccessMsg(null), 4000);
    } catch (e) {
      alert((e as Error).message || 'حدث خطأ أثناء حفظ الحضور');
    } finally {
      setIsSaving(false);
    }
  };

  // Quick stats
  const presentCount = groupStudents.filter(
    (s) => attendanceMap[s.id]?.status === 'present'
  ).length;
  const absentCount = groupStudents.filter(
    (s) => attendanceMap[s.id]?.status === 'absent'
  ).length;
  const lateCount = groupStudents.filter((s) => attendanceMap[s.id]?.status === 'late').length;
  const excusedCount = groupStudents.filter(
    (s) => attendanceMap[s.id]?.status === 'excused'
  ).length;

  return (
    <div className="space-y-4">
      {/* Group & Date Selector Toolbar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200/90 shadow-xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              المجموعة الدراسية:
            </label>
            <select
              value={selectedGroupId}
              onChange={(e) => setSelectedGroupId(e.target.value)}
              className="px-3 py-1.5 text-xs font-semibold bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            >
              {groups.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name} ({g.teacherName})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              تاريخ الحصة:
            </label>
            <input
              type="date"
              value={sessionDate}
              onChange={(e) => setSessionDate(e.target.value)}
              className="px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">
              وقت انطلاق الحصة:
            </label>
            <input
              type="time"
              value={sessionTime}
              onChange={(e) => setSessionTime(e.target.value)}
              className="px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono"
            />
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="sm"
            icon={<Scan className="w-4 h-4 text-indigo-600" />}
            onClick={() => setIsScannerOpen(true)}
            title="مسح بطاقة التلميذ بالباركود أو الكاميرا لتسجيل الحضور الفوري"
          >
            مسح بالباركود / QR 📷
          </Button>
          <Button
            variant="outline"
            size="sm"
            icon={<Printer className="w-4 h-4 text-slate-600" />}
            onClick={() => window.print()}
            title="طباعة ورقة الحضور لتسليمها للأستاذ في القاعة"
          >
            طباعة الورقة
          </Button>
          <Button
            variant="outline"
            size="sm"
            icon={<CheckCheck className="w-4 h-4 text-emerald-600" />}
            onClick={() => markAll('present')}
          >
            الكل حاضر
          </Button>
          <Button
            variant="primary"
            size="sm"
            icon={<Save className="w-4 h-4" />}
            isLoading={isSaving}
            onClick={handleSave}
          >
            حفظ وتوثيق الحضور
          </Button>
        </div>
      </div>

      {/* Real-time Attendance Stat Banner */}
      <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl flex flex-wrap items-center justify-between text-xs text-slate-600 gap-3">
        <div className="flex items-center gap-4">
          <span>
            إجمالي المسجلين في الفوج:{' '}
            <strong className="text-slate-900 font-mono">{groupStudents.length}</strong>
          </span>
          <span>·</span>
          <span className="text-emerald-700 font-medium">
            حاضر: <strong className="font-mono">{presentCount}</strong>
          </span>
          <span>·</span>
          <span className="text-rose-700 font-medium">
            غائب: <strong className="font-mono">{absentCount}</strong>
          </span>
        </div>

        {successMsg && (
          <div className="text-emerald-700 bg-emerald-50 px-3 py-1 rounded-md border border-emerald-200 font-medium animate-fade-in">
            {successMsg}
          </div>
        )}
      </div>

      {/* Attendance Table */}
      {groupStudents.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-200 text-slate-500 text-sm">
          لا يوجد أي تلميذ مسجل في هذا الفوج حالياً. يمكنك تسجيل التلاميذ من قسم "سجل التلاميذ".
        </div>
      ) : (
        <div className="bg-white border border-slate-200/90 rounded-xl overflow-hidden shadow-xs">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 font-bold">
              <tr>
                <th className="py-3 px-3 w-10 text-center">#</th>
                <th className="py-3 px-3">رقم التعريف</th>
                <th className="py-3 px-3">اسم التلميذ</th>
                <th className="py-3 px-3">رقم الهاتف</th>
                <th className="py-3 px-3 text-center">حالة الحضور اليوم</th>
                <th className="py-3 px-3 text-center">سجل غياباته (كم ومتى)</th>
                <th className="py-3 px-3">ملاحظات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {groupStudents.map((stu, idx) => {
                const currentStatus = attendanceMap[stu.id]?.status || 'present';
                const isAbsent = currentStatus === 'absent';
                return (
                  <tr key={stu.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-2.5 px-3 text-center font-mono text-slate-400">
                      {idx + 1}
                    </td>
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-700">{stu.code}</td>
                    <td className="py-2.5 px-3 font-bold text-slate-900">{stu.fullName}</td>
                    <td className="py-2.5 px-3 font-mono text-slate-600" dir="ltr">
                      {stu.guardianPhone}
                    </td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          type="button"
                          onClick={() => handleStatusChange(stu.id, 'present')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            !isAbsent
                              ? 'bg-emerald-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          <Check className="w-3.5 h-3.5" />
                          <span>حاضر</span>
                        </button>

                        <button
                          type="button"
                          onClick={() => handleStatusChange(stu.id, 'absent')}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center gap-1 ${
                            isAbsent
                              ? 'bg-rose-600 text-white shadow-xs'
                              : 'bg-slate-100 text-slate-500 hover:bg-slate-200'
                          }`}
                        >
                          <X className="w-3.5 h-3.5" />
                          <span>غائب</span>
                        </button>

                        {isAbsent && stu.guardianPhone && (
                          <a
                            href={dataService.getWhatsAppAttendanceUrl(
                              stu,
                              currentGroup?.name || 'الفوج',
                              sessionDate,
                              'absent',
                              settings?.centerName || 'مؤسسة النجاح'
                            )}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-1 px-2 py-1 rounded-md bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 text-[11px] font-bold transition-all cursor-pointer shadow-2xs"
                            title="إرسال إشعار فوري لولي الأمر عبر واتساب"
                          >
                            <MessageCircle className="w-3 h-3 text-emerald-600" />
                            <span>واتساب</span>
                          </a>
                        )}
                      </div>
                    </td>

                    <td className="py-2.5 px-3 text-center">
                      <button
                        type="button"
                        onClick={() => setSelectedStudentForAbsences(stu)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold border border-indigo-200 transition-colors cursor-pointer"
                        title="عرض كشف الغيابات وتواريخها بدقة"
                      >
                        <History className="w-3.5 h-3.5" />
                        <span>سجل الغياب 📋</span>
                      </button>
                    </td>

                    <td className="py-2.5 px-3">
                      <input
                        type="text"
                        placeholder="ملاحظة..."
                        value={attendanceMap[stu.id]?.notes || ''}
                        onChange={(e) => handleNotesChange(stu.id, e.target.value)}
                        className="w-full px-2.5 py-1 bg-white border border-slate-200 rounded-md text-xs text-slate-800 focus:ring-1 focus:ring-indigo-500 outline-none"
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Barcode / QR Camera Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        groupStudents={groupStudents}
        onStudentScanned={(scannedStu) => {
          handleStatusChange(scannedStu.id, 'present');
        }}
      />

      {/* Student Absence History Modal (كم يوم غاب ومتى) */}
      <StudentAbsenceHistoryModal
        isOpen={!!selectedStudentForAbsences}
        onClose={() => setSelectedStudentForAbsences(null)}
        student={selectedStudentForAbsences}
        settings={settings}
      />
    </div>
  );
};
