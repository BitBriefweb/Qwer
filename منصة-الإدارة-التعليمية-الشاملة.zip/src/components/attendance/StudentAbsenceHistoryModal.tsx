import React, { useState, useEffect } from 'react';
import { StudentWithDetails, AttendanceRecord, CenterSettings } from '../../types';
import { dataService } from '../../services/data-service';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { Calendar, AlertCircle, CheckCircle, MessageCircle, Phone } from 'lucide-react';

interface StudentAbsenceHistoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: StudentWithDetails | null;
  settings?: CenterSettings;
}

export const StudentAbsenceHistoryModal: React.FC<StudentAbsenceHistoryModalProps> = ({
  isOpen,
  onClose,
  student,
  settings,
}) => {
  const [absences, setAbsences] = useState<Array<AttendanceRecord & { groupName?: string }>>([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (student && isOpen) {
      loadAbsences(student.id);
    }
  }, [student, isOpen]);

  const loadAbsences = async (studentId: string) => {
    try {
      setIsLoading(true);
      const list = await dataService.getStudentAbsences(studentId);
      setAbsences(list);
    } catch (e) {
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  };

  if (!student) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`سجل غيابات التلميذ: ${student.fullName}`}
      subtitle={`رقم التسجيل: ${student.code} • ${student.enrolledGroups.map((g) => g.name).join('، ') || 'طالب مسجل'}`}
      maxWidth="lg"
    >
      <div className="space-y-4" dir="rtl">
        {/* Quick Stats Pill */}
        <div className="p-4 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div
              className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-lg ${
                absences.length > 0 ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'
              }`}
            >
              {absences.length}
            </div>
            <div>
              <span className="text-xs text-slate-500 block">إجمالي أيام الغياب المسجلة</span>
              <span className="font-extrabold text-sm text-slate-800">
                {absences.length === 0 ? 'لا توجد أي غيابات مسجلة (منضبط دائماً)' : `${absences.length} حصص غياب`}
              </span>
            </div>
          </div>

          {student.guardianPhone && (
            <a
              href={`https://wa.me/212${student.guardianPhone.replace(/^0/, '').replace(/\s+/g, '')}?text=${encodeURIComponent(
                `السلام عليكم ورحمة الله، نخبركم من إدارة ${
                  settings?.centerName || 'المؤسسة'
                } أن التلميذ(ة) ${student.fullName} قد تغيب(ت) عن حصص الدعم.`
              )}`}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all flex items-center gap-1.5 shadow-xs"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>مراسلة الولي عبر واتساب</span>
            </a>
          )}
        </div>

        {/* Detailed Absences List */}
        <div>
          <h4 className="text-xs font-bold text-slate-700 mb-2 flex items-center gap-1.5">
            <Calendar className="w-4 h-4 text-indigo-500" />
            <span>التواريخ الدقيقة للحصص التي غاب فيها:</span>
          </h4>

          {isLoading ? (
            <div className="text-center py-8 text-xs text-slate-400">جاري تحميل سجل الغيابات...</div>
          ) : absences.length === 0 ? (
            <div className="text-center py-8 bg-emerald-50 rounded-xl border border-emerald-200 p-4 space-y-1 text-emerald-700">
              <CheckCircle className="w-8 h-8 mx-auto text-emerald-600" />
              <p className="font-bold text-sm">سجل ناصع! لم يسجل عليه أي غياب</p>
              <p className="text-xs text-emerald-600">التلميذ يحضر بانتظام لكافة الحصص المقررة.</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {absences.map((record) => (
                <div
                  key={record.id}
                  className="p-3 rounded-xl border border-rose-100 bg-rose-50/40 flex items-center justify-between text-xs"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 font-bold text-slate-800">
                      <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span>
                      <span>{record.sessionDate}</span>
                      <span className="text-slate-400 font-mono">({record.sessionTime || '18:00'})</span>
                    </div>
                    <div className="text-[11px] text-slate-500">
                      الفوج: <strong className="text-slate-700">{record.groupName || 'فوج دراسي'}</strong>
                      {record.notes && (
                        <span className="mr-2 text-slate-600 bg-white px-1.5 py-0.5 rounded border border-slate-200 text-[10px]">
                          ملاحظة: {record.notes}
                        </span>
                      )}
                    </div>
                  </div>

                  <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-700 border border-rose-200">
                    غائب
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="pt-3 border-t border-slate-100 flex justify-end">
          <Button variant="secondary" size="sm" onClick={onClose}>
            إغلاق النافذة
          </Button>
        </div>
      </div>
    </Modal>
  );
};
