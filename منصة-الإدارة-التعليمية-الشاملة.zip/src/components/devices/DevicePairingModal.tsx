import React, { useState } from 'react';
import { ConnectedDevice, StudyGroup } from '../../types';
import { Modal } from '../common/Modal';
import { Button } from '../common/Button';
import { QRCodeSvg } from '../common/QRCodeSvg';
import { Tablet, Smartphone, Laptop, KeyRound, QrCode, Check, Copy, ExternalLink, ShieldCheck, Sparkles } from 'lucide-react';

interface DevicePairingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDevice: (data: Omit<ConnectedDevice, 'id' | 'createdAt' | 'pairingToken'>) => Promise<ConnectedDevice>;
  groups: StudyGroup[];
  onOpenMobileTerminal: (device: ConnectedDevice) => void;
}

export const DevicePairingModal: React.FC<DevicePairingModalProps> = ({
  isOpen,
  onClose,
  onAddDevice,
  groups,
  onOpenMobileTerminal,
}) => {
  const [step, setStep] = useState<'form' | 'qr'>('form');
  const [name, setName] = useState('');
  const [deviceType, setDeviceType] = useState<ConnectedDevice['deviceType']>('tablet');
  const [pinCode, setPinCode] = useState(
    Math.floor(1000 + Math.random() * 9000).toString()
  );
  const [assignedTeacher, setAssignedTeacher] = useState('');
  const [notes, setNotes] = useState('');
  const [createdDevice, setCreatedDevice] = useState<ConnectedDevice | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    try {
      setIsSubmitting(true);
      const newDev = await onAddDevice({
        name: name.trim(),
        deviceType,
        pinCode: pinCode.trim() || '1234',
        assignedTeacher: assignedTeacher.trim() || undefined,
        status: 'active',
        notes: notes.trim() || undefined,
      });

      setCreatedDevice(newDev);
      setStep('qr');
    } catch (err) {
      alert((err as Error).message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // Generate pairing URL for phone / tablet
  const pairingUrl = createdDevice
    ? `${window.location.origin}${window.location.pathname}?mode=mobile_terminal&device=${createdDevice.id}&token=${createdDevice.pairingToken}`
    : '';

  const handleCopyLink = () => {
    if (!pairingUrl) return;
    navigator.clipboard.writeText(pairingUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        onClose();
        setStep('form');
        setCreatedDevice(null);
      }}
      title={step === 'form' ? 'إضافة وربط جهاز لوحي (تابليت / هاتف) جديد' : 'رمز المصادقة السريعة ومسح QR Code'}
      subtitle={
        step === 'form'
          ? 'اربط هاتف أو تابلت الأستاذ لتسجيل الغياب في القاعات مع المزامنة الفورية مع الحاسوب'
          : 'امسح الرمز بكاميرا الهاتف أو التابليت للاتصال المباشر والبدء الفوري'
      }
      maxWidth="md"
    >
      {step === 'form' ? (
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">
              اسم الجهاز المخصص <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="مثال: تابليت القاعة 1، هاتف الأستاذ طارق، تابلت الدعم..."
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-700">نوع الجهاز</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setDeviceType('tablet')}
                  className={`p-2 rounded-lg border text-center text-xs font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                    deviceType === 'tablet'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-500/20'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <Tablet className="w-5 h-5" />
                  <span>جهاز لوحي (تابليت)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setDeviceType('phone')}
                  className={`p-2 rounded-lg border text-center text-xs font-bold flex flex-col items-center gap-1 transition-all cursor-pointer ${
                    deviceType === 'phone'
                      ? 'border-indigo-600 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-500/20'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  <Smartphone className="w-5 h-5" />
                  <span>هاتف ذكي (موبايل)</span>
                </button>
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-xs font-semibold text-slate-700">
                رمز PIN السريع (4 أرقام)
              </label>
              <div className="relative">
                <KeyRound className="w-4 h-4 text-slate-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  maxLength={4}
                  value={pinCode}
                  onChange={(e) => setPinCode(e.target.value.replace(/\D/g, ''))}
                  placeholder="1234"
                  className="w-full pr-9 pl-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-center font-bold text-sm tracking-widest"
                  required
                />
              </div>
              <p className="text-[10px] text-slate-400">لفتح قفل التطبيق السريع على التابليت</p>
            </div>
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">
              الأستاذ أو المشرف المسند إليه (اختياري)
            </label>
            <input
              type="text"
              value={assignedTeacher}
              onChange={(e) => setAssignedTeacher(e.target.value)}
              placeholder="اسم الأستاذ المسؤول عن الجهاز"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          <div className="space-y-1">
            <label className="block text-xs font-semibold text-slate-700">ملاحظات وموقع الجهاز</label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: يوضع في درج القاعة رقم 2 مع الشاحن"
              className="w-full px-3 py-2 text-xs bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
            <Button variant="outline" size="sm" type="button" onClick={onClose}>
              إلغاء
            </Button>
            <Button variant="primary" size="sm" type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'جاري التوليد...' : 'توليد رمز الربط و QR Code ←'}
            </Button>
          </div>
        </form>
      ) : (
        /* Step 2: QR Code & Direct Pairing Link */
        <div className="space-y-5 text-center">
          <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 flex flex-col items-center">
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>تم اعتماد الجهاز: {createdDevice?.name}</span>
            </div>

            {/* QR Code */}
            <QRCodeSvg value={pairingUrl} size={190} />

            <div className="text-xs text-slate-600 space-y-1 max-w-xs">
              <p className="font-bold text-slate-800">طريقة الاستخدام السريعة:</p>
              <ol className="list-decimal list-inside text-[11px] text-slate-500 text-right space-y-1">
                <li>افتح كاميرا الهاتف أو جهاز التابليت.</li>
                <li>وجه الكاميرا نحو مربع الرمز (QR Code) أعلاه.</li>
                <li>انقر على الرابط الذي سيظهر في الشاشة.</li>
                <li>أدخل كود PIN السريع: <span className="font-mono font-bold text-slate-900 bg-slate-200 px-1 rounded">{createdDevice?.pinCode}</span>.</li>
              </ol>
            </div>
          </div>

          {/* Quick Copy Link */}
          <div className="space-y-1.5 text-right">
            <label className="block text-[11px] font-bold text-slate-700">
              أو شارك رابط الربط المباشر مع الأستاذ:
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                readOnly
                value={pairingUrl}
                className="flex-1 px-3 py-1.5 text-xs bg-slate-100 border border-slate-300 rounded-lg font-mono text-left dir-ltr truncate text-slate-600"
              />
              <Button
                variant="outline"
                size="sm"
                icon={copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                onClick={handleCopyLink}
              >
                {copiedLink ? 'تم النسخ!' : 'نسخ الرابط'}
              </Button>
            </div>
          </div>

          {/* Direct Launch on PC (Simulate / Test Tablet Interface) */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <Button
              variant="secondary"
              size="sm"
              icon={<ExternalLink className="w-3.5 h-3.5" />}
              onClick={() => {
                if (createdDevice) {
                  onClose();
                  onOpenMobileTerminal(createdDevice);
                }
              }}
            >
              فتح وتجربة واجهة التابليت الآن 📱
            </Button>

            <Button
              variant="primary"
              size="sm"
              onClick={() => {
                onClose();
                setStep('form');
              }}
            >
              تم الانتهاء
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
};
