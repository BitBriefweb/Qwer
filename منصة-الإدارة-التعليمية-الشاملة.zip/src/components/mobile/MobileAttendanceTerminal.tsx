import React, { useState, useEffect } from 'react';
import {
  ConnectedDevice,
  StudyGroup,
  StudentWithDetails,
  AttendanceRecord,
  CenterSettings,
} from '../../types';
import {
  Tablet,
  CheckCircle,
  XCircle,
  Clock,
  AlertCircle,
  RefreshCw,
  ArrowRight,
  Sparkles,
  Calendar,
  Users,
  CheckCheck,
  Send,
  Wifi,
  Smartphone,
  ShieldCheck,
  Search,
  Scan,
} from 'lucide-react';
import { Button } from '../common/Button';
import { dataService } from '../../services/data-service';
import { BarcodeScannerModal } from '../attendance/BarcodeScannerModal';

interface MobileAttendanceTerminalProps {
  device: ConnectedDevice;
  groups: StudyGroup[];
  students: StudentWithDetails[];
  settings: CenterSettings;
  onSyncAttendance: (
    deviceToken: string,
    groupId: string,
    date: string,
    records: Array<{ studentId: string; status: AttendanceRecord['status']; notes?: string }>
  ) => Promise<{ success: boolean; count: number; message: string }>;
  onCloseTerminal?: () => void;
  isStandaloneMobile?: boolean;
}

export const MobileAttendanceTerminal: React.FC<MobileAttendanceTerminalProps> = ({
  device,
  groups,
  students,
  settings,
  onSyncAttendance,
  onCloseTerminal,
  isStandaloneMobile = false,
}) => {
  const [selectedGroupId, setSelectedGroupId] = useState(groups[0]?.id || '');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().substring(0, 10));
  const [sessionTime, setSessionTime] = useState(
    new Date().toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit' })
  );

  // Student Attendance State: studentId -> status
  const [attendanceState, setAttendanceState] = useState<
    Record<string, { status: AttendanceRecord['status']; notes: string }>
  >({});

  const [studentSearch, setStudentSearch] = useState('');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [syncStatus, setSyncStatus] = useState<{
    type: 'success' | 'error' | null;
    message: string;
    time?: string;
  }>({ type: null, message: '' });

  // Get active group
  const activeGroup = groups.find((g) => g.id === selectedGroupId) || groups[0];

  // Students belonging to active group
  const groupStudents = students.filter((stu) =>
    stu.enrolledGroups.some((g) => g.id === activeGroup?.id)
  );

  // Initialize all students as 'present' by default for convenience
  useEffect(() => {
    if (groupStudents.length > 0) {
      setAttendanceState((prev) => {
        const next = { ...prev };
        groupStudents.forEach((stu) => {
          if (!next[stu.id]) {
            next[stu.id] = { status: 'present', notes: '' };
          }
        });
        return next;
      });
    }
  }, [selectedGroupId, students]);

  const handleSetStatus = (studentId: string, status: AttendanceRecord['status']) => {
    setAttendanceState((prev) => ({
      ...prev,
      [studentId]: {
        status,
        notes: prev[studentId]?.notes || '',
      },
    }));
  };

  const handleSetAll = (status: AttendanceRecord['status']) => {
    setAttendanceState((prev) => {
      const next = { ...prev };
      groupStudents.forEach((stu) => {
        next[stu.id] = { status, notes: prev[stu.id]?.notes || '' };
      });
      return next;
    });
  };

  const handleSyncToPC = async () => {
    if (!activeGroup) return;

    try {
      setIsSyncing(true);
      setSyncStatus({ type: null, message: '' });

      const recordsToSync = groupStudents.map((stu) => ({
        studentId: stu.id,
        status: attendanceState[stu.id]?.status || 'present',
        notes: attendanceState[stu.id]?.notes?.trim() || undefined,
      }));

      const res = await onSyncAttendance(
        device.pairingToken,
        activeGroup.id,
        selectedDate,
        recordsToSync
      );

      setSyncStatus({
        type: 'success',
        message: res.message,
        time: new Date().toLocaleTimeString('ar-MA', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      });

      // Broadcast event so any open desktop tabs automatically refresh
      try {
        const channel = new BroadcastChannel('itqan_device_sync');
        channel.postMessage({ type: 'ATTENDANCE_SYNCED', deviceId: device.id, timestamp: Date.now() });
      } catch (e) {
        // Channel not supported in some older environments
      }
    } catch (err) {
      setSyncStatus({
        type: 'error',
        message: (err as Error).message || 'فشلت المزامنة مع الحاسوب',
      });
    } finally {
      setIsSyncing(false);
    }
  };

  const filteredStudents = groupStudents.filter((stu) => {
    if (!studentSearch.trim()) return true;
    return (
      stu.fullName.toLowerCase().includes(studentSearch.toLowerCase()) ||
      stu.code.toLowerCase().includes(studentSearch.toLowerCase())
    );
  });

  const presentCount = groupStudents.filter(
    (s) => (attendanceState[s.id]?.status || 'present') === 'present'
  ).length;
  const absentCount = groupStudents.filter(
    (s) => attendanceState[s.id]?.status === 'absent'
  ).length;
  const lateCount = groupStudents.filter(
    (s) => attendanceState[s.id]?.status === 'late'
  ).length;

  return (
    <div className="bg-slate-900 text-slate-100 min-h-screen flex flex-col antialiased selection:bg-indigo-500 selection:text-white" dir="rtl">
      {/* Top Mobile App Bar */}
      <header className="bg-slate-800/90 backdrop-blur-md border-b border-slate-700/80 sticky top-0 z-30 px-4 py-3 shadow-md">
        <div className="max-w-2xl mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            {onCloseTerminal && (
              <button
                type="button"
                onClick={onCloseTerminal}
                className="p-1.5 text-slate-300 hover:text-white bg-slate-700 rounded-lg cursor-pointer"
                title="الرجوع إلى لوحة التحكم الرئيسية"
              >
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            <div>
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-[11px] font-bold text-emerald-400">
                  {device.deviceType === 'tablet' ? 'تابليت القاعات' : 'هاتف الأستاذ'}
                </span>
                <span className="text-slate-400 text-[10px]">• متصل بالحاسوب</span>
              </div>
              <h1 className="text-sm font-black text-white tracking-tight">
                {device.name}
              </h1>
            </div>
          </div>

          {/* Sync status indicator */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleSyncToPC}
              disabled={isSyncing}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin' : ''}`} />
              <span>{isSyncing ? 'جاري المزامنة...' : 'مزامنة مع الحاسوب ⚡'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* Sync Notification Banner */}
      {syncStatus.type && (
        <div
          className={`px-4 py-2.5 text-xs font-medium text-center shadow-inner flex items-center justify-center gap-2 ${
            syncStatus.type === 'success'
              ? 'bg-emerald-950/80 text-emerald-300 border-b border-emerald-800'
              : 'bg-red-950/80 text-red-300 border-b border-red-800'
          }`}
        >
          {syncStatus.type === 'success' ? (
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
          ) : (
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          )}
          <span>{syncStatus.message}</span>
          {syncStatus.time && (
            <span className="text-[10px] font-mono text-slate-400">({syncStatus.time})</span>
          )}
        </div>
      )}

      {/* Main Terminal Body */}
      <main className="flex-1 max-w-2xl w-full mx-auto p-4 space-y-4">
        {/* Date and Group Controls (Big Touch Pills) */}
        <div className="bg-slate-800/80 p-3.5 rounded-2xl border border-slate-700/80 space-y-3">
          <div className="grid grid-cols-2 gap-2.5">
            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <Calendar className="w-3 h-3 text-indigo-400" />
                <span>تاريخ الحصة:</span>
              </label>
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>

            <div className="space-y-1">
              <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
                <Clock className="w-3 h-3 text-amber-400" />
                <span>توقيت الحصة:</span>
              </label>
              <input
                type="time"
                value={sessionTime}
                onChange={(e) => setSessionTime(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-900 border border-slate-700 rounded-xl text-white font-mono focus:ring-2 focus:ring-indigo-500 outline-none"
              />
            </div>
          </div>

          {/* Group Picker Slider */}
          <div className="space-y-1.5 pt-1 border-t border-slate-700/60">
            <label className="text-[11px] font-semibold text-slate-400 flex items-center gap-1">
              <Users className="w-3 h-3 text-cyan-400" />
              <span>اختر الفوج / الحصة الدراسية:</span>
            </label>

            <div className="flex gap-2 overflow-x-auto pb-1.5 no-scrollbar">
              {groups.map((grp) => {
                const isSelected = selectedGroupId === grp.id;
                return (
                  <button
                    type="button"
                    key={grp.id}
                    onClick={() => setSelectedGroupId(grp.id)}
                    className={`px-3 py-2 rounded-xl text-xs font-bold shrink-0 transition-all cursor-pointer text-right flex flex-col justify-between ${
                      isSelected
                        ? 'bg-indigo-600 text-white shadow-md ring-2 ring-indigo-400/40'
                        : 'bg-slate-900/90 text-slate-300 border border-slate-700 hover:border-slate-600'
                    }`}
                  >
                    <span>{grp.name}</span>
                    <span className="text-[10px] opacity-75 font-normal">
                      {grp.teacherName || 'أستاذ المادة'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Attendance Summary Bar & Quick All-Present Action */}
        <div className="bg-slate-800/80 p-3 rounded-2xl border border-slate-700/80 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 font-bold text-emerald-400">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
              <span>حاضر: {presentCount}</span>
            </span>
            <span className="flex items-center gap-1 font-bold text-rose-400">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
              <span>غائب: {absentCount}</span>
            </span>
            <span className="flex items-center gap-1 font-bold text-amber-400">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <span>متأخر: {lateCount}</span>
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsScannerOpen(true)}
              className="text-[11px] font-bold text-emerald-300 hover:text-white bg-emerald-950/80 hover:bg-emerald-900 border border-emerald-700/60 px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
            >
              <Scan className="w-3.5 h-3.5 text-emerald-400" />
              <span>مسح بالكاميرا 📷</span>
            </button>

            <button
              type="button"
              onClick={() => handleSetAll('present')}
              className="text-[11px] font-bold text-indigo-300 hover:text-white bg-indigo-950/60 hover:bg-indigo-900/80 border border-indigo-700/50 px-2.5 py-1.5 rounded-lg flex items-center gap-1 transition-colors cursor-pointer"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>الكل حاضر ✓</span>
            </button>
          </div>
        </div>

        {/* Student Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-500 absolute right-3.5 top-3" />
          <input
            type="text"
            value={studentSearch}
            onChange={(e) => setStudentSearch(e.target.value)}
            placeholder="بحث عن اسم تلميذ في هذا الفوج..."
            className="w-full pr-10 pl-3 py-2.5 text-xs bg-slate-800/90 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>

        {/* Student Attendance Cards */}
        {groupStudents.length === 0 ? (
          <div className="p-8 text-center bg-slate-800/50 rounded-2xl border border-slate-700/80 space-y-2">
            <Users className="w-8 h-8 text-slate-500 mx-auto" />
            <p className="text-xs font-bold text-slate-300">
              لا يوجد تلاميذ مسجلون في فوج "{activeGroup?.name}" حالياً.
            </p>
            <p className="text-[11px] text-slate-500">
              قم بتسجيل التلاميذ في هذا الفوج من الحاسوب الرئيسي أولاً.
            </p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {filteredStudents.map((stu, index) => {
              const currentStatus = attendanceState[stu.id]?.status || 'present';

              return (
                <div
                  key={stu.id}
                  className={`p-3.5 rounded-2xl border transition-all ${
                    currentStatus === 'present'
                      ? 'bg-slate-800/90 border-emerald-900/60'
                      : currentStatus === 'absent'
                      ? 'bg-rose-950/30 border-rose-900/80 ring-1 ring-rose-500/20'
                      : currentStatus === 'late'
                      ? 'bg-amber-950/30 border-amber-900/80'
                      : 'bg-blue-950/30 border-blue-900/80'
                  }`}
                >
                  <div className="flex items-center justify-between gap-3 mb-2.5">
                    <div className="flex items-center gap-2">
                      <span className="w-6 h-6 rounded-full bg-slate-700 text-slate-300 font-mono text-[11px] font-bold flex items-center justify-center shrink-0">
                        {index + 1}
                      </span>
                      <div>
                        <h3 className="font-black text-sm text-white">{stu.fullName}</h3>
                        <p className="text-[11px] text-slate-400 font-mono">
                          {stu.code} • {stu.guardianPhone}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {(currentStatus === 'absent' || currentStatus === 'late') && stu.guardianPhone && (
                        <a
                          href={dataService.getWhatsAppAttendanceUrl(
                            stu,
                            activeGroup?.name || 'الفوج',
                            selectedDate,
                            currentStatus,
                            settings.centerName
                          )}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-2 py-0.5 rounded-md bg-emerald-900/70 hover:bg-emerald-800 text-emerald-300 border border-emerald-700/70 text-[10px] font-bold flex items-center gap-1 transition-colors"
                          title="إرسال إشعار غياب عبر واتساب"
                        >
                          <span>💬 واتساب</span>
                        </a>
                      )}

                      <span
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold uppercase ${
                          currentStatus === 'present'
                            ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                            : currentStatus === 'absent'
                            ? 'bg-rose-950 text-rose-300 border border-rose-800'
                            : currentStatus === 'late'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-blue-950 text-blue-300 border border-blue-800'
                        }`}
                      >
                        {currentStatus === 'present'
                          ? 'حاضر'
                          : currentStatus === 'absent'
                          ? 'غائب'
                          : currentStatus === 'late'
                          ? 'متأخر'
                          : 'مبرر'}
                      </span>
                    </div>
                  </div>

                  {/* Big Touch Action Buttons for Tablet / Phone */}
                  <div className="grid grid-cols-4 gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleSetStatus(stu.id, 'present')}
                      className={`py-2 px-1 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                        currentStatus === 'present'
                          ? 'bg-emerald-600 text-white shadow-md ring-2 ring-emerald-400/50'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      حاضر
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSetStatus(stu.id, 'absent')}
                      className={`py-2 px-1 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                        currentStatus === 'absent'
                          ? 'bg-rose-600 text-white shadow-md ring-2 ring-rose-400/50'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      غائب
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSetStatus(stu.id, 'late')}
                      className={`py-2 px-1 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                        currentStatus === 'late'
                          ? 'bg-amber-600 text-white shadow-md ring-2 ring-amber-400/50'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      متأخر
                    </button>

                    <button
                      type="button"
                      onClick={() => handleSetStatus(stu.id, 'excused')}
                      className={`py-2 px-1 rounded-xl text-xs font-bold text-center transition-all cursor-pointer ${
                        currentStatus === 'excused'
                          ? 'bg-blue-600 text-white shadow-md ring-2 ring-blue-400/50'
                          : 'bg-slate-900 text-slate-300 hover:bg-slate-700 border border-slate-700'
                      }`}
                    >
                      مبرر
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Bottom Big Sync Sticky Button */}
        <div className="sticky bottom-3 pt-2">
          <button
            type="button"
            onClick={handleSyncToPC}
            disabled={isSyncing || groupStudents.length === 0}
            className="w-full py-3.5 px-4 rounded-2xl bg-linear-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-sm shadow-xl flex items-center justify-center gap-2 transition-all active:scale-[0.98] cursor-pointer disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>
              {isSyncing
                ? 'جاري حفظ ومزامنة الحضور مع الحاسوب...'
                : `تثبيت ومزامنة غياب (${groupStudents.length} تلميذ) في الحاسوب`}
            </span>
          </button>
        </div>
      </main>

      {/* Mobile Barcode / QR Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        groupStudents={groupStudents}
        onStudentScanned={(scannedStu) => {
          handleSetStatus(scannedStu.id, 'present');
        }}
      />
    </div>
  );
};
