export type UserRole = 'director' | 'admin' | 'accountant' | 'viewer';

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  permissions: string[];
  passwordHash: string;
  active: boolean;
  lastLogin?: string;
}

export interface Level {
  id: string;
  name: string; // e.g. "الثالثة إعدادي", "الأولى باك علوم تجريبية", "الثانية باك علوم رياضية"
  code: string;
  orderIndex: number;
  description?: string;
}

export interface Subject {
  id: string;
  name: string; // e.g. "اللغة الألمانية", "اللغة الإنجليزية", "الرياضيات", إلخ
  levelId?: string; // اختياري - يمكن أن تكون المادة عامة أو تابعة لمستوى معين
  code?: string; // رمز المادة (e.g. DE, EN, FR, MATH)
  department?: 'languages' | 'sciences' | 'humanities' | 'general'; // تصنيف الفرع: لغات حية، علوم، آداب، عام
  description?: string;
  monthlyFeeDefault?: number; // السعر الشهري المقترح بالدرهم
  registrationFeeDefault?: number;
  sessionFeeDefault?: number;
  teacherDefault?: string; // الأستاذ المشرف الافتراضي
  color?: string; // لون الهوية البصرية للفرع
  targetLevels?: string[]; // المستويات المستهدفة
  isActive?: boolean;
}

export interface SubjectBranchSummary {
  subject: Subject;
  groupsCount: number;
  studentsCount: number;
  weeklySessionsCount: number;
  monthlyRevenueProjected: number;
  teachers: string[];
}

export interface GroupSchedule {
  day: 'الاثنين' | 'الثلاثاء' | 'الأربعاء' | 'الخميس' | 'الجمعة' | 'السبت' | 'الأحد';
  timeStart: string; // "17:00"
  timeEnd: string; // "19:00"
  classroom?: string;
}

export interface StudyGroup {
  id: string;
  name: string; // e.g. "مجموعة التميز - رياضيات 2 باك ع.ر"
  levelId: string;
  subjectId: string;
  teacherName: string;
  maxCapacity: number;
  schedule: GroupSchedule[];
  monthlyFee: number; // بالدرهم المغربي MAD
  registrationFee: number;
  perSessionFee?: number;
  status: 'active' | 'paused';
  academicYear: string;
  notes?: string;
}

export interface Student {
  id: string;
  code: string; // رقم التعريف الداخلي أو مسار (e.g. STU-2026-001)
  fullName: string;
  birthDate?: string;
  gender: 'male' | 'female';
  guardianName: string;
  guardianPhone: string;
  guardianRelation: 'أب' | 'أم' | 'ولي أمر' | 'آخر';
  address?: string;
  levelId: string;
  status: 'active' | 'inactive' | 'suspended';
  registrationDate: string;
  notes?: string;
}

export interface StudentWithDetails extends Student {
  totalCharges: number;
  totalPaid: number;
  remainingBalance: number;
  enrolledGroups: Array<{ id: string; name: string; teacherName: string; monthlyFee: number }>;
  attendanceRate: number; // percentage e.g. 95%
}

export interface StudentEnrollment {
  id: string;
  studentId: string;
  groupId: string;
  enrollmentDate: string;
  status: 'active' | 'transferred' | 'dropped';
  transferReason?: string;
}

export type ChargeType = 'registration' | 'monthly' | 'session' | 'custom';

export interface FeeCharge {
  id: string;
  studentId: string;
  groupId?: string;
  type: ChargeType;
  title: string; // e.g. "واجب شهر أكتوبر 2026 - مادة الرياضيات"
  amount: number; // المبلغ المستحق بالدرهم
  dueDate: string;
  academicYear: string;
  periodMonth?: string; // "2026-10"
  status: 'unpaid' | 'partial' | 'paid';
  paidAmount: number;
  remainingAmount: number;
  createdAt: string;
}

export type PaymentMethod = 'cash' | 'transfer' | 'cheque' | 'card' | 'other';

export interface Payment {
  id: string;
  receiptNumber: string; // e.g. "REC-2026-0014"
  studentId: string;
  chargeId?: string;
  amountPaid: number; // المبلغ المؤدى
  previousBalance: number;
  remainingBalanceAfter: number; // المبلغ المتبقي بعد هذه الدفعة
  paymentDate: string;
  paymentMethod: PaymentMethod;
  referenceNumber?: string;
  notes?: string;
  recordedBy: string; // username or name
  status: 'completed' | 'cancelled';
  cancellationReason?: string;
  cancelledAt?: string;
  cancelledBy?: string;
  itemsCovered: string; // Description of what this receipt covers
}

export type ExpenseCategory =
  | 'rent'
  | 'salaries'
  | 'utilities'
  | 'supplies'
  | 'maintenance'
  | 'marketing'
  | 'taxes'
  | 'other';

export interface Expense {
  id: string;
  title: string;
  category: ExpenseCategory;
  amount: number;
  date: string;
  paymentMethod: PaymentMethod;
  beneficiary?: string; // المستفيد / الأستاذ / المورد
  referenceDoc?: string; // رقم الفاتورة أو الوصل
  notes?: string;
  recordedBy: string;
}

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export interface AttendanceRecord {
  id: string;
  groupId: string;
  studentId: string;
  sessionDate: string; // "YYYY-MM-DD"
  sessionTime?: string;
  status: AttendanceStatus;
  notes?: string;
  recordedBy: string;
  updatedAt: string;
}

export interface CenterSettings {
  centerName: string;
  slogan: string;
  address: string;
  city?: string;
  phone: string;
  phoneSecondary?: string;
  email?: string;
  website?: string;
  logoUrl?: string;
  currency: string; // "MAD" أو "درهم"
  academicYear: string; // "2025/2026"
  receiptPrefix: string; // "REC"
  receiptNextNumber: number;
  receiptTermsNotice: string;
  directorName: string;
  directorTitle?: string;
  directorSignatureUrl?: string;
  taxIdOrLicense?: string;
  printFormatDefault: 'A4' | 'thermal_80mm';
}

export interface AuditLog {
  id: string;
  timestamp: string;
  userId: string;
  userName: string;
  action: string;
  entityType: 'student' | 'group' | 'payment' | 'expense' | 'attendance' | 'settings' | 'backup' | 'teacher' | 'grade' | 'caisse';
  entityId: string;
  details: string;
}

export interface LicenseInfo {
  centerName: string;
  licenseKey?: string; // يتم حجبه بعد التفعيل ولا يتم حفظه صريحاً
  licenseType: 'lifetime_commercial' | 'trial';
  issueDate: string;
  expiresAt?: string;
  machineFingerprint: string;
  isValid: boolean;
  activationSignature?: string; // البصمة الرقمية المشفرة
  maskedKey?: string; // الكود المحجوب للعرض الآمن فقط
  activatedAt?: string;
}

export type DeviceType = 'tablet' | 'phone' | 'laptop' | 'other';

export interface ConnectedDevice {
  id: string;
  name: string; // e.g. "تابليت القاعة 1", "هاتف الأستاذ طارق"
  deviceType: DeviceType;
  pairingToken: string; // رمز المصادقة المشفر
  pinCode: string; // رمز PIN السريع (4 أرقام)
  assignedTeacher?: string; // اسم الأستاذ المسند له الجهاز
  allowedGroupIds?: string[]; // الأفواج المسموح بتسجيل غيابها
  status: 'active' | 'revoked'; // نشط أو معطل
  lastSyncAt?: string; // آخر موعد مزامنة ناجحة مع الحاسوب
  createdAt: string;
  notes?: string;
}

// ==========================================
// TEACHER PAYROLL & EVALUATIONS MODELS
// ==========================================
export type TeacherCompensationType = 'percentage' | 'hourly' | 'monthly_fixed';

export interface Teacher {
  id: string;
  name: string;
  phone: string;
  email?: string;
  specialty: string; // e.g. "اللغة الألمانية"
  compensationType: TeacherCompensationType;
  rate: number; // e.g. 50 (%) or 120 (MAD/hour) or 4000 (monthly)
  status: 'active' | 'inactive';
  joinedAt: string;
  notes?: string;
}

export interface TeacherPaymentRecord {
  id: string;
  teacherId: string;
  teacherName: string;
  month: string; // e.g. "2026-09"
  amount: number;
  paymentDate: string;
  details: string;
  recordedBy: string;
  receiptNumber: string;
}

export interface GradeRecord {
  id: string;
  studentId: string;
  groupId: string;
  subjectId: string;
  evaluationTitle: string; // e.g. "الفرض الأول - الدورة الأولى"
  date: string;
  score: number; // e.g. 17.5
  maxScore: number; // e.g. 20
  notes?: string;
}

export interface DailyCashClosure {
  id: string;
  date: string; // YYYY-MM-DD
  closedAt: string; // YYYY-MM-DD HH:mm
  closedByUserId: string;
  closedByUserName: string;
  openingCash: number;
  totalCashIncome: number;
  totalCashExpense: number;
  expectedCashInDrawer: number;
  actualCashInDrawer: number;
  discrepancy: number; // actual - expected
  notes?: string;
}

export interface AppDatabase {
  levels: Level[];
  subjects: Subject[];
  groups: StudyGroup[];
  students: Student[];
  enrollments: StudentEnrollment[];
  charges: FeeCharge[];
  payments: Payment[];
  expenses: Expense[];
  attendance: AttendanceRecord[];
  devices: ConnectedDevice[];
  teachers: Teacher[];
  teacherPayments: TeacherPaymentRecord[];
  grades: GradeRecord[];
  cashClosures: DailyCashClosure[];
  settings: CenterSettings;
  users: User[];
  auditLogs: AuditLog[];
  license: LicenseInfo;
}
